---
titulo: 'Sagrada Familia: Guided Tour with Tower Access'
slug: sagrada-familia-tour-with-tower-access
ciudad: barcelona
descripcion: Guided tour of the Sagrada Familia with skip-the-line entry and optional access to one of the basilica towers for views over Barcelona from above.
slugs:
  en: sagrada-familia-tour-with-tower-access
  es: sagrada-familia-tour-con-torre
duracion: 1h 30min - 2h
duracionMinutos: 90
precioDesde: 66
moneda: EUR
idiomas:
- es
- en
proveedor: getyourguide
urlReserva: https://www.getyourguide.com/barcelona-l45/barcelona-visita-a-la-sagrada-familia-y-visita-opcional-a-la-torre-t72879/?partner_id=C71NOAW
cancelacionGratuita: true
horasCancelacion: 24
highlights:
- The only option with access to one of the basilica towers
- A 1-hour guided tour of the interior plus the tower climb on your own (about 30 min)
- Panoramic views of Barcelona from high up the temple
- Skip-the-line entry, a professional local guide and headphones included
- Also includes the crypt and the Gaudí Museum
incluye:
- Fast-access ticket to the Sagrada Familia
- Professional local guide and live narration
- Headphones to hear the guide
- Access to one of the basilica towers (when you choose the with-tower option)
noIncluye:
- Hotel pickup and return service
- Gratuities and personal expenses
- The tower climb, if you book the no-tower option
puntoEncuentro:
  texto: Carrer de Nàpols, 218, 08013 Barcelona
  descripcionGuia: 'Meet your guide at Carrer de Nàpols, 218, next to the basilica. Look for the Amigo Tours logo. Arrive with time to spare: there are queues to enter the Sagrada Familia because of the security checks.'
  latitud: 41.4043
  longitud: 2.1731
  zoom: 17
detallesPracticos:
  ticketMovil: true
  confirmacionInmediata: true
  accesibleSilla: false
  edadMinima: 0
informacionImportante:
  queTraer:
  - Passport or ID card for every participant, including children
  noAptoPara:
  - 'People with reduced mobility or wheelchair users: the operator does not recommend this route'
  - Children under 6 for the tower climb, even accompanied by an adult
  aTenerEnCuenta:
  - The tower climb is an option chosen and paid for at booking; check your booking includes it
  - You go up the tower by lift but come down by stairs; only one tower is open, and the monument decides which depending on the day and the works
  - The tower can close in bad weather (rain or wind)
  - The guided part lasts about 90 minutes; the tower climb is done afterwards on your own and takes about 30 minutes
  - Audio receivers are not handed out to children under 11
accesibilidad: 'The operator states the route is NOT recommended for people with reduced mobility or wheelchair users. The tower climb, moreover, is not accessible: you come down by stairs.'
politicaCancelacion: Free cancellation with a full refund if you cancel 24 hours in advance.
preguntasFrecuentes:
- pregunta: Is the tower climb included in the price?
  respuesta: It's an option you choose and pay for at booking. There's a with-tower version and a no-tower version; make sure you select the one that includes the climb if that's what you want. The price from €75 corresponds to the with-tower option.
- pregunta: Which tower do you go up and what's it like?
  respuesta: Only one tower is open, and the monument decides which depending on the day and the works (Nativity or Passion). You go up by lift but come down a narrow staircase. It can close in bad weather — rain or wind.
- pregunta: Can children go up?
  respuesta: Children under 6 cannot go up the tower, even with an adult. They can access the rest of the route. Note that audio receivers are not handed out to children under 11.
- pregunta: Is it wheelchair accessible?
  respuesta: No. The operator does not recommend the route for people with reduced mobility, and the tower, because of the descent by stairs, is not accessible in any case.
- pregunta: How long is it in total?
  respuesta: The guided part lasts about 90 minutes and includes the interior, the crypt and the Gaudí Museum. Afterwards you go up the tower on your own, which adds about 30 minutes.
variantes:
- sagrada-familia-skip-the-line-guided-tour
- sagrada-familia-small-group-tour
- sagrada-familia-ticket-audio-guide
avisoReserva: In high season, the Sagrada Familia sells out weeks in advance
opinionEditorial: 'This is the experience that takes you up one of the basilica''s towers, and that''s exactly its appeal: taking in Barcelona from high up Gaudí''s temple. The guided tour is really well handled — it includes the crypt and the Gaudí Museum, with headphones and live narration — and you do the tower climb afterwards, on your own, in about 30 minutes.


  A few things so you go in fully informed: you go up the tower by lift and down a narrow staircase, only one tower is open — the monument decides which — and it can close in rain or wind. It isn''t accessible and children under 6 can''t go up. If what you want are the views from the Sagrada Familia, this is the experience that offers them.

  '
atraccionesRelacionadas:
- sagrada-familia
categoria: visitasGuiadas
keywords:
- sagrada familia with towers
- sagrada familia tower climb
- sagrada familia tower tour
- sagrada familia views
- sagrada familia tower tickets
imagen: /images/actividades/barcelona/sagrada-familia/sagrada-familia-impressive-view-basilica-barcelona-hero-hero.webp
imagenAlt: Sagrada Familia basilica front facade with towering spires, Barcelona
ratingProveedor: 4.4
numeroOpiniones: 5518
publicada: true
destacada: false
fecha: '2026-05-15'
galeria:
- src: /images/actividades/barcelona/sagrada-familia/vista-desde-torre-nacimiento.webp
  alt: View of Barcelona and Plaça de Gaudí through an opening in the Nativity towers
- src: /images/actividades/barcelona/sagrada-familia/pexels-11920332-hero.webp
  alt: Interior of the Sagrada Familia with columns lit by the warm-toned stained glass light
- src: /images/actividades/barcelona/sagrada-familia/vista-desde-torre-agbar.webp
  alt: Barcelona and Torre Glòries seen from a Sagrada Familia tower
- src: /images/actividades/barcelona/sagrada-familia/sagrada-familia-6622795573-hero-hero.webp
  alt: Sagrada Familia basilica facade with intricate architectural details in Barcelona
- src: /images/actividades/barcelona/sagrada-familia/pinaculos-torre-vistas.webp
  alt: Fruit-topped pinnacles and the city below, seen from high on the Sagrada Familia
- src: /images/actividades/barcelona/sagrada-familia/sagrada-familia-foto-9029528-hero-hero.webp
  alt: Sagrada Familia basilica in Barcelona with intricate stone facades and towering spires
- src: /images/actividades/barcelona/sagrada-familia/wikimedia-115176367-hero.webp
  alt: Spiral staircase inside a Sagrada Familia tower
- src: /images/actividades/barcelona/sagrada-familia/sagrada-familia-vibrant-stained-glass-windows-hero-hero.webp
  alt: Vibrant stained glass windows of Sagrada Familia basilica in Barcelona, Spain
- src: /images/actividades/barcelona/sagrada-familia/cripta-sagrada-familia.webp
  alt: Crypt of the Sagrada Familia, where Gaudí is buried
- src: /images/actividades/barcelona/sagrada-familia/wikimedia-115176370-hero.webp
  alt: Barcelona street view with historic buildings and urban architecture
- src: /images/actividades/barcelona/sagrada-familia/museo-taller-maquetas.webp
  alt: Plaster model workshop in the Sagrada Familia museum
- src: /images/actividades/barcelona/sagrada-familia/pexels-15616250-hero.webp
  alt: Interior stained-glass windows of the Sagrada Familia with saints' names inscribed
guiasRelacionadas:
- sagrada-familia-which-ticket-to-choose
fecha_actualizacion: '2026-10-25'
alternativa:
  slug: sagrada-familia-small-group-tour
  motivo: 'Sagrada Familia tickets and tours on GetYourGuide sell out one to two weeks ahead. If your date is gone, this small-group visit (4.7 from 3,700+ reviews) includes skip-the-line entry and has its own allocation:'
---

## What you'll see

The route adds to the usual guided visit an extra that no other listing offers: the climb up one of the towers.

- **The interior and the crypt:** the nave with the tree-like columns and the stained glass, and the crypt where Gaudí is buried.
- **The Gaudí Museum:** below the basilica, where you understand the architect's life and how the project evolved.
- **One tower:** access to one of the temple's towers — Nativity or Passion, the monument decides — for views over Barcelona from above.

## How it works

The meeting point is **Carrer de Nàpols, 218**, next to the basilica; look for the **Amigo Tours** logo. Arrive with time to spare: there are queues to get in because of the security checks.

The **guided part lasts about 90 minutes** with a local guide, live narration and headphones. It covers the interior, the crypt and the Gaudí Museum. Afterwards, you **go up the tower on your own** — about 30 minutes more.

About the tower, read the small print before booking: the **climb is an option** chosen and paid for at booking, so check your booking includes it. You **go up by lift and down a narrow staircase**, only one tower is open, **children under 6 can't go up** and it can close in rain or wind. Entry is nominative and the church dress code applies.

## Who I'd recommend it to

- If you've decided you want to go up a tower: it's the only option that includes it.
- If you want a full guided visit, with the crypt and the Gaudí Museum, as well as the tower.
- If you don't mind managing the tower climb yourself after the guided part.

## Who I would NOT recommend it to

- If you need accessibility: neither the route nor the tower is. See the [small-group guided tour](/en/cities/barcelona/activities/sagrada-familia-small-group-tour).
- If you're travelling with children under 6 and the tower is the reason: they won't be able to go up.

Our guide [Sagrada Familia: how to visit it well](/en/guides/barcelona/sagrada-familia-how-to-visit) has a section on which tower to climb and how to make the most of your visit.
