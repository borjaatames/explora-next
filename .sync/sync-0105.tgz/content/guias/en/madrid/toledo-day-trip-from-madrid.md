---
titulo: 'Toledo day trip from Madrid: what to see in one day'
descripcion: 'Toledo day trip from Madrid: what to see in one day, a timed route from the Cathedral (€12) to the Jewish Quarter, the €14 bracelet and where to eat.'
metaTitle: 'Toledo day trip from Madrid: one-day route'
categoria: "madrid"
slug: "toledo-day-trip-from-madrid"
fecha: "2026-04-02"
fecha_actualizacion: '2026-11-04'
autor: Borja
publicada: true
destacada: false
imagen_portada: "/images/guias/escapadas-desde-madrid-toledo.jpg"
imagen_alt: The Alcázar of Toledo, Spain
tiempo_lectura: 5
keywords:
  - 'toledo day trip from madrid'
  - 'toledo in one day'
  - 'what to see in toledo in one day'
  - 'toledo one day itinerary'
  - 'day trips from madrid'
slugs:
  es: escapadas-desde-madrid-toledo
  en: toledo-day-trip-from-madrid
  de: tagesausflug-toledo-ab-madrid
  fr: tolede-depuis-madrid-en-une-journee
  it: toledo-da-madrid-in-un-giorno
  pt: toledo-desde-madrid-num-dia
reservasArriba: true
respuestaCorta: 'Take the **Avant train from Atocha (33 minutes, €22–26 return)** or drive an hour on the A-42, and arrive by 10 AM. Spend the morning on the **Cathedral (€12)**, Santo Tomé and Santa María la Blanca, the afternoon in the Jewish Quarter, and finish at the **Mirador del Valle**. The [**€14 bracelet**](/en/cities/madrid/activities/toledo-tourist-bracelet-7-monuments) covers seven smaller monuments.'
actividades:
  - excursion-toledo-dia-completo
  - toledo-pulsera-turistica-7-monumentos
  - toledo-catedral-visita-guiada
  - excursion-avila-segovia-con-entradas
  - excursion-toledo-molinos-quijote
  - excursion-chinchon-aranjuez-toledo
  - excursion-alcala-henares-bodega-privada
  - escorial-valle-cuelgamuros-excursion-grupo
  - tour-privado-escorial-monasterio-real
---

Seventy kilometers from Madrid sits an intact medieval city: **Toledo**, where Jews, Muslims and Christians lived side by side for centuries and left their mark in stone. El Escorial is one monument and Segovia an aqueduct plus an alcázar; Toledo is a whole city listed by UNESCO, and you can see it well in one day. Here's the route, what to skip and the usual mistakes. If you want the full list of things to do in Toledo, with prices and opening hours for each sight, see [things to do in Toledo](/en/guides/madrid/things-to-do-in-toledo).

## When to go

| Season | Verdict |
| --- | --- |
| April, May, September, October | Ideal: 15–25 °C, good light |
| November | Underrated: morning fog seen from the Mirador del Valle, few tourists |
| December–March | Fine: cold, uncrowded |
| July–August | Avoid: 35–40 °C on shadeless hills; if you must, leave Madrid at 8 AM |
| Holy Week | Only for the processions; everything is packed |

## How to get there

- **Avant high-speed train from Atocha:** 33 minutes, roughly hourly from about 6:50 AM, last return around 9:30 PM; **€22–26 return**. Early trains sell out, so book on Renfe. Toledo station is a 20-minute uphill walk from the old town; take bus 5 or a taxi (€6–8). Timetables and fares are in our [Madrid to Toledo train guide](/en/guides/madrid/madrid-to-toledo-train).
- **Car:** 1 hour on the A-42 (free) or AP-41 (toll). It's the only way to stop easily at the **Mirador del Valle**. Don't drive into the old town: access is controlled by number plate and fines are steep. Park at **Safont** (€0.40/hour for non-residents, the cheapest regulated rate in Toledo according to the city council), next to the free escalators up to the old town, or at **Cardenal**, by the Puerta de Bisagra.
- **Alsa bus** from Plaza Elíptica: 1 hour, about **€11 return**, every 30 minutes at peak times; last return around 10 PM.
- **Organized tour:** €45–70 with transport, guide and tickets, 8–9 hours. Worth it in a group or without a car; a couple with a car is better off alone.

[actividad: toledo-full-day-from-madrid]

## Opening hours and prices 2026

| What | Hours | Price |
| --- | --- | --- |
| Avant train Atocha–Toledo | 33 min, roughly every hour; last from Madrid at 20:45 (Sunday to Thursday), last back around 21:30 | €13-16 one way, €22-26 return |
| Alsa bus from Plaza Elíptica | 50 min direct | From €6.55 one way |
| Cathedral | Monday to Saturday 10:00-18:30; Sunday 14:00-18:30; last entry half an hour before closing | €12 |
| Alcázar (Army Museum) | 10:00-17:00, last entry 16:30; closed on Mondays | €5; free on Wednesdays |
| Santo Tomé (*The Burial of the Count of Orgaz*) | 10:00-18:45 from 1 March to 15 October; 10:00-17:45 the rest of the year | €4 |
| El Tránsito Synagogue (Sephardic Museum) | Tuesday to Saturday 9:30-20:00; Sundays and holidays 10:00-15:00; closed Mondays | €3; free on Saturdays from 14:00 and on Sundays |
| Tourist wristband | 7 monuments (Santo Tomé, Santa María la Blanca, San Juan de los Reyes, Cristo de la Luz, the Jesuit church, El Salvador and Doncellas Nobles), one entry each, valid 7 days | €14 (excludes the Cathedral and the Alcázar) |

*Checked in November 2026 on the official websites of the Cathedral, the Army Museum, Santo Tomé and Toledo Monumental; train and bus details from Renfe and Alsa.*

## A one-day route

| Time | Plan |
| --- | --- |
| 10 AM | Mirador del Valle (by car), then up to Plaza de Zocodover |
| 11 AM–2 PM | Cathedral, Santo Tomé, Santa María la Blanca |
| 2–3:30 PM | Lunch in the old town |
| 3:30–6 PM | Jewish Quarter, San Juan de los Reyes, Puente de San Martín |
| 6–8 PM | Mirador del Valle at sunset, or the cobertizos |
| 8 PM | Back to Madrid |

**Morning: the classic three.** The **Cathedral** (€12, 1.5 hours) is the second-largest in Spain: Arfe's monstrance, Narciso Tomé's Transparente, the sacristy with its El Grecos and the Mozarabic chapel. Buy online at `catedralprimada.es` to skip a 30–45 minute queue in high season. **Santo Tomé** is one room and one painting, El Greco's *The Burial of the Count of Orgaz* (30 minutes). **Santa María la Blanca** is a 12th-century synagogue with white columns and horseshoe arches. If you'd rather see the three cultures side by side, swap the last two for the 10th-century **Mosque of Cristo de la Luz** and the **Synagogue of El Tránsito and Sephardic Museum** (€3).

**The tourist bracelet** (€14) covers seven smaller monuments that cost about €4 each: Santo Tomé, Santa María la Blanca, Cristo de la Luz, San Juan de los Reyes, El Salvador, San Ildefonso (the Jesuits) and Colegio de Doncellas. It pays off from the fourth entry. The Cathedral is not included.

[actividad: toledo-tourist-bracelet-7-monuments]

**Lunch.** Skip Plaza de Zocodover. Around **Calle de la Sillería** and **Plaza de Padilla**, taverns serve set lunches for €12–18: carrillera (pork cheek), stewed partridge, Manchego cheese. On Calle Comercio quality varies, so check reviews first. For **marzipan**, Confitería Santo Tomé is the famous name, but the better buy is through the revolving hatch (torno) at the Comendadoras or Concepcionistas convents, from nuns you never see.

**Afternoon: get lost.** The **Jewish Quarter** itself is the monument: narrow streets, white houses, small squares. At **San Juan de los Reyes** (on the bracelet), see the cloister and the views over the Tagus. Cross the **Puente de San Martín** on foot and look back. The **Alcázar and Army Museum** (€5, 1.5 hours) is only worth it if military history interests you.

**Finish.** By car, go back to the **Mirador del Valle at sunset**, with the Cathedral and Alcázar lit against a purple sky (by train, a taxi of about €10 gets you there). On foot, walk the **cobertizos**, covered medieval passages unique to Toledo (Doncellas, Santo Domingo el Antiguo, Santa Clara), almost empty at dusk.

## What to skip

- **The tourist train:** Toledo is meant to be walked. Only worth it with reduced mobility.
- **Souvenir-shop "Toledo swords":** about 90% are mass-produced imports. Real damascene work carries the Damasquinados de Toledo seal or comes from recognized workshops such as Mariano Zamorano or Felipe Galante.
- **"Legends and mysteries" night tours:** the empty, lit-up city is better on your own and in silence.

## Common mistakes

1. **Arriving at 11 AM.** Leave Madrid at 8–9 AM; the first trains give you the whole morning.
2. **Trying to see everything.** There are 30+ monuments; you'll do four to six well.
3. **Not buying the Cathedral ticket online.**
4. **Skipping the Mirador del Valle.**
5. **Walking up the hills** when the free Recaredo escalators run up from Safont.
6. **Skipping the bracelet** when you'll enter more than three small monuments.

## If you stay the night

Toledo empties once the day-trippers leave. Stay in the **old town** (parador and boutique hotels in medieval buildings: pricey but unique), **around Zocodover** (practical) or **across the Tagus near the Mirador del Valle**, with the lit-up city from your window. Avoid the ring-road hotels.

## Other day trips within an hour

**El Escorial and the Valley of Cuelgamuros** (see [Madrid in 3 days](/en/guides/madrid/madrid-in-3-days)), **Segovia** (aqueduct, alcázar, roast suckling pig; see our [Segovia day trip](/en/guides/madrid/segovia-day-trip-from-madrid) route), **Aranjuez** (royal palace and gardens, best in spring), **Ávila** (intact walls, colder; see the [Ávila day trip](/en/guides/madrid/avila-day-trip-from-madrid)) and **Alcalá de Henares** (Cervantes' birthplace, fewer visitors). With only one day, choose Toledo. Still torn between Toledo and Segovia? [Toledo or Segovia?](/en/guides/madrid/toledo-or-segovia-from-madrid) compares the two trips side by side.
