import Image from "next/image";
import Link from "next/link";
import BuscadorDestino, { type OpcionDestino } from "./BuscadorDestino";
import type { Idioma } from "@/lib/i18n/types";
import { urlPlanificador } from "@/lib/planificador";

const DICT = {
  es: {
    antetitulo: "Expertos locales · Reserva segura",
    titulo: "Tours, actividades y guías de España, con criterio",
    subtitulo:
      "Actividades seleccionadas, guías escritas por expertos locales y reserva segura en un solo lugar.",
    etiqueta: "¿A dónde vas?",
    placeholder: "Madrid, Granada, Tenerife…",
    boton: "Buscar",
    verDestinos: "O explora todos los destinos",
    planificador: "¿No sabes qué hacer? Prueba el planificador",
  },
  en: {
    antetitulo: "Local experts · Secure booking",
    titulo: "Spain tours, activities and travel guides, chosen with care",
    subtitulo:
      "Hand-picked activities, guides written by local experts and secure booking in one place.",
    etiqueta: "Where are you going?",
    placeholder: "Madrid, Granada, Tenerife…",
    boton: "Search",
    verDestinos: "Or browse all destinations",
    planificador: "Not sure what to do? Try the trip planner",
  },
  de: {
    antetitulo: "Lokale Experten · Sichere Buchung",
    titulo: "Touren, Aktivitäten und Reiseführer für Spanien – mit Bedacht gewählt",
    subtitulo:
      "Ausgewählte Aktivitäten, Reiseführer von lokalen Experten und sichere Buchung an einem Ort.",
    etiqueta: "Wohin geht die Reise?",
    placeholder: "Madrid, Granada, Teneriffa…",
    boton: "Suchen",
    verDestinos: "Oder alle Reiseziele ansehen",
    planificador: "Unsicher, was ihr machen sollt? Probier den Reiseplaner",
  },
  fr: {
    antetitulo: "Experts locaux · Réservation sécurisée",
    titulo: "Visites et activités en Espagne, choisies avec soin",
    subtitulo:
      "Des activités sélectionnées, des conseils d’experts locaux et une réservation sécurisée, au même endroit.",
    etiqueta: "Où allez-vous ?",
    placeholder: "Madrid, Grenade, Tenerife…",
    boton: "Rechercher",
    verDestinos: "Ou parcourez toutes les destinations",
    planificador: "Vous ne savez pas quoi faire ? Essayez le planificateur",
  },
  it: {
    antetitulo: "Esperti locali · Prenotazione sicura",
    titulo: "Tour e attività in Spagna, scelti con cura",
    subtitulo:
      "Attività selezionate, consigli di esperti locali e prenotazione sicura in un unico posto.",
    etiqueta: "Dove vai?",
    placeholder: "Madrid, Granada, Tenerife…",
    boton: "Cerca",
    verDestinos: "Oppure esplora tutte le destinazioni",
    planificador: "Non sai cosa fare? Prova il pianificatore",
  },
  pt: {
    antetitulo: "Especialistas locais · Reserva segura",
    titulo: "Tours e atividades em Espanha, escolhidos com critério",
    subtitulo:
      "Atividades selecionadas, conselhos de especialistas locais e reserva segura num só lugar.",
    etiqueta: "Para onde vai?",
    placeholder: "Madrid, Granada, Tenerife…",
    boton: "Pesquisar",
    verDestinos: "Ou explore todos os destinos",
    planificador: "Não sabe o que fazer? Experimente o planeador",
  },
} as const satisfies Record<Idioma, Record<string, string | null>>;

type Props = {
  idioma: Idioma;
  opciones: ReadonlyArray<OpcionDestino>;
  urlTodos: string;
  anclaDestinos: string;
};

export default function HeroHome({
  idioma,
  opciones,
  urlTodos,
  anclaDestinos,
}: Props) {
  const t = DICT[idioma];

  return (
    <section className="relative isolate overflow-hidden text-white">
      <Image
        src="/images/home/hero.jpg"
        alt=""
        fill
        priority
        sizes="100vw"
        className="object-cover object-[center_40%] -z-10"
      />
      {/* Velo oscuro hacia la izquierda: el texto siempre pasa contraste AA */}
      <div
        className="absolute inset-0 -z-10 bg-gradient-to-r from-piedra-900/85 via-piedra-900/60 to-piedra-900/20"
        aria-hidden="true"
      />
      <div className="max-w-6xl mx-auto px-4 py-20 md:py-28">
        <p className="text-xs md:text-sm font-semibold uppercase tracking-widest text-anil-200 mb-4">
          {t.antetitulo}
        </p>
        <h1 className="font-fraunces text-4xl md:text-6xl font-bold leading-tight max-w-3xl mb-5">
          {t.titulo}
        </h1>
        <p className="text-lg md:text-xl text-anil-50 leading-relaxed max-w-xl mb-9">
          {t.subtitulo}
        </p>
        <BuscadorDestino
          opciones={opciones}
          urlTodos={urlTodos}
          etiqueta={t.etiqueta}
          placeholder={t.placeholder}
          boton={t.boton}
        />
        <div className="mt-5 flex flex-wrap gap-x-6 gap-y-2">
          <Link
            href={anclaDestinos}
            prefetch={false}
            className="inline-flex items-center text-sm font-semibold text-anil-100 hover:text-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-piedra-900 rounded"
          >
            {t.verDestinos} →
          </Link>
          {t.planificador && (
            <Link
              href={urlPlanificador(idioma)}
              prefetch={false}
              className="inline-flex items-center text-sm font-semibold text-azafran-300 hover:text-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-piedra-900 rounded"
            >
              {t.planificador} →
            </Link>
          )}
        </div>
      </div>
    </section>
  );
}
