import type { Idioma } from "@/lib/i18n/types";
import { formatearPrecioBokun, type PrecioGrupo } from "@/lib/reservaBokun";
import { tramosCoherentes } from "@/lib/precioComparable";

type Props = {
  precios: ReadonlyArray<PrecioGrupo> | undefined;
  moneda?: string;
  idioma: Idioma;
};

const TEXTOS = {
  es: {
    titulo: "Precio por persona según cuántos seáis",
    personas: (n: number) => (n === 1 ? "1 persona" : `${n} personas`),
    porPersona: "/pers.",
    total: "total",
    nota: "En grande, lo que sale por persona; debajo, el total del grupo. Puede variar según la fecha.",
  },
  en: {
    titulo: "Price per person by group size",
    personas: (n: number) => (n === 1 ? "1 person" : `${n} people`),
    porPersona: "/person",
    total: "total",
    nota: "Large figure: price per person; below: total for the group. It may vary by date.",
  },
  de: {
    titulo: "Preis pro Person nach Gruppengröße",
    personas: (n: number) => (n === 1 ? "1 Person" : `${n} Personen`),
    porPersona: "/Pers.",
    total: "gesamt",
    nota: "Groß: Preis pro Person; darunter: Gesamtpreis der Gruppe. Kann je nach Datum variieren.",
  },
  fr: {
    titulo: "Prix par personne selon la taille du groupe",
    personas: (n: number) => (n === 1 ? "1 personne" : `${n} personnes`),
    porPersona: "/pers.",
    total: "au total",
    nota: "En grand : le prix par personne ; en dessous : le total pour le groupe. Il peut varier selon la date.",
  },
  it: {
    titulo: "Prezzo a persona in base a quanti siete",
    personas: (n: number) => (n === 1 ? "1 persona" : `${n} persone`),
    porPersona: "/pers.",
    total: "in totale",
    nota: "In grande il prezzo a persona; sotto, il totale per il gruppo. Può variare in base alla data.",
  },
  pt: {
    titulo: "Preço por pessoa consoante o tamanho do grupo",
    personas: (n: number) => (n === 1 ? "1 pessoa" : `${n} pessoas`),
    porPersona: "/pess.",
    total: "no total",
    nota: "Em destaque, o preço por pessoa; por baixo, o total do grupo. Pode variar consoante a data.",
  },
} as const satisfies Record<Idioma, unknown>;

/**
 * Privadas con precio por grupo: quien llega desde un anuncio compara con
 * excursiones en grupo, que se anuncian por persona. Enseñamos el total y lo
 * que sale por persona para 2, 4 y 6 (o los tamaños que haya en Bókun).
 */
export default function PreciosPorGrupo({ precios: preciosBrutos, moneda, idioma }: Props) {
  const precios = preciosBrutos ? tramosCoherentes(preciosBrutos) : undefined;
  if (!precios || precios.length < 2) return null;
  const t = TEXTOS[idioma];

  return (
    <div className="w-full rounded-lg border border-piedra-200 bg-white p-3">
      <p className="text-xs font-semibold uppercase tracking-wider text-piedra-500 mb-2">
        {t.titulo}
      </p>
      <ul className="grid grid-cols-3 gap-2">
        {precios.slice(0, 3).map((p) => (
          <li key={p.personas} className="rounded-md bg-piedra-50 px-2 py-2 text-center">
            <span className="block text-xs text-piedra-600">{t.personas(p.personas)}</span>
            <span className="block text-base font-bold text-piedra-900">
              {formatearPrecioBokun(Math.round(p.total / p.personas), moneda, idioma)}
              <span className="text-xs font-normal text-piedra-500">{t.porPersona}</span>
            </span>
            <span className="block text-xs text-piedra-500">
              {formatearPrecioBokun(p.total, moneda, idioma)} {t.total}
            </span>
          </li>
        ))}
      </ul>
      <p className="mt-2 text-xs text-piedra-500">{t.nota}</p>
    </div>
  );
}
