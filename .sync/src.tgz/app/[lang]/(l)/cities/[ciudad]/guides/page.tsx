import type { Metadata } from "next";
import { urlListadoActividadesSiExiste } from "@/lib/actividades";
import { notFound } from "next/navigation";
import Link from "next/link";
import { obtenerCiudad } from "@/lib/ciudades";
import {
  obtenerCiudadesConGuias,
  obtenerGuiasDeCiudad,
} from "@/lib/guias";
import {
  esIdiomaActivo,
  IDIOMAS_ACTIVOS,
  IDIOMA_LOCALE,
} from "@/lib/i18n/config";
import { getDictionary } from "@/lib/i18n/getDictionary";
import { slugParejaCiudad } from "@/lib/i18n/slugs";
import {
  formatearFecha,
  hreflangAlternates,
  prefijoIdioma,
  urlActividadesDeCiudad,
  urlCiudad,
  urlGuiasDeCiudad,
  urlIndiceCiudades,
} from "@/lib/i18n/utils";
import type { Idioma } from "@/lib/i18n/types";
import { ampliarDescripcion, resumenActividades, resumenGuias } from "@/lib/metaDescripcion";

const SITE_URL =
  process.env.NEXT_PUBLIC_SITE_URL || "https://www.exploraspain.com";

type Props = {
  params: { lang: string; ciudad: string };
};

export async function generateStaticParams() {
  const caminos: { lang: string; ciudad: string }[] = [];
  for (const lang of IDIOMAS_ACTIVOS) {
    if (lang === "es") continue;
    for (const { ciudad } of obtenerCiudadesConGuias(lang)) {
      caminos.push({ lang, ciudad });
    }
  }
  return caminos;
}

type Strings = {
  titulo: string;
  descripcion: string;
  volver: string;
  guias: string;
};

const STRINGS: Record<Idioma, (nombreCiudad: string) => Strings> = {
  es: (c) => ({
    titulo: `Guías de ${c}`,
    descripcion: `Rutas con criterio y consejos prácticos para conocer ${c} sin postales.`,
    volver: `Ver actividades en ${c} →`,
    guias: "Guías",
  }),
  en: (c) => ({
    titulo: `Guides for ${c}`,
    descripcion: `Honest itineraries and practical advice to explore ${c} without the tourist clichés.`,
    volver: `See activities in ${c} →`,
    guias: "Guides",
  }),
  de: (c) => ({
    titulo: `Reiseführer für ${c}`,
    descripcion: `Ehrliche Routen und praktische Tipps, um ${c} ohne Touristenklischees zu entdecken.`,
    volver: `Aktivitäten in ${c} ansehen →`,
    guias: "Reiseführer",
  }),
  fr: (c) => ({
    titulo: `Guides de ${c}`,
    descripcion: `Des itinéraires honnêtes et des conseils pratiques pour découvrir ${c} loin des clichés touristiques.`,
    volver: `Voir les activités à ${c} →`,
    guias: "Guides",
  }),
  it: (c) => ({
    titulo: `Guide di ${c}`,
    descripcion: `Itinerari onesti e consigli pratici per scoprire ${c} senza i soliti cliché turistici.`,
    volver: `Vedi le attività a ${c} →`,
    guias: "Guide",
  }),
  pt: (c) => ({
    titulo: `Guias de ${c}`,
    descripcion: `Roteiros honestos e conselhos práticos para conhecer ${c} sem os clichés turísticos.`,
    volver: `Ver atividades em ${c} →`,
    guias: "Guias",
  }),
};

function getStrings(lang: Idioma, nombreCiudad: string): Strings {
  return STRINGS[lang](nombreCiudad);
}

const NO_ENCONTRADA: Record<Idioma, string> = {
  es: "Página no encontrada",
  en: "Page not found",
  de: "Seite nicht gefunden",
  fr: "Page introuvable",
  it: "Pagina non trovata",
  pt: "Página não encontrada",
};

const ARIA_MIGAS: Record<Idioma, string> = {
  es: "Migas de pan",
  en: "Breadcrumb",
  de: "Brotkrumen",
  fr: "Fil d’Ariane",
  it: "Percorso di navigazione",
  pt: "Navegação estrutural",
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  if (!esIdiomaActivo(params.lang) || params.lang === "es") {
    return { title: "Not found" };
  }
  const lang: Idioma = params.lang;
  const ciudad = await obtenerCiudad(lang, params.ciudad);
  if (!ciudad) return { title: "Not found" };

  // Mismo criterio que el componente de página (más abajo): sin guías
  // para este idioma+ciudad, la página hace notFound().
  if (obtenerGuiasDeCiudad(lang, params.ciudad).length === 0) {
    return { title: NO_ENCONTRADA[lang], robots: { index: false, follow: false } };
  }

  const url = `${SITE_URL}${urlGuiasDeCiudad(lang, params.ciudad)}`;
  const strings = getStrings(lang, ciudad.nombre);
  const metaDescripcion = ampliarDescripcion(strings.descripcion, [
    resumenGuias(lang, obtenerGuiasDeCiudad(lang, params.ciudad)),
  ]);
  const allowIndexing = process.env.NEXT_PUBLIC_ALLOW_INDEXING === "true";

  return {
    // Sin sufijo manual: el template "%s | ExploraSpain" del RootLayout ya lo añade.
    title: strings.titulo,
    description: metaDescripcion,
    robots: {
      index: allowIndexing,
      follow: allowIndexing,
    },
    alternates: {
      canonical: url,
      languages: hreflangAlternates((l) => {
        const slugPareja = slugParejaCiudad(lang, params.ciudad, l);
        // Solo los idiomas con guías publicadas en esta ciudad.
        return slugPareja && obtenerGuiasDeCiudad(l, slugPareja).length > 0
          ? urlGuiasDeCiudad(l, slugPareja)
          : null;
      }),
    },
    openGraph: {
      type: "website",
      url,
      title: `${strings.titulo} | ExploraSpain`,
      description: metaDescripcion,
      siteName: "ExploraSpain",
      locale: IDIOMA_LOCALE[lang],
    },
  };
}

export default async function GuiasDeCiudadPage({ params }: Props) {
  if (!esIdiomaActivo(params.lang) || params.lang === "es") {
    notFound();
  }

  const lang: Idioma = params.lang;
  const dict = getDictionary(lang);
  const ciudad = await obtenerCiudad(lang, params.ciudad);
  if (!ciudad) notFound();

  const guias = obtenerGuiasDeCiudad(lang, params.ciudad);
  if (guias.length === 0) notFound();

  const strings = getStrings(lang, ciudad.nombre);
  const homeUrl = `${SITE_URL}${prefijoIdioma(lang) || "/"}`;
  const indiceCiudadesUrl = `${SITE_URL}${urlIndiceCiudades(lang)}`;
  const ciudadUrl = `${SITE_URL}${ciudad.url}`;
  const indiceGuiasCiudadUrl = `${SITE_URL}${urlGuiasDeCiudad(lang, params.ciudad)}`;

  const breadcrumbsLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: dict.navegacion.inicio, item: homeUrl },
      { "@type": "ListItem", position: 2, name: dict.navegacion.ciudades, item: indiceCiudadesUrl },
      { "@type": "ListItem", position: 3, name: ciudad.nombre, item: ciudadUrl },
      { "@type": "ListItem", position: 4, name: strings.guias, item: indiceGuiasCiudadUrl },
    ],
  };

  return (
    <main className="min-h-screen bg-white">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbsLd) }}
      />

      <header className="bg-anil-500 text-white py-12 md:py-16">
        <div className="max-w-3xl mx-auto px-4">
          <nav aria-label={ARIA_MIGAS[lang]} className="text-sm text-anil-100 mb-4">
            <Link href={prefijoIdioma(lang) || "/"} className="hover:text-white">
              {dict.navegacion.inicio}
            </Link>
            {" › "}
            <Link href={urlIndiceCiudades(lang)} className="hover:text-white">
              {dict.navegacion.ciudades}
            </Link>
            {" › "}
            <Link href={urlCiudad(lang, params.ciudad)} className="hover:text-white">
              {ciudad.nombre}
            </Link>
            {" › "}
            <span className="text-white">{strings.guias}</span>
          </nav>

          <h1 className="font-fraunces text-3xl md:text-5xl font-bold mb-3 leading-tight">
            {strings.titulo}
          </h1>
          <p className="text-lg md:text-xl text-anil-50">{strings.descripcion}</p>
        </div>
      </header>

      <section className="max-w-5xl mx-auto px-4 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {guias.map((guia) => (
            <Link
              key={guia.url}
              href={guia.url}
              className="group block border border-piedra-200 rounded-lg p-6 hover:border-anil-400 hover:shadow-md transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-anil-500 focus-visible:ring-offset-2"
            >
              <span className="inline-block bg-anil-100 text-anil-700 text-xs font-semibold uppercase tracking-wider px-2 py-1 rounded mb-3">
                {ciudad.nombre}
              </span>
              <h2 className="font-fraunces text-xl md:text-2xl font-bold text-piedra-900 mb-2 group-hover:text-anil-700 transition-colors">
                {guia.titulo}
              </h2>
              <p className="text-piedra-600 leading-relaxed mb-4">
                {guia.descripcion}
              </p>
              <div className="flex items-center justify-between text-xs text-piedra-500">
                <span>{formatearFecha(guia.fecha, lang)}</span>
                <span>
                  {guia.tiempoLectura} {dict.guias.minutosLectura}
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {urlListadoActividadesSiExiste(lang, params.ciudad) ? (
        <div className="max-w-3xl mx-auto px-4 py-12 text-center">
          <Link
            href={urlActividadesDeCiudad(lang, params.ciudad)}
            className="text-anil-600 hover:text-anil-700 font-semibold"
          >
            {strings.volver}
          </Link>
        </div>
      ) : null}
    </main>
  );
}
