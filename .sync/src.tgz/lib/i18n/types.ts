import { IDIOMAS_CONFIGURADOS } from "./config";

export type Idioma = (typeof IDIOMAS_CONFIGURADOS)[number];

export type SegmentosUrl = {
  guias: string;
  ciudades: string;
  actividades: string;
  atracciones: string;
  avisoLegal: string;
  privacidad: string;
  cookies: string;
  contacto: string;
};

export type Diccionario = {
  meta: {
    sitioNombre: string;
    sitioDescripcion: string;
  };
  navegacion: {
    inicio: string;
    guias: string;
    ciudades: string;
    sobreNosotros: string;
    contacto: string;
    abrirMenu: string;
    cerrarMenu: string;
    cambiarIdioma: string;
  };
  home: {
    heroTitulo: string;
    heroSubtitulo: string;
    ctaExplorar: string;
    seccionGuiasDestacadas: string;
    seccionCiudades: string;
    verTodas: string;
  };
  guias: {
    tituloIndice: string;
    descripcionIndice: string;
    minutosLectura: string;
    publicadoEl: string;
    autorPor: string;
    relacionadas: string;
    volverAGuias: string;
  };
  ciudades: {
    tituloIndice: string;
    descripcionIndice: string;
    verCiudad: string;
    guiasDeCiudad: string;
    volverACiudades: string;
  };
  actividades: {
    tituloIndiceCiudad: string;
    descripcionIndiceCiudad: string;
    verActividad: string;
    actividadesEnCiudad: string;
    desde: string;
    porPersona: string;
    duracion: string;
    idiomas: string;
    cancelacionGratuita: string;
    cancelacionHorasAntes: string;
    sinColas: string;
    reservar: string;
    viaProveedor: string;
    highlights: string;
    nuestraOpinion: string;
    queIncluye: string;
    queNoIncluye: string;
    puntoEncuentro: string;
    laExperiencia: string;
    guiasRelacionadas: string;
    alternativas: string;
    avisoAfiliacion: string;
    avisoVentaDirecta: string;
    valoracion: string;
    opiniones: string;
    categorias: {
      visitasGuiadas: string;
      entradas: string;
      toursCiudad: string;
      excursionesDia: string;
      toursGastronomicos: string;
      espectaculos: string;
      agua: string;
      aventura: string;
      parques: string;
      nocturno: string;
      talleres: string;
      /** Botón del filtro de privados (no es una categoría). */
      privados: string;
    };
    faqEnCiudad: string;
  };
  footer: {
    derechos: string;
    avisoLegal: string;
    privacidad: string;
    cookies: string;
    operadoPor: string;
  };
  comun: {
    cargando: string;
    error: string;
    leerMas: string;
  };
};
