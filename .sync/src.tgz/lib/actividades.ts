import fs from "fs";
import path from "path";
import matter from "gray-matter";
import { remark } from "remark";
import remarkGfm from "remark-gfm";
import remarkHtml from "remark-html";

import { IDIOMAS_ACTIVOS } from "./i18n/config";
import {
  urlActividad,
  urlActividadesDeCiudad,
  urlActividadesDeCiudadPorCategoria,
} from "./i18n/utils";
import type { Idioma } from "./i18n/types";
import {
  type ProveedorActividad,
  PROVEEDORES_ACTIVOS,
} from "./afiliados";
import type { PrecioGrupo } from "@/lib/reservaBokun";

const actividadesRoot = path.join(process.cwd(), "content", "actividades");

/**
 * Categorías permitidas. Debe coincidir con las claves de
 * `dict.actividades.categorias` en los diccionarios.
 *
 * Octubre 2026: 11 tipos de actividad; «privada» deja de ser categoría y
 * pasa a ser el campo `privada` (filtro «Privados» en la página de ciudad).
 *
 * Reemplazo (mayo 2026): pasamos de 6 categorías semánticas (cultural,
 * gastronomico, aireLibre, nocturno, excursion, familiar) a 7 comerciales
 * más visibles y orientadas a conversión.
 */
export const CATEGORIAS_ACTIVIDAD = [
  "visitasGuiadas",
  "entradas",
  "toursCiudad",
  "excursionesDia",
  "toursGastronomicos",
  "espectaculos",
  "agua",
  "aventura",
  "parques",
  "nocturno",
  "talleres",
] as const;

export type CategoriaActividad = (typeof CATEGORIAS_ACTIVIDAD)[number];

export type ActividadHighlight = string;

export type ImagenGaleria = {
  src: string;
  alt: string;
};

/**
 * Detalles prácticos granulares (8 datos máximo).
 * Todos los campos son opcionales: si no están en el frontmatter, no se
 * muestra esa fila. Permite reusar el mismo bloque para actividades muy
 * distintas sin que falten datos a medias.
 */
export type DetallesPracticos = {
  ticketMovil?: boolean;
  confirmacionInmediata?: boolean;
  accesibleSilla?: boolean;
  edadMinima?: number;
  mascotasPermitidas?: boolean;
};

/**
 * Información importante mostrada en 3 columnas (Qué traer / No apto para
 * / A tener en cuenta). Cualquiera puede estar vacía o ausente.
 */
export type InformacionImportante = {
  queTraer?: string[];
  noAptoPara?: string[];
  aTenerEnCuenta?: string[];
};

/**
 * Punto de encuentro detallado con coordenadas para el mapa.
 * Sustituye/complementa al string `puntoEncuentro` original.
 *
 * Si en el frontmatter solo hay `puntoEncuentro: "texto"` (string), se
 * normaliza a `{ texto: "..." }` sin coordenadas: el mapa simplemente
 * no se renderizará para esa actividad.
 */
export type PuntoEncuentroDetallado = {
  texto: string;
  descripcionGuia?: string;
  latitud?: number;
  longitud?: number;
  zoom?: number;
};

export type PreguntaFrecuente = {
  pregunta: string;
  respuesta: string;
};

export type ActividadFrontmatter = {
  titulo: string;
  slug: string;
  ciudad: string;
  descripcion: string;

  /**
   * Title HTML para SEO. Si no se define, se usa `titulo` como fallback.
   * Útil cuando el H1 en pantalla y el <title> óptimo en SERP difieren
   * (e.g. H1 corto y limpio vs <title> con marca y keyword extra).
   * Recomendado: 50-60 caracteres incluyendo "| ExploraSpain".
   */
  metaTitle?: string;

  /**
   * Meta description HTML para SEO. Si no se define, se usa `descripcion`
   * como fallback. Permite afinar el snippet de SERP sin tocar la copy
   * editorial de la ficha. Recomendado: 150-160 caracteres con CTA.
   */
  metaDescription?: string;

  // Datos comerciales
  duracion: string;
  duracionMinutos?: number;
  precioDesde: number;
  moneda: string;
  idiomas: string[];
  proveedor: ProveedorActividad;
  urlReserva: string;
  /**
   * ID de producto/experiencia en Bokun (solo `proveedor: bokun`).
   * Alimenta el data-src del widget embebido de reserva. Se ignora para
   * el resto de proveedores, que usan `urlReserva`.
   */
  bokunProductId?: number;
  cancelacionGratuita?: boolean;
  horasCancelacion?: number;
  /**
   * Mínimo de personas por reserva cuando el precio es por persona
   * (ej. visitas privadas "mínimo 2"). Se muestra junto al precio "desde"
   * para que el visitante que llega desde un anuncio no se lleve sorpresas.
   */
  minimoPersonas?: number;
  /**
   * El calendario de Bókun arranca por debajo del mínimo y se ve vacío:
   * se muestra un aviso para que el cliente elija el número de personas.
   */
  bokunPedirPersonas?: boolean;
  /** Actividad solo para el grupo del cliente (tour privado). Filtro «Privados». */
  privada?: boolean;
  /** El precio «desde» es por grupo, no por persona. */
  precioPorGrupo?: boolean;
  /**
   * Privadas: total del grupo según cuántos sois (de los precios reales de
   * Bókun). Sirve para enseñar el precio por persona, que es como compara
   * quien llega de un anuncio. Ordenado de menos a más personas.
   */
  preciosGrupo?: PrecioGrupo[];

  // Vendedor
  highlights: ActividadHighlight[];

  // Práctico
  incluye: string[];
  noIncluye: string[];
  /**
   * Punto de encuentro. Acepta dos formatos:
   *   - string plano (formato original, retrocompatible)
   *   - objeto PuntoEncuentroDetallado (recomendado para nuevas actividades)
   * Tras pasar por `construirListItem` siempre queda como objeto.
   */
  puntoEncuentro: string | PuntoEncuentroDetallado;

  // === Bloques nuevos (mejoras inspiradas en Civitatis y GetYourGuide) ===
  detallesPracticos?: DetallesPracticos;
  informacionImportante?: InformacionImportante;
  accesibilidad?: string;
  politicaCancelacion?: string;
  preguntasFrecuentes?: PreguntaFrecuente[];
  /**
   * Slugs de OTRAS actividades publicadas en la misma ciudad que se
   * mostrarán en el carrusel "Otras formas de visitar X". Si la lista
   * está vacía o los slugs no resuelven a una actividad publicada, el
   * bloque no aparece.
   */
  variantes?: string[];

  // Editorial
  opinionEditorial?: string;
  /**
   * Aviso de disponibilidad, cierto y estático (p. ej. «Las entradas de la
   * Alhambra se agotan con semanas de antelación»). Nunca contadores
   * inventados. Se muestra sobre la barra de reserva en móvil y bajo el
   * precio en escritorio.
   */
  avisoReserva?: string;
  /**
   * Otra ficha de la misma ciudad (slug del mismo idioma) que ofrecer cuando
   * esta suele agotarse o hay una opción claramente mejor. `motivo` es una
   * frase cierta y estática: nunca fechas ni plazas inventadas.
   */
  alternativa?: AlternativaReserva;
  guiasRelacionadas?: string[];

  // Categorización
  categoria: CategoriaActividad;
  keywords?: string[];

  /**
   * Tags de atracciones / temas con los que la actividad está relacionada.
   * Se usan para los chips de filtrado en la página de ciudad. El listado
   * de tags válidos por ciudad se define en `chipsFiltros` del frontmatter
   * de la ciudad. Una actividad puede pertenecer a varios tags a la vez.
   *
   * Ejemplos: "museo-prado", "palacio-real", "excursiones-desde-madrid",
   * "tapas-madrid", "sagrada-familia", "park-guell".
   */
  atraccionesRelacionadas?: string[];
  /**
   * Otras ciudades en cuya página de actividades debe listarse también esta
   * ficha (p. ej. una excursión a Girona que sale de Barcelona). La ficha
   * sigue teniendo una sola URL, la de su carpeta: no se duplica contenido.
   */
  ciudadesAdicionales?: string[];

  // Imágenes
  imagen: string;
  imagenAlt: string;
  galeria?: ImagenGaleria[];

  // SEO/JSON-LD
  ratingProveedor?: number;
  numeroOpiniones?: number;

  // Estado
  publicada: boolean;
  destacada?: boolean;
  /**
   * Entre las que más reservas nos han dado (panel de GYG / Bókun). Se marca a
   * mano y solo con ventas reales: muestra la etiqueta «Lo más reservado».
   */
  masReservado?: boolean;
  /**
   * `false` = publicada pero fuera de Google (`noindex, follow` y fuera del
   * sitemap). Sigue en listados, guías y con su botón de reserva. Se usa para
   * fichas que duplican a otra mejor de la misma atracción (recorte del
   * 27 oct 2026, ver `recorte-indexacion-2026-10-27.xlsx`). Por defecto, indexable.
   */
  indexar?: boolean;
  fecha: string;
  /**
   * Fecha de última actualización editorial (ISO YYYY-MM-DD).
   * Útil para señalar a Google que el contenido se mantiene fresco.
   * Si no se define, no aparece en JSON-LD ni se muestra en pantalla.
   */
  fecha_actualizacion?: string;

  /**
   * Mapa de slugs por idioma para esta actividad. Permite que el sitemap
   * y los pages declaren hreflang correcto cuando los slugs están
   * traducidos entre idiomas (e.g. ES "tour-prado" ↔ EN "prado-tour").
   * Si el campo no existe, no se asume pareja: el alternate hreflang se
   * omite para los idiomas no declarados (mejor que apuntar a un 404).
   */
  slugs?: Partial<Record<Idioma, string>>;
};

/**
 * Versión normalizada del frontmatter tal y como la consume la UI:
 * `puntoEncuentro` es siempre un objeto, los arrays nunca son undefined,
 * etc. Esto simplifica el render en el page sin defensive coding.
 */
export type AlternativaReserva = { slug: string; motivo: string };

function normalizarAlternativa(valor: unknown): AlternativaReserva | undefined {
  if (!valor || typeof valor !== "object") return undefined;
  const { slug, motivo } = valor as Record<string, unknown>;
  if (typeof slug !== "string" || typeof motivo !== "string") return undefined;
  if (!slug.trim() || !motivo.trim()) return undefined;
  return { slug: slug.trim(), motivo: motivo.trim() };
}

export type ActividadListItem = Omit<ActividadFrontmatter, "puntoEncuentro"> & {
  idioma: Idioma;
  url: string;
  puntoEncuentro: PuntoEncuentroDetallado;
};

export type ActividadCompleta = ActividadListItem & {
  contenidoHtml: string;
};

function directorioCiudad(idioma: Idioma, ciudad: string): string {
  return path.join(actividadesRoot, idioma, ciudad);
}

/**
 * Lista todas las actividades publicadas de una ciudad para un idioma dado.
 * Devuelve array vacío si la carpeta no existe (ciudad sin actividades aún).
 */
export function obtenerListaActividadesPorCiudad(
  idioma: Idioma,
  ciudad: string
): ActividadListItem[] {
  const base = directorioCiudad(idioma, ciudad);
  if (!fs.existsSync(base)) return [];

  const archivos = fs.readdirSync(base).filter((f) => f.endsWith(".md"));
  const actividades: ActividadListItem[] = [];

  for (const archivo of archivos) {
    const slug = archivo.replace(/\.md$/, "");
    const fullPath = path.join(base, archivo);
    const fileContents = fs.readFileSync(fullPath, "utf8");
    const { data } = matter(fileContents);

    const fm = data as Partial<ActividadFrontmatter>;
    if (!fm.publicada) continue;

    actividades.push(construirListItem(fm, slug, ciudad, idioma));
  }

  // Orden: destacadas primero, luego por fecha descendente.
  return actividades.sort((a, b) => {
    if (a.destacada !== b.destacada) return a.destacada ? -1 : 1;
    return a.fecha < b.fecha ? 1 : a.fecha > b.fecha ? -1 : 0;
  });
}

/**
 * Devuelve una actividad concreta por idioma + ciudad + slug, con HTML
 * procesado. Devuelve null si no existe o no está publicada.
 */
export async function obtenerActividad(
  idioma: Idioma,
  ciudad: string,
  slug: string
): Promise<ActividadCompleta | null> {
  const fullPath = path.join(directorioCiudad(idioma, ciudad), `${slug}.md`);
  if (!fs.existsSync(fullPath)) return null;

  const fileContents = fs.readFileSync(fullPath, "utf8");
  const { data, content } = matter(fileContents);
  const fm = data as Partial<ActividadFrontmatter>;
  if (!fm.publicada) return null;

  const procesado = await remark()
    .use(remarkGfm)
    .use(remarkHtml, { sanitize: false })
    .process(content);

  return {
    ...construirListItem(fm, slug, ciudad, idioma),
    contenidoHtml: procesado.toString(),
  };
}

/**
 * Lista TODAS las actividades de un idioma (de todas las ciudades).
 * Útil para el sitemap.
 */
export function obtenerListaActividades(idioma: Idioma): ActividadListItem[] {
  const base = path.join(actividadesRoot, idioma);
  if (!fs.existsSync(base)) return [];

  const ciudades = fs.readdirSync(base).filter((entry) => {
    const fullPath = path.join(base, entry);
    return fs.statSync(fullPath).isDirectory();
  });

  const todas: ActividadListItem[] = [];
  for (const ciudad of ciudades) {
    todas.push(...obtenerListaActividadesPorCiudad(idioma, ciudad));
  }

  return todas;
}

/**
 * Actividades a mostrar en la página de actividades de una ciudad: las suyas
 * más las de otras ciudades que declaran esta en `ciudadesAdicionales`.
 * Las añadidas conservan su URL original (una sola ficha por actividad).
 */
export function obtenerActividadesParaPaginaCiudad(
  idioma: Idioma,
  ciudad: string
): ActividadListItem[] {
  const propias = obtenerListaActividadesPorCiudad(idioma, ciudad);
  const ajenas = obtenerListaActividades(idioma).filter(
    (a) => a.ciudad !== ciudad && a.ciudadesAdicionales?.includes(ciudad)
  );
  return [...propias, ...ajenas];
}

/**
 * Devuelve actividades destacadas de una ciudad (límite configurable).
 * Si no hay suficientes destacadas, completa con las más recientes.
 */
export function obtenerActividadesDestacadasPorCiudad(
  idioma: Idioma,
  ciudad: string,
  limite: number = 3
): ActividadListItem[] {
  const todas = obtenerListaActividadesPorCiudad(idioma, ciudad);
  const destacadas = todas.filter((a) => a.destacada);
  if (destacadas.length >= limite) return destacadas.slice(0, limite);
  return [...destacadas, ...todas.filter((a) => !a.destacada)].slice(0, limite);
}

/**
 * Selección curada de actividades "estrella" para la portada (home).
 *
 * Son las que promocionamos en Google Ads y mejor convierten, no un
 * surtido por ciudad. Se define por slug ES (única fuente de verdad);
 * para otros idiomas se resuelve automáticamente la ficha gemela vía
 * `slugs.es`, así no hay dos listas que mantener.
 *
 * Para cambiar la portada, edita SLUGS_ACTIVIDADES_HOME.
 */
const SLUGS_ACTIVIDADES_HOME: ReadonlyArray<{ ciudad: string; slug: string }> = [
  // Una actividad por atracción (sin repetir monumento) y todas publicadas:
  // si una se despublica, la portada muestra un hueco. Revisar al despublicar.
  { ciudad: "barcelona", slug: "entrada-sagrada-familia-audioguia" },
  { ciudad: "granada", slug: "visita-guiada-alhambra-generalife" },
  { ciudad: "madrid", slug: "museo-prado-entrada" },
  // Lo que más se reserva en GYG (oct-nov 2026): Caminito del Rey y Teide.
  { ciudad: "malaga", slug: "caminito-del-rey-guiado-desde-malaga" },
  { ciudad: "tenerife", slug: "teide-teleferico-traslado" },
  { ciudad: "sevilla", slug: "sevilla-3-monumentos-acceso-prioritario-catedral-giralda-alcazar" },
  { ciudad: "madrid", slug: "excursion-toledo-segovia-alcazar" },
  { ciudad: "sevilla", slug: "teatro-flamenco-sevilla-show-mas-vendido" },
];

export function obtenerActividadesHome(idioma: Idioma): ActividadListItem[] {
  const cachePorCiudad = new Map<string, ActividadListItem[]>();
  const resultado: ActividadListItem[] = [];

  for (const { ciudad, slug } of SLUGS_ACTIVIDADES_HOME) {
    if (!cachePorCiudad.has(ciudad)) {
      cachePorCiudad.set(ciudad, obtenerListaActividadesPorCiudad(idioma, ciudad));
    }
    const lista = cachePorCiudad.get(ciudad)!;
    // En ES el nombre del fichero es el slug; en otros idiomas se resuelve
    // la ficha gemela por su `slugs.es`.
    const item =
      idioma === "es"
        ? lista.find((a) => a.slug === slug)
        : lista.find((a) => a.slugs?.es === slug);
    if (item) resultado.push(item);
  }

  return resultado;
}

/**
 * Agrupa las actividades de una ciudad por categoría.
 * Útil para el listado tipo Viator (secciones por categoría).
 */
export function agruparActividadesPorCategoria(
  actividades: ActividadListItem[]
): Record<CategoriaActividad, ActividadListItem[]> {
  const grupos = {
    visitasGuiadas: [],
    entradas: [],
    toursCiudad: [],
    excursionesDia: [],
    toursGastronomicos: [],
    espectaculos: [],
    agua: [],
    aventura: [],
    parques: [],
    nocturno: [],
    talleres: [],
  } as Record<CategoriaActividad, ActividadListItem[]>;

  for (const actividad of actividades) {
    if (CATEGORIAS_ACTIVIDAD.includes(actividad.categoria)) {
      grupos[actividad.categoria].push(actividad);
    }
  }

  return grupos;
}

/**
 * Devuelve actividades alternativas dentro de la misma ciudad,
 * excluyendo la actual y excluyendo también las que ya estén listadas
 * como `variantes` de la actividad actual (para no duplicar tarjetas).
 */
export function obtenerActividadesAlternativas(
  idioma: Idioma,
  ciudad: string,
  slugActual: string,
  limite: number = 3,
  slugsExcluidos: string[] = []
): ActividadListItem[] {
  const exclusiones = new Set([slugActual, ...slugsExcluidos]);
  return obtenerListaActividadesPorCiudad(idioma, ciudad)
    .filter((a) => !exclusiones.has(a.slug))
    .slice(0, limite);
}

/**
 * Resuelve una lista de slugs de variantes a las actividades reales
 * publicadas en la misma ciudad e idioma. Mantiene el orden indicado en
 * el frontmatter. Slugs no resolubles se descartan silenciosamente.
 */
export function obtenerVariantesDeActividad(
  idioma: Idioma,
  ciudad: string,
  slugs: string[]
): ActividadListItem[] {
  if (!slugs || slugs.length === 0) return [];
  const todas = obtenerListaActividadesPorCiudad(idioma, ciudad);
  const indice = new Map(todas.map((a) => [a.slug, a]));
  return slugs
    .map((slug) => indice.get(slug))
    .filter((a): a is ActividadListItem => Boolean(a));
}

/**
 * Devuelve todos los caminos (idioma + ciudad + slug) de todas las
 * actividades publicadas en idiomas activos. Pensado para
 * generateStaticParams en /[lang]/cities/[ciudad]/activities/[slug].
 * Para la ruta española sin prefijo, filtrar por idioma === "es".
 */
export function obtenerTodosLosCaminosActividades(): {
  idioma: Idioma;
  ciudad: string;
  slug: string;
}[] {
  const caminos: { idioma: Idioma; ciudad: string; slug: string }[] = [];
  for (const idioma of IDIOMAS_ACTIVOS) {
    for (const actividad of obtenerListaActividades(idioma)) {
      caminos.push({
        idioma,
        ciudad: actividad.ciudad,
        slug: actividad.slug,
      });
    }
  }
  return caminos;
}

/**
 * Devuelve los slugs de ciudades que tienen al menos una actividad
 * publicada en el idioma indicado. Útil para generateStaticParams del
 * listado de actividades por ciudad.
 */
export function obtenerCiudadesConActividades(idioma: Idioma): string[] {
  const base = path.join(actividadesRoot, idioma);
  if (!fs.existsSync(base)) return [];

  return fs
    .readdirSync(base)
    .filter((entry) => {
      const fullPath = path.join(base, entry);
      return fs.statSync(fullPath).isDirectory();
    })
    .filter((ciudad) => {
      const lista = obtenerListaActividadesPorCiudad(idioma, ciudad);
      return lista.length > 0;
    });
}

/**
 * Normaliza el campo `puntoEncuentro` del frontmatter a su forma de
 * objeto. Acepta string plano (formato original) u objeto detallado
 * (formato nuevo). Si está vacío devuelve un objeto con texto vacío
 * para que el render no tenga que comprobar undefined.
 */
function normalizarPuntoEncuentro(
  raw: string | PuntoEncuentroDetallado | undefined
): PuntoEncuentroDetallado {
  if (!raw) return { texto: "" };
  if (typeof raw === "string") return { texto: raw };
  return {
    texto: raw.texto || "",
    descripcionGuia: raw.descripcionGuia,
    latitud: raw.latitud,
    longitud: raw.longitud,
    zoom: raw.zoom,
  };
}

/**
 * Construye un ActividadListItem a partir del frontmatter. Centralizado
 * para no repetir la lógica entre obtenerLista y obtenerActividad.
 *
 * Si el `proveedor` del frontmatter no es uno de los conocidos, se hace
 * fallback a "civitatis" (con warning en consola en build).
 */
function construirListItem(
  fm: Partial<ActividadFrontmatter>,
  slug: string,
  ciudad: string,
  idioma: Idioma
): ActividadListItem {
  const proveedorRaw = (fm.proveedor as unknown as string) || "civitatis";
  const proveedor = PROVEEDORES_ACTIVOS.includes(
    proveedorRaw as ProveedorActividad
  )
    ? (proveedorRaw as ProveedorActividad)
    : (() => {
        // eslint-disable-next-line no-console
        console.warn(
          `[actividades] Proveedor desconocido "${proveedorRaw}" en ${idioma}/${ciudad}/${slug}.md, usando "civitatis" por defecto.`
        );
        return "civitatis" as ProveedorActividad;
      })();

  return {
    titulo: fm.titulo || "Sin título",
    metaTitle: fm.metaTitle,
    metaDescription: fm.metaDescription,
    slug,
    ciudad,
    descripcion: fm.descripcion || "",

    duracion: fm.duracion || "",
    duracionMinutos: fm.duracionMinutos,
    precioDesde: fm.precioDesde ?? 0,
    moneda: fm.moneda || "EUR",
    idiomas: fm.idiomas || [],
    proveedor,
    urlReserva: fm.urlReserva || "",
    bokunProductId: fm.bokunProductId,
    cancelacionGratuita: fm.cancelacionGratuita ?? false,
    horasCancelacion: fm.horasCancelacion,
    minimoPersonas: fm.minimoPersonas,
    bokunPedirPersonas: fm.bokunPedirPersonas === true,
    privada: fm.privada === true,
    precioPorGrupo: fm.precioPorGrupo === true,
    preciosGrupo: leerPreciosGrupo(fm.preciosGrupo),

    highlights: fm.highlights || [],
    incluye: fm.incluye || [],
    noIncluye: fm.noIncluye || [],
    puntoEncuentro: normalizarPuntoEncuentro(fm.puntoEncuentro),

    detallesPracticos: fm.detallesPracticos,
    informacionImportante: fm.informacionImportante,
    accesibilidad: fm.accesibilidad,
    politicaCancelacion: fm.politicaCancelacion,
    preguntasFrecuentes: fm.preguntasFrecuentes || [],
    variantes: fm.variantes || [],

    opinionEditorial: fm.opinionEditorial,
    avisoReserva:
      typeof fm.avisoReserva === "string" && fm.avisoReserva.trim()
        ? fm.avisoReserva.trim()
        : undefined,
    alternativa: normalizarAlternativa(fm.alternativa),
    guiasRelacionadas: fm.guiasRelacionadas || [],

    categoria: (fm.categoria || "visitasGuiadas") as CategoriaActividad,
    keywords: fm.keywords || [],
    atraccionesRelacionadas: fm.atraccionesRelacionadas || [],
    ciudadesAdicionales: fm.ciudadesAdicionales || [],

    imagen: fm.imagen || "",
    imagenAlt: fm.imagenAlt || "",
    galeria: fm.galeria || [],

    ratingProveedor: fm.ratingProveedor,
    numeroOpiniones: fm.numeroOpiniones,

    publicada: true,
    destacada: fm.destacada || false,
    masReservado: fm.masReservado === true,
    fecha: fm.fecha || "",
    fecha_actualizacion: fm.fecha_actualizacion,
    slugs: fm.slugs,

    idioma,
    url: urlActividad(idioma, ciudad, slug),
  };
}

// =============================================================================
// Helpers para listado de actividades por categoría
// =============================================================================

/**
 * Mapeo categoría camelCase del frontmatter -> slug kebab-case en URL.
 * Único lugar que conoce esta correspondencia.
 *
 * Si en el futuro se añade una categoría nueva, hay que actualizar:
 *   1) CATEGORIAS_ACTIVIDAD (arriba en este archivo)
 *   2) este mapeo
 *   3) la clave en `dict.actividades.categorias` de los 6 idiomas
 */
export const CATEGORIA_A_URL: Record<CategoriaActividad, string> = {
  visitasGuiadas: "visitas-guiadas",
  entradas: "entradas",
  toursCiudad: "tours-por-la-ciudad",
  excursionesDia: "excursiones-de-un-dia",
  toursGastronomicos: "tours-gastronomicos",
  espectaculos: "espectaculos",
  agua: "barcos-y-actividades-acuaticas",
  aventura: "naturaleza-y-aventura",
  parques: "parques-tematicos",
  nocturno: "vida-nocturna",
  talleres: "talleres-y-experiencias",
};

const URL_A_CATEGORIA: Record<string, CategoriaActividad> = Object.fromEntries(
  (Object.entries(CATEGORIA_A_URL) as [CategoriaActividad, string][]).map(
    ([clave, urlSlug]) => [urlSlug, clave]
  )
) as Record<string, CategoriaActividad>;

/** Convierte clave de categoría (frontmatter) -> slug de URL. */
export function categoriaAUrl(categoria: CategoriaActividad): string {
  return CATEGORIA_A_URL[categoria];
}

/**
 * Convierte slug de URL -> clave de categoría (frontmatter).
 * Devuelve null si el slug no corresponde a ninguna categoría conocida.
 */
export function categoriaDesdeUrl(
  urlSlug: string
): CategoriaActividad | null {
  return URL_A_CATEGORIA[urlSlug] ?? null;
}

export type CategoriaConActividades = {
  /** Clave camelCase del frontmatter (ej: "aireLibre"). */
  categoria: CategoriaActividad;
  /** Slug kebab-case usado en URLs (ej: "aire-libre"). */
  urlSlug: string;
  /** Número de actividades publicadas en esa categoría/ciudad. */
  total: number;
  /** Imagen de portada: la primera actividad de la categoría. */
  imagenPortada: string;
  /** Alt de la imagen de portada. */
  imagenPortadaAlt: string;
};

/**
 * Devuelve las categorías que tienen >=1 actividad publicada en una
 * ciudad, con su contador e imagen de portada (la primera actividad del
 * grupo).
 *
 * Ordenadas por número de actividades descendente. Las categorías sin
 * actividades NO se devuelven (decisión de producto: nada de "(0)").
 *
 * Útil para construir el grid del índice de actividades de la ciudad.
 */
export function obtenerCategoriasConActividades(
  idioma: Idioma,
  ciudad: string
): CategoriaConActividades[] {
  const actividades = obtenerListaActividadesPorCiudad(idioma, ciudad);
  if (actividades.length === 0) return [];

  const grupos = agruparActividadesPorCategoria(actividades);

  const resultado: CategoriaConActividades[] = [];
  for (const categoria of CATEGORIAS_ACTIVIDAD) {
    const lista = grupos[categoria];
    if (lista.length === 0) continue;

    const portada = lista[0];
    resultado.push({
      categoria,
      urlSlug: CATEGORIA_A_URL[categoria],
      total: lista.length,
      imagenPortada: portada.imagen,
      imagenPortadaAlt: portada.imagenAlt,
    });
  }

  return resultado.sort((a, b) => b.total - a.total);
}

/**
 * Devuelve las actividades de una ciudad filtradas por una categoría
 * concreta. Devuelve array vacío si la combinación no tiene actividades.
 *
 * El orden se hereda de `obtenerListaActividadesPorCiudad`: destacadas
 * primero, luego por fecha descendente.
 */
export function obtenerActividadesDeCiudadPorCategoria(
  idioma: Idioma,
  ciudad: string,
  categoria: CategoriaActividad
): ActividadListItem[] {
  return obtenerListaActividadesPorCiudad(idioma, ciudad).filter(
    (a) => a.categoria === categoria
  );
}


/**
 * Comprueba si existe el archivo `.md` de una actividad en el idioma dado.
 *
 * Útil para construir alternates hreflang correctos: si una actividad
 * no tiene pareja en otro idioma (por ejemplo, una actividad solo
 * publicada en inglés), no debemos declarar un hreflang apuntando a
 * una URL que devolvería 404.
 *
 * No comprueba el flag `publicada`: solo la existencia física del
 * archivo. Si necesitas considerar también `publicada`, usa
 * `obtenerActividad` y comprueba si el resultado es `null`.
 */
export function existeActividad(
  idioma: Idioma,
  ciudad: string,
  slug: string
): boolean {
  const fullPath = path.join(directorioCiudad(idioma, ciudad), `${slug}.md`);
  return fs.existsSync(fullPath);
}


/**
 * URL del listado de actividades de una ciudad, solo si ese idioma tiene
 * actividades publicadas allí. Para hreflang y sitemap: evita declarar
 * alternativas que darían 404 (p. ej. `/de/cities/granada/activities`).
 */
export function urlListadoActividadesSiExiste(
  idioma: Idioma,
  ciudad: string
): string | null {
  return obtenerListaActividadesPorCiudad(idioma, ciudad).length > 0
    ? urlActividadesDeCiudad(idioma, ciudad)
    : null;
}

/** Igual que `urlListadoActividadesSiExiste`, para una categoría (slug de URL). */
export function urlCategoriaActividadesSiExiste(
  idioma: Idioma,
  ciudad: string,
  categoriaUrlSlug: string
): string | null {
  const categoria = categoriaDesdeUrl(categoriaUrlSlug);
  if (!categoria) return null;
  return obtenerActividadesDeCiudadPorCategoria(idioma, ciudad, categoria)
    .length > 0
    ? urlActividadesDeCiudadPorCategoria(idioma, ciudad, categoriaUrlSlug)
    : null;
}

/**
 * Mínimo de fichas para que una landing de categoría sea indexable y se
 * enlace desde el listado. Con menos, es contenido fino: `noindex, follow`.
 */
export const MIN_FICHAS_CATEGORIA_INDEXABLE = 4;

function leerPreciosGrupo(valor: unknown): PrecioGrupo[] | undefined {
  if (!Array.isArray(valor)) return undefined;
  const precios = valor
    .filter(
      (p): p is PrecioGrupo =>
        typeof p === "object" &&
        p !== null &&
        typeof (p as Record<string, unknown>).personas === "number" &&
        typeof (p as Record<string, unknown>).total === "number" &&
        (p as PrecioGrupo).personas > 0 &&
        (p as PrecioGrupo).total > 0
    )
    .sort((a, b) => a.personas - b.personas);
  return precios.length >= 2 ? precios : undefined;
}
