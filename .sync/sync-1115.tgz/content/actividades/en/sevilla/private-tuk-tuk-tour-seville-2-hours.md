---
titulo: 'Seville: 2-hour private grand tour by electric tuk tuk'
slug: private-tuk-tuk-tour-seville-2-hours
ciudad: sevilla
descripcion: 'Private 2-hour tour of Seville in an electric tuk tuk, just for your group (up to 4 people): Plaza de España, María Luisa Park, Torre del Oro, the Maestranza, Triana, Cartuja island and the Macarena, with photo stops. Book direct, price per group.'
slugs:
  es: tuk-tuk-privado-sevilla-2-horas
  en: private-tuk-tuk-tour-seville-2-hours
  fr: seville-grand-tour-tuk-tuk-electrique-prive-2-heures
duracion: 2 hours
duracionMinutos: 120
precioDesde: 124
moneda: EUR
idiomas:
- en
- es
proveedor: bokun
bokunProductId: 1154004
urlReserva: ''
cancelacionGratuita: true
horasCancelacion: 24
highlights:
- Electric tuk tuk just for your group, up to 4 people
- Plaza de España, María Luisa, Torre del Oro, Maestranza and Triana
- Cartuja island, the Macarena Basilica and the city walls
- Photo stops
- Price per group, not per person
incluye:
- Private 2-hour electric tuk tuk tour
- Local driver-guide in English or Spanish
- Digital guide with tips
- Photo stops
- Covers and blankets in rain or cold
noIncluye:
- Monument entry
- Tips
- Hotel pickup (not allowed by local rules)
puntoEncuentro:
  texto: Parking Saba Plaza de Armas, Calle Marqués de Paradas, Seville.
  descripcionGuia: 'Go down to level -1 of the car park and walk to the "Centro de Control": your driver will meet you there.'
  latitud: 37.3925
  longitud: -6.001
  zoom: 16
detallesPracticos:
  ticketMovil: true
  confirmacionInmediata: true
  accesibleSilla: false
  edadMinima: 2
  mascotasPermitidas: false
informacionImportante:
  queTraer:
  - Hat and sun protection
  - Camera
  noAptoPara:
  - Children under 2
  - Wheelchair users
  aTenerEnCuenta:
  - No hotel pickup
  - Monuments are seen from outside
accesibilidad: Not suitable for wheelchairs.
politicaCancelacion: Free cancellation up to 24 hours before, with a full refund.
preguntasFrecuentes:
- pregunta: How is it different from the 1-hour tour?
  respuesta: The 2-hour tour adds Cartuja island, the Macarena Basilica and the city walls, with more stops.
- pregunta: Is it good with kids?
  respuesta: 'Yes: they see all of Seville without walking or overheating. From age 2.'
- pregunta: Do you go inside monuments?
  respuesta: No, you see them from outside with photo stops.
- pregunta: Is there hotel pickup?
  respuesta: No, local rules don't allow it. You start from the Saba car park at Plaza de Armas.
- pregunta: Does it run in the rain?
  respuesta: Yes, it runs rain or shine, with covers and blankets.
opinionEditorial: Short on time in Seville? In two hours you see almost the whole city, including Cartuja and the Macarena, which are far on foot. With kids or in summer it's the comfiest option. You book it directly with us and the price is per group.
guiasRelacionadas:
- seville-with-kids
atraccionesRelacionadas:
- plaza-espana
- triana
- tuk-tuk
categoria: toursCiudad
keywords:
- seville tuk tuk 2 hours
- seville tuk tuk tour
- private tour seville
- seville by tuk tuk
imagen: https://imgcdn.bokun.tools/0ad6f0ff-d878-4b4b-ba5e-3d5fad09d269.png
imagenAlt: Family riding an electric tuk tuk through Seville
galeria:
- src: https://imgcdn.bokun.tools/1a40ce30-6ccc-4bdf-8bfe-bef06754265b.jpeg
  alt: Tuk tuk outside the Macarena Basilica
- src: https://imgcdn.bokun.tools/fd805ff9-dc13-4512-9134-7aba2cd79026.png
  alt: Electric tuk tuk outside the San Telmo Palace
- src: /images/actividades/sevilla/triana/triana-sevilla-bridge-spain-river-engineering-hero.webp
  alt: Triana bridge over the Guadalquivir
- src: /images/actividades/sevilla/plaza-espana/plaza-espana-pexels-34946149.webp
  alt: Plaza de España lit up at night
- src: https://imgcdn.bokun.tools/132aa0f1-236e-44f3-9f49-dcb9afc6cd23.png
  alt: Main gate of the Maestranza bullring
- src: https://imgcdn.bokun.tools/fa3608dd-4894-4077-8d27-446b7001fb40.jpeg
  alt: Torre del Oro among palm trees
- src: /images/actividades/sevilla/macarena/basilica-macarena-sevilla-exterior-20180719-hero.webp
  alt: White and yellow façade of the Macarena Basilica
- src: /images/actividades/sevilla/tuk-tuk/parque-maria-luisa.webp
  alt: Tree-lined avenue in María Luisa Park
publicada: true
indexar: false
destacada: false
fecha: '2026-10-05'
fecha_actualizacion: '2026-10-05'
privada: true
precioPorGrupo: true
# Totales de Bókun (primera fecha libre de noviembre), comprobados el 28-10-2026
preciosGrupo:
- personas: 2
  total: 155
- personas: 4
  total: 165
- personas: 6
  total: 320
---

## What you will do

- The **Plaza de España** and **María Luisa Park**.
- The **Torre del Oro**, the **Maestranza** and **Triana**.
- **Cartuja island**, the **Macarena** and the **city walls**.

## How it works

You book a day and time, go down to level -1 of the Saba car park at Plaza de Armas, and the driver takes you round for two hours in an electric tuk tuk just for your group, with photo stops.

If you'd rather go shorter, there's a [1-hour version](/en/cities/sevilla/activities/private-tuk-tuk-tour-seville).

## Who I recommend it for

- **Families with kids**.
- Anyone wanting to see **all of Seville** quickly.

## Who I don't recommend it for

- Anyone wanting to go inside monuments.
- Wheelchair users.
