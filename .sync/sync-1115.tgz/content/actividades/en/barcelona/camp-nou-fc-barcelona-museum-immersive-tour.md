---
titulo: 'Camp Nou: FC Barcelona Museum Barça Immersive Tour (Official Ticket)'
slug: camp-nou-fc-barcelona-museum-immersive-tour
ciudad: barcelona
descripcion: Official ticket to the FC Barcelona Museum with the Barça Immersive Tour during the Camp Nou renovation. 12,092 reviews at 4.3/5. STADIUM ITSELF NOT ACCESSIBLE (under renovation until 2027-2028).
slugs:
  es: camp-nou-museo-fc-barcelona-tour-inmersivo
  en: camp-nou-fc-barcelona-museum-immersive-tour
  de: barcelona-camp-nou-museum-barca-immersive-tour
  fr: camp-nou-musee-fc-barcelone-visite-immersive
  it: camp-nou-museo-fc-barcellona-tour-immersivo
  pt: camp-nou-museu-fc-barcelona-tour-imersivo
duracion: 1.5 - 2 hours (self-paced)
duracionMinutos: 90
precioDesde: 30.1
moneda: EUR
idiomas:
- es
- en
proveedor: getyourguide
urlReserva: https://www.getyourguide.com/barcelona-l45/barcelona-barca-immersive-exhibition-ticket-t449261/?partner_id=VPFQWBY&utm_medium=online_publisher&placement=content-middle
cancelacionGratuita: false
horasCancelacion: 0
highlights:
- Official ticket sold directly by FC Barcelona — 12,092 reviews at 4.3/5
- Audio guide in 13 languages (English, Spanish, Catalan, Chinese, etc.)
- Camp Nou Live 360° immersive room — recreates match-day atmosphere
- Construction Viewpoint to see the stadium being rebuilt
- Wheelchair accessible — fully adapted for visitors with reduced mobility
incluye:
- FC Barcelona Museum immersive tour entry ticket
- Digital audio guide in 13 languages
- Construction viewpoint of the stadium
- Robokeeper challenge (only if option selected — extra)
- Virtual reality experience (only if option selected — extra)
- Digital Memory (only if option selected — extra)
noIncluye:
- ACCESS TO THE SPOTIFY CAMP NOU STADIUM (closed for renovation 2026-2028)
- Food and drinks
- Pets (assistance dogs allowed)
- Hotel pickup
puntoEncuentro:
  texto: FC Barcelona Museum / Barça Immersive Tour, Carrer d'Aristides Maillol 12, 08028 Barcelona. The temporary exhibition is housed in a specially adapted space NEAR the Spotify Camp Nou (the stadium itself is closed). Show your mobile voucher at the entrance.
  descripcionGuia: 'The Barça Immersive Tour operates from a TEMPORARY space adjacent to the stadium during the renovation (2026-2028). Metro: Palau Reial or Maria Cristina (line 3), or Collblanc (lines 5, 9, 10) — 10-15 min walking. Bus 7, 33, 67, 75, H8, V1, V3 stop nearby. Taxi: ask for «Museu FC Barcelona, entrance to the temporary exhibition». IMPORTANT: the actual Spotify Camp Nou stadium is CLOSED to visitors throughout the renovation — you cannot enter the bowl, the field, the dugouts or the players'' tunnel. The current product is the museum + Camp Nou Live 360° room + Construction Viewpoint, NOT a stadium tour.'
  latitud: 41.3808
  longitud: 2.1204
  zoom: 17
detallesPracticos:
  ticketMovil: true
  confirmacionInmediata: true
  accesibleSilla: true
  edadMinima: 0
  mascotasPermitidas: false
informacionImportante:
  queTraer:
  - Charged smartphone (mobile voucher required)
  - Headphones (the audio device works but personal headphones are more comfortable)
  - Comfortable shoes
  noAptoPara:
  - Travellers expecting a STADIUM TOUR — the bowl is closed for renovation, only museum + construction viewpoint available
  - Visitors with epilepsy or photosensitivity (immersive 360° room has flashing lights)
  aTenerEnCuenta:
  - Camp Nou is under MAJOR renovation 2022-2028 — capacity will eventually be 105,000 (largest in Europe)
  - 'Match days: museum may have restricted hours or close — check before visiting'
  - The visit is fully adapted for people with reduced mobility and wheelchair users
  - Children under 4 join free but require a ticket (pick up at the ticket office)
  - Non-refundable — once booked, no cancellation
  - Robokeeper, Barça Virtual Dream, Digital Memory are paid add-ons — only included in the Total Experience Pass (t700918, ~€49)
  - '**Precio oficial en `fcbarcelona.com`: €28. En GYG: ~€32**'
accesibilidad: The visit is fully wheelchair accessible — FC Barcelona explicitly states it's adapted for people with reduced mobility. Lifts and ramps throughout the museum and viewpoint area. Assistance dogs allowed; other pets not. Children under 4 free.
politicaCancelacion: 'NON-refundable. Once booked, the ticket cannot be cancelled, refunded or rescheduled. Note: ticket is valid 1 day - 4 months from purchase, so you have flexibility on when to use it within that window — but the specific booking date can''t be moved retroactively.'
preguntasFrecuentes:
- pregunta: Can I visit the Camp Nou stadium itself?
  respuesta: NO — the Spotify Camp Nou stadium is closed to visitors due to renovation works (2022-2028). The current «Barça Immersive Tour» is housed in a temporary exhibition space adjacent to the stadium, NOT inside the stadium bowl. You CAN see the renovation works from the Construction Viewpoint (a designated observation deck), but you cannot enter the playing field, the dugouts, the players' tunnel, or the stands. This is the expected state until late 2027/early 2028 when the stadium is scheduled to reopen with full 105,000 capacity.
- pregunta: When will the full Camp Nou stadium tour resume?
  respuesta: FC Barcelona's published target is late 2027 or early 2028. The stadium is currently operating at 62,652 capacity (vs. 105,000 target) for matches following Phase 1C licence approval in March 2026. Tours of the stadium bowl will gradually return as renovation phases complete — most likely starting with restricted areas first. Until then, the «Barça Immersive Tour» is the only FC Barcelona experience available at the venue.
- pregunta: Is the immersive museum worth visiting if I'm not a football fan?
  respuesta: Reviews suggest YES, with caveats. The recurring sentiment from non-fans is «I don't watch football but the museum is genuinely impressive and emotional». The 360° Camp Nou Live room (recreating match-day atmosphere with crowd sounds, video projections, and tactile elements) is the most-praised element among non-fans. Football fans rate it consistently higher. If you have only 1 day in Barcelona and limited interest in football, skip; if you have 3+ days, it's a legitimate cultural experience.
- pregunta: Should I book this or the Total Experience Pass (t700918)?
  respuesta: This basic ticket (~€28) covers museum + audio guide + 360° room + construction viewpoint. The Total Experience Pass (t700918, ~€49) adds Robokeeper challenge (3 shots), Barça Virtual Dream VR experience, and a digital memory photo of your visit. The €21 difference is fair if you have kids who'd love the Robokeeper and VR (highly engaging for ages 6-14), or if you're a hardcore Barça fan wanting the full experience. For most adult casual visitors, the basic ticket is enough — the museum content is what justifies the visit, not the gamified extras.
variantes:
- camp-nou-fc-barcelona-museum-total-experience-pass
opinionEditorial: 'Official FC Barcelona Museum ticket during the Camp Nou renovation period (2022-2028) — 12,092 reviews at 4.3/5, sold directly by FC Barcelona. The product is honestly named: it''s a museum visit with the «Barça Immersive Tour» format (interactive exhibits, 360° room, construction viewpoint), NOT a stadium tour. The recurring positive sentiment focuses on the 360° Camp Nou Live room (matchday atmosphere recreation with crowd sounds and projections) and the museum''s emotional pull even for non-fans. The recurring complaint, predictably, is «I expected to see inside the stadium» — read the listing before booking.


  **Price comparison:** the official FC Barcelona website (`fcbarcelona.com`) sells the Basic Ticket at **€28**. GetYourGuide sells it at ~€32 (~$35) — €4 more for platform service. If you don''t have a GYG loyalty preference, book directly with `fcbarcelona.com` to save €4.


  Two operational notes: **(1)** the visit is fully wheelchair accessible (FC Barcelona explicitly states this). **(2)** the immersive 360° room includes flashing lights and is NOT recommended for visitors with epilepsy or photosensitivity. The Barça Virtual Dream, Robokeeper, and Digital Memory are paid add-ons NOT included in the basic ticket — if you want them, book the Total Experience Pass (t700918) instead which bundles them at ~€49.


  Who it''s for: FC Barcelona fans (must-do during the stadium renovation), football enthusiasts in general, cultural visitors with 3+ days in Barcelona, families with kids 8+ (museum is engaging for them, especially the 360° room), and travellers building a Barcelona itinerary that includes non-Gaudí experiences. Who it''s NOT for: travellers expecting a traditional stadium tour (the bowl is closed — read the listing), visitors with epilepsy (the 360° room is intense), and anyone in a rush (the visit needs 1.5-2 hours minimum to be worthwhile at this price).

  '
atraccionesRelacionadas:
- camp-nou
- futbol
categoria: entradas
keywords:
- camp nou museum ticket
- barca immersive tour
- fc barcelona museum
- camp nou renovation visit
- barca immersive exhibition
imagen: "/images/actividades/barcelona/camp-nou/fcb-prensa/museo-fcb-sala-inmersiva-360-messi.webp"
imagenAlt: "Visitors in the 360° immersive room of the FC Barcelona museum"
galeria:
- src: /images/actividades/barcelona/camp-nou/fcb-prensa/museo-fcb-sala-inmersiva-familias.webp
  alt: "Families in the immersive room watching a league title celebration"
- src: /images/actividades/barcelona/camp-nou/fcb-prensa/museo-fcb-pantallas-jugadores-familia.webp
  alt: "Family using the player touchscreens in the Barça museum"
- src: /images/actividades/barcelona/camp-nou/fcb-prensa/museo-fcb-sala-trofeos-champions.webp
  alt: "FC Barcelona's European Cups in lit display cases"
- src: /images/actividades/barcelona/camp-nou/fcb-prensa/museo-fcb-trofeos-champions-visitantes.webp
  alt: "Visitors before the European Cup and the trophy cabinet"
- src: /images/actividades/barcelona/camp-nou/fcb-prensa/museo-fcb-selfi-escudo.webp
  alt: "Friends taking a selfie in front of the FC Barcelona crest"
- src: /images/actividades/barcelona/camp-nou/fcb-prensa/museo-fcb-sala-balon-secciones.webp
  alt: "Giant ball room devoted to the club's other sports sections"
- src: /images/actividades/barcelona/camp-nou/fcb-prensa/museo-fcb-sala-la-masia.webp
  alt: "Visitors watching the La Masia audiovisual"
- src: /images/actividades/barcelona/camp-nou/fcb-prensa/museo-fcb-selfi-balon-socios.webp
  alt: "Family taking a selfie by the museum's giant ball"
- src: /images/actividades/barcelona/camp-nou/museo-barca-copas-champions.webp
  alt: Display case with the European Cups at the FC Barcelona Museum
- src: /images/actividades/barcelona/camp-nou/unsplash-FfGoHKPTV1s-hero.webp
  alt: Camp Nou stands spelling out FC Barcelona
- src: /images/actividades/barcelona/camp-nou/museo-barca-sala-visitantes.webp
  alt: Visitors walking through the FC Barcelona Museum halls
- src: /images/actividades/barcelona/camp-nou/images-hero.webp
  alt: Camp Nou pitch seen from above
- src: /images/actividades/barcelona/camp-nou/museo-barca-vitrina-trofeos.webp
  alt: Trophy cabinet at the FC Barcelona Museum
- src: /images/actividades/barcelona/camp-nou/wikimedia-estatua-de-ladislao-kubala-stecz-exteriores-do-camp-nou-barcelona-b32-hero.webp
  alt: Kubala statue outside Camp Nou
- src: /images/actividades/barcelona/camp-nou/obras-camp-nou-2024.webp
  alt: Spotify Camp Nou redevelopment works with cranes, 2024
- src: /images/actividades/barcelona/camp-nou/16979312785855-hero.webp
  alt: Aerial night view of the illuminated Spotify Camp Nou
- src: /images/actividades/barcelona/camp-nou/694f98298d5cb-hero.webp
  alt: Rendering of Spotify Camp Nou lit up at night
ratingProveedor: 4.3
numeroOpiniones: 12092
publicada: true
destacada: true
fecha: '2026-05-17'
fecha_actualizacion: '2026-10-25'
---

## What you'll see

Official FC Barcelona Museum visit with the «Barça Immersive Tour» format — interactive exhibits, 360° immersive room, construction viewpoint of the stadium under renovation. This is the only FC Barcelona experience available at the venue during the 2022-2028 renovation.

- **«We are history» immersive tunnel:** photographs, significant objects, and a dedicated space honoring Johan Cruyff.
- **«Tots units fem força» area:** interactive stations for both men's and women's first teams.
- **«More than Achievements» installation:** iconic moments, legendary players (Messi, Cruyff, Iniesta, etc.) and trophies, with immersive goal broadcasts and celebratory sounds.
- **Camp Nou Live 360° room:** the highlight — 360° audiovisual show placing you in the centre of the stadium, recreating match-day atmosphere from a unique vantage point.
- **Construction Viewpoint:** designated observation deck where you can see the actual stadium renovation in progress.
- **Espai Barça:** exhibition with models and audiovisual pieces showing the new stadium's future design.

## How it works

**Book your specific date online.** The ticket is valid 1 day - 4 months from purchase, so you have flexibility on when to use it within that window.

**Show mobile voucher at the FC Barcelona Museum entrance** (NOT at the stadium — the museum is in a temporary adjacent space during the renovation).

**Pick up your audio device** at reception — 13 languages available.

**Walk through the museum at your own pace.** Plan 1.5-2 hours for the full visit.

**The stadium bowl is NOT visitable** — only the Construction Viewpoint shows the renovation works from outside.

## Who I'd recommend it to

- FC Barcelona fans (must-do during the stadium renovation).
- Football enthusiasts in general.
- Cultural visitors with 3+ days in Barcelona.
- Families with kids 8+ (museum engages them, 360° room especially).
- Wheelchair users (fully accessible).

## Who I would NOT recommend it to

- Travellers expecting a traditional stadium tour (the bowl is closed).
- Visitors with epilepsy (the 360° room has flashing lights).
- Anyone in a rush (visit needs 1.5-2 hours minimum).
- Hardcore Barça fans wanting the full experience — book Total Experience Pass (t700918) for €49 instead.
