---
titulo: 'Lanzarote: entrada al Museo LagOmar en Nazaret'
slug: museo-lagomar-entrada-nazaret
ciudad: lanzarote
descripcion: Entrada al Museo LagOmar, en Nazaret, una antigua cantera volcánica convertida en un laberinto de cuevas, túneles, terrazas y jardines donde está la casa de Omar Sharif. 4,7/5 con 1.266 reseñas.
slugs:
  es: museo-lagomar-entrada-nazaret
  en: lagomar-museum-ticket-nazaret
  de: lagomar-museum-ticket-nazaret
  fr: lanzarote-billet-musee-lagomar-nazaret
  it: museo-lagomar-biglietto-nazaret
  pt: lanzarote-bilhete-museu-lagomar-nazaret
duracion: 45 minutos
duracionMinutos: 45
precioDesde: 10
moneda: EUR
idiomas: []
proveedor: getyourguide
urlReserva: https://www.getyourguide.com/es-es/activity-t684473/?partner_id=C71NOAW
cancelacionGratuita: true
horasCancelacion: 48
highlights:
- Arquitectura excavada en una cantera volcánica
- Cuevas, túneles y terrazas sobre la lava
- La casa vinculada a Omar Sharif
- Jardines, galerías de arte y tiendas de artesanía
- Visita libre a tu ritmo
incluye:
- Entrada al museo
noIncluye:
- Comida y bebida
puntoEncuentro:
  texto: Museo LagOmar, calle Los Loros, 2, Nazaret (Teguise).
  descripcionGuia: Presenta la entrada en la taquilla del museo. Se puede entrar hasta las 17:30.
detallesPracticos:
  ticketMovil: true
  confirmacionInmediata: false
  accesibleSilla: false
  edadMinima: 0
  mascotasPermitidas: false
informacionImportante:
  queTraer:
  - Calzado cómodo
  noAptoPara:
  - Usuarios de silla de ruedas
  aTenerEnCuenta:
  - Último acceso a las 17:30
  - No se permite ir descalzo
  - Los descuentos para residentes solo se aplican comprando en taquilla
accesibilidad: No apto para usuarios de silla de ruedas; hay escaleras, túneles y desniveles.
politicaCancelacion: Cancelación gratuita hasta 2 días antes, con reembolso íntegro.
preguntasFrecuentes:
- pregunta: ¿Cuánto dura la visita?
  respuesta: Unos 45 minutos, aunque al ser visita libre puedes quedarte más.
- pregunta: ¿Hasta qué hora se puede entrar?
  respuesta: El último acceso es a las 17:30.
- pregunta: ¿Es una visita guiada?
  respuesta: No, la entrada es para recorrer el museo por tu cuenta.
- pregunta: ¿Se puede cancelar?
  respuesta: Sí, gratis hasta 2 días antes. Con menos margen no hay reembolso.
opinionEditorial: LagOmar es de los rincones más sorprendentes de Lanzarote y, por 10 €, de los que mejor relación precio-experiencia tienen. Encaja muy bien como parada corta si vas en coche por la zona de Teguise; ojo a que la cancelación gratuita es hasta 48 horas, no 24 como en casi todo lo demás.
guiasRelacionadas:
- que-ver-en-lanzarote
categoria: entradas
keywords:
- museo lagomar
- lagomar lanzarote entradas
- casa omar sharif lanzarote
- que ver en teguise
ratingProveedor: 4.7
numeroOpiniones: 1266
atraccionesRelacionadas: []
publicada: true
indexar: false
destacada: false
fecha: '2026-10-31'
fecha_actualizacion: '2026-10-31'
imagen: /images/actividades/lanzarote/lagomar/flz-piscina.webp
imagenAlt: "Piscina de LagOmar rodeada de roca volcánica"
galeria:
- src: /images/actividades/lanzarote/lagomar/flz-terraza-roca.webp
  alt: "Terraza y puerta blanca excavadas en la roca en LagOmar"
- src: /images/actividades/lanzarote/lagomar/flz-pared-cuevas.webp
  alt: "Pared de roca con cuevas y puerta blanca en LagOmar"
- src: /images/actividades/lanzarote/lagomar/flz-tunel-blanco.webp
  alt: "Túnel blanco excavado en la roca en LagOmar"
- src: /images/actividades/lanzarote/lagomar/flz-arco-roca.webp
  alt: "Arco de roca y jardín de cactus en LagOmar"
- src: /images/actividades/lanzarote/lagomar/flz-jardin-palmeras.webp
  alt: "Jardín con palmeras y cactus junto a la roca en LagOmar"
- src: /images/actividades/lanzarote/lagomar/flz-muros-blancos.webp
  alt: "Muros blancos y vegetación sobre la roca en LagOmar"
---

## Qué vas a ver

- **Cuevas y túneles** excavados en una antigua cantera de lava.
- **Terrazas, escaleras y jardines** integrados en la roca.
- La **casa de Omar Sharif**, la parte más conocida del complejo.
- **Galerías de arte** y tiendas con productos de Lanzarote.

## Cómo funciona

Llegas por tu cuenta al museo, en Nazaret, muestras la entrada en taquilla y recorres el complejo a tu ritmo. La visita media ronda los 45 minutos. El último acceso es a las 17:30.

## A quién se lo recomiendo

- A quien le interesa la **arquitectura** y la **fotografía**.
- A quien va **en coche** por el centro y norte de la isla y quiere una parada corta.

## A quién NO se lo recomiendo

- A **usuarios de silla de ruedas**.
- A quien busca una **visita guiada**: es visita libre.
