---
titulo: 'Gran Canaria: excursión en yate compartido con barra libre, comida y esnórquel'
slug: yate-compartido-gran-canaria-comida-esnorquel
ciudad: gran-canaria
descripcion: Salida de 4 horas en yate desde Puerto Rico hacia Mogán con 12 pasajeros como máximo, copa de cava, barra libre de refrescos, cerveza y sangría, tentempié, esnórquel y paddle surf. 4,7/5 con 896 reseñas.
slugs:
  es: yate-compartido-gran-canaria-comida-esnorquel
  en: gran-canaria-shared-yacht-trip-lunch-snorkeling
  de: gran-canaria-yachtausflug-schnorcheln-puerto-rico
  fr: grande-canarie-yacht-partage-open-bar-snorkeling
  it: gran-canaria-yacht-condiviso-open-bar-snorkeling
  pt: gran-canaria-iate-partilhado-bar-aberto-snorkel
duracion: 4 horas
duracionMinutos: 240
precioDesde: 68
moneda: EUR
idiomas:
- en
- es
proveedor: getyourguide
urlReserva: https://www.getyourguide.com/es-es/activity-t767148/?partner_id=C71NOAW
cancelacionGratuita: true
horasCancelacion: 24
highlights:
- Yate con 12 pasajeros como máximo
- Cala del Perchel, solo accesible por mar
- Barra libre de refrescos, cerveza y sangría
- Esnórquel y paddle surf
- Recogida en el sur de la isla
incluye:
- Recogida y regreso al alojamiento en el sur de la isla
- Patrón y guía
- Copa de cava de bienvenida
- Barra libre de cerveza, refrescos, sangría, agua y zumos
- Tentempié variado
- Equipo de esnórquel
- Dos tablas de paddle surf
- Seguro, tasas e impuestos
noIncluye:
- Toallas
- Bebidas premium, cócteles, vino y champán
- Actividades acuáticas extra (moto de agua, parasailing, banana boat)
puntoEncuentro:
  texto: Calle Puerto Escala, puerto de Puerto Rico (Mogán), o recogida en hoteles del sur.
  descripcionGuia: Puedes ir por tu cuenta al puerto de Puerto Rico o elegir recogida en tu alojamiento del sur al reservar.
detallesPracticos:
  ticketMovil: true
  confirmacionInmediata: false
  accesibleSilla: false
  edadMinima: 0
  mascotasPermitidas: false
informacionImportante:
  queTraer:
  - Bañador y toalla
  - Gafas de sol y crema solar
  noAptoPara: []
  aTenerEnCuenta:
  - Si te mareas, lleva pastillas para el mareo
  - Prohibido subir bebidas propias y mascotas
  - El itinerario puede cambiar por el estado del mar
  - Avisa con antelación de necesidades alimentarias
accesibilidad: Consulta la accesibilidad con el proveedor.
politicaCancelacion: Cancelación gratuita hasta 24 horas antes, con reembolso íntegro.
preguntasFrecuentes:
- pregunta: ¿Cuánta gente va en el barco?
  respuesta: Como máximo 12 pasajeros. También hay opción privada.
- pregunta: ¿Qué bebidas están incluidas?
  respuesta: Cerveza, refrescos, sangría, agua y zumos, más una copa de cava de bienvenida. Cócteles y vino se pagan aparte.
- pregunta: ¿Cuánto tiempo hay para bañarse?
  respuesta: Entre una hora y media y dos horas, con esnórquel y paddle surf.
- pregunta: ¿Incluye recogida?
  respuesta: Sí, desde muchos alojamientos del sur de la isla; también puedes ir directamente al puerto de Puerto Rico.
opinionEditorial: Frente a los catamaranes grandes, aquí la gracia es ir en un barco pequeño con pocos pasajeros y mucho tiempo para bañarse. Es una mañana relajada, más de baño y charla que de ver delfines.
guiasRelacionadas:
- que-ver-en-gran-canaria
categoria: agua
keywords:
- excursion barco gran canaria
- yate puerto rico gran canaria
- barco mogan esnorquel
- paseo en barco gran canaria
ratingProveedor: 4.7
numeroOpiniones: 896
atraccionesRelacionadas:
- mar
- mogan
publicada: true
indexar: false
destacada: false
fecha: '2026-10-31'
fecha_actualizacion: '2026-10-31'
imagen: /images/actividades/gran-canaria/yate/fgc-yate-navegando-mar-abierto.webp
imagenAlt: "Yate a motor navegando en mar abierto"
galeria:
- src: /images/actividades/gran-canaria/puerto-rico/bahia-puerto-rico.webp
  alt: "Bahía y playa de Puerto Rico de Gran Canaria"
- src: /images/actividades/gran-canaria/mogan-kayak/acantilados-volcanicos-mogan-mar.webp
  alt: "Acantilados volcánicos de la costa suroeste vistos desde el mar"
- src: /images/actividades/gran-canaria/yate/fgc-mar-azul-costa-rocosa.webp
  alt: "Mar azul frente a una costa rocosa, a ras de agua"
- src: /images/actividades/gran-canaria/catamaran/fgc-esnorquel-fondo-rocoso.webp
  alt: "Esnórquel sobre un fondo de rocas en aguas claras"
- src: /images/actividades/gran-canaria/mogan-kayak/peces-fondo-marino-gran-canaria.webp
  alt: "Peces sobre el fondo arenoso en aguas de Gran Canaria"
- src: /images/actividades/gran-canaria/mar/puerto-rico-atardecer.webp
  alt: "Puerto Rico de Gran Canaria al atardecer"
---

## Qué vas a ver

- La costa de **Mogán** y la **Cala del Perchel**, solo accesible por mar.
- La bahía de Mogán y la playa de **Tauro**.
- Los acantilados de **Tiritaña** a la vuelta.

## Cómo funciona

Te recogen en tu alojamiento del sur o vas directamente al puerto de Puerto Rico. Zarpas con una copa de cava, navegas hacia Mogán y fondeas en una cala para nadar, hacer esnórquel y paddle surf mientras la tripulación prepara el tentempié. Vuelves a Puerto Rico bordeando la costa.

## A quién se lo recomiendo

- A **parejas** y **grupos de amigos** que quieren una mañana de baño.
- A quien prefiere un barco **pequeño** a un catamarán grande.

## A quién NO se lo recomiendo

- A quien **se marea** con facilidad.
- A quien busca sobre todo **ver delfines**.
