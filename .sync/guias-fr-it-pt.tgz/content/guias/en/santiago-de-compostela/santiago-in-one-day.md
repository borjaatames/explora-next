---
titulo: "Santiago de Compostela in one day: cathedral, old town and the Camino"
descripcion: "What to see in Santiago in one day: Cathedral, Obradoiro, old town and the Mercado de Abastos. An hour-by-hour walking route at the end of the Camino, where to eat and what to skip."
respuestaCorta: 'Start at 9:30 in the **Plaza del Obradoiro** and the **Cathedral**, with Master Mateo''s Pórtico de la Gloria, then walk its four squares and the arcaded Rúa do Franco and Rúa do Vilar. Stop at the **Mercado de Abastos** before lunch and end at **Alameda park** for the best view of the towers at sunset. An old-town walking tour with an official guide costs from €10.'
categoria: "santiago-de-compostela"
slug: "santiago-in-one-day"
fecha: "2026-05-02"
fecha_actualizacion: "2026-10-23"
autor: Borja
publicada: true
destacada: true
imagen_portada: "/images/guias/santiago-en-un-dia.jpg"
imagen_alt: "Obradoiro square with Raxoi Palace and the Hostal dos Reis Católicos"
tiempo_lectura: 11
keywords:
  - "what to see in santiago de compostela"
  - "santiago in one day"
  - "santiago cathedral"
  - "camino de santiago"
  - "obradoiro"
slugs:
  es: santiago-en-un-dia
  en: santiago-in-one-day
  de: santiago-in-einem-tag
  fr: saint-jacques-de-compostelle-en-un-jour
  it: santiago-di-compostela-in-un-giorno
  pt: santiago-de-compostela-num-dia
reservasArriba: true
actividades:
  - santiago-portico-gloria-catedral-tour
  - tour-a-pie-casco-antiguo-santiago
  - tour-tapas-santiago-musica-directo
  - excursion-finisterre-muxia-costa-da-morte
  - catedral-museo-casco-antiguo-santiago
  - catedral-santiago-museo-tour-guiado
  - excursion-rias-baixas-barco-bodega
  - excursion-playa-catedrales-lugo-ribadeo
  - cubiertas-catedral-santiago-tour
  - tour-autoguiado-daremapp-santiago-de-compostela
  - santiago-de-compostela-private-tour-official-guide
  - santiago-de-compostela-private-food-tour
---

**Santiago is easily seen in a day**, though its atmosphere invites you to stay. The old town is compact, all stone and arcades, a UNESCO World Heritage Site, and everything revolves around the **cathedral**, the goal of the Camino. This guide covers the essentials of the Galician capital and makes clear why whoever stays overnight takes home far more than the passing tourist.

## Book the essentials

| Activity | Rating | From |
| --- | --- | --- |
| [Cathedral, museum and old town tour](/en/cities/santiago-de-compostela/activities/santiago-cathedral-museum-old-town-tour) | 4.8★ (439) | €24 |
| [Old town walking tour with an official guide](/en/cities/santiago-de-compostela/activities/santiago-old-town-walking-tour) | 4.8★ (356) | €10 |
| [Skip-the-line cathedral and museum tour](/en/cities/santiago-de-compostela/activities/santiago-cathedral-museum-guided-tour) | 4.7★ (2,454) | €25 |
| [Tapas tour with drinks and live music](/en/cities/santiago-de-compostela/activities/santiago-tapas-tour-live-music) | 4.7★ (231) | €45 |
| [Finisterre, Muxía and Costa da Morte](/en/cities/santiago-de-compostela/activities/finisterre-muxia-costa-da-morte-day-trip) | 4.7★ (2,372) | €52 |
| [Rías Baixas with boat trip and winery](/en/cities/santiago-de-compostela/activities/rias-baixas-boat-winery-day-trip) | 4.7★ (486) | €47 |
| [Las Catedrales beach, Lugo and Ribadeo](/en/cities/santiago-de-compostela/activities/las-catedrales-beach-lugo-ribadeo-day-trip) | 4.5★ (225) | €65 |

The key to Santiago isn't only monumental, it's atmospheric: rain on the stone, bagpipes in the squares, pilgrims arriving moved at the Obradoiro and a university old town with a life you don't see on an express visit. This route orders the day so you miss neither the cathedral nor the soul of the city.

## When to visit Santiago

| Season | Verdict | Why |
| --- | --- | --- |
| May, June and September | Ideal | Drier weather, long days, Camino atmosphere |
| July and August | Busy | Good weather and festivals, but packed with pilgrims |
| 24-25 July | Festas do Apóstolo | Santiago's big day; spectacular but at capacity |
| October to April | Rainy | Green and authentic; bring an umbrella and wrap up |
| Holy Year (Xacobeo) | Unique | When 25 July falls on a Sunday; great pilgrimage |

> **⭐ Tip:** Santiago **rains a lot** for much of the year; it's not a flaw of the climate, it's its essence ("wet stone"). Bring an umbrella or raincoat and don't skip going out: the city in the rain is beautiful.

## Getting there

**By high-speed train** from Madrid in about 3h; there's also an airport (Lavacolla, 12 km away) with domestic and European flights, and trains from A Coruña and Vigo. The station is a 15-minute walk from the centre. Santiago is also the **end of all the Camino routes** (French, Portuguese, Northern, Primitivo…). The old town is pedestrian: walked end to end.

## The one-day route, done right

| Time | Activity |
| --- | --- |
| 9:30 — 11:00 | Plaza del Obradoiro and Cathedral |
| 11:00 — 12:00 | The four squares (Quintana, Praterías, Inmaculada) |
| 12:00 — 13:00 | Old town (Rúa do Franco, Rúa do Vilar) |
| 13:00 — 14:00 | Mercado de Abastos |
| 14:00 — 16:00 | Lunch |
| 16:30 — 18:00 | San Martiño Pinario and Alameda park |

**9:30 — Obradoiro and Cathedral.** Start at the **Plaza del Obradoiro**, before the Baroque façade of the **Cathedral**, where pilgrims arrive. Go in to see Master Mateo's **Pórtico de la Gloria** (restored, a Romanesque gem) and, if your visit coincides with the Pilgrim's Mass and the day allows, the swing of the **botafumeiro**, the giant censer. The square is framed by the Pazo de Raxoi and the **Hostal dos Reis Católicos** (a former pilgrims' hospital, now a parador).

**11:00 — The four squares.** Walk around the cathedral via its squares: the **Quintana** (with the Holy Door, opened only in Holy Years), **Praterías** (the fountain of horses) and the **Inmaculada**.

**12:00 — Old town.** Get lost along the **Rúa do Franco** and the **Rúa do Vilar**, arcaded and full of taverns, and through the stone lanes of the centre.

**13:00 — Mercado de Abastos.** Visit the **Mercado de Abastos**, the second most-visited place after the cathedral: you buy Galician produce and at some stalls they cook it for you on the spot.

**14:00 — Lunch.** Time for octopus (see below).

**16:30 — San Martiño and the Alameda.** Look in at the **San Martiño Pinario** monastery and finish at the **Alameda park**, with the **best view** of the cathedral towers at sunset (the classic image from the Carballeira de Santa Susana).

## Where to stay

The best area is the **old town**, within the monumental zone: everything on foot and the night-time buzz of student bands and taverns. The **Ensanche** area (by the Alameda) is practical and has more modern options. **Avoid** staying far from the centre: the joy of Santiago is walking it, especially at night when the day-trippers have gone.

## Eating in Santiago

Galician cooking is pure produce. The essentials: **pulpo á feira** (octopus with paprika and oil), **seafood** (goose barnacles, razor clams, scallops), **Galician empanada**, **Padrón peppers**, **lacón con grelos** (pork with turnip tops) and, for dessert, the **tarta de Santiago** (almond cake with the apostle's cross). To drink, **Albariño** from the Rías Baixas or **Ribeiro**, with an orujo or a queimada as a digestif.

> **⚠️ Warning:** avoid the more touristy taverns on the Rúa do Franco with touts at the door. The Mercado de Abastos and the back streets of the old town are far better for quality and price.

## What we don't recommend

1. **Seeing it in a rush.** Santiago's atmosphere is enjoyed strolling without a clock.
2. **Eating only on the touristy Rúa do Franco.** The market and the streets behind reward you more.
3. **Staying in the centre without climbing to the Alameda.** It's the best view in the city.
4. **Giving up on going out if it rains.** The wet stone is half the charm of Santiago.

## Common visitor mistakes

> **⚠️ Warning:** the slip-ups we see most.

1. **Not booking the cathedral rooftop tour.** It's a different, highly recommended visit.
2. **Just passing through between the Rías Baixas and A Coruña.** Santiago deserves at least a full day.
3. **Not checking the botafumeiro schedule.** It only swings at certain Masses and dates; check beforehand.
4. **Forgetting the umbrella.** It rains often all year round.

## Events to plan around

- **Festas do Apóstolo (24-25 July).** Santiago's big day: on the eve, the pyrotechnic spectacle of the **Fire of the Apostle** over a mock façade on the Obradoiro; on the 25th, the main festivity.
- **Holy Year (Xacobeo).** When 25 July falls on a Sunday: the Holy Door opens and the pilgrimage multiplies.
- **Ascensión (May/June).** The city's other big festival, more local.

## In one sentence

Santiago in a day is cathedral, wet stone and the end of the Camino; with one more night, you take home its unique atmosphere of student bands and taverns and an escape to the **Rías Baixas** or to Fisterra, the end of the world.
