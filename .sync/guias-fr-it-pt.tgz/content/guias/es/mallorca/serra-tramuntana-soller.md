---
titulo: "Serra de Tramuntana y Sóller: ruta por la Mallorca de montaña"
descripcion: "Guía de la Serra de Tramuntana: Valldemossa, Deià, Sóller y su tren, Sa Calobra y los miradores. Ruta en coche o en tren, qué ver y cuándo ir."
categoria: "mallorca"
slug: "serra-tramuntana-soller"
fecha: "2026-03-18"
fecha_actualizacion: "2026-10-23"
autor: Borja
publicada: true
destacada: true
imagen_portada: "/images/actividades/mallorca/soller/port-de-soller-vista.webp"
imagen_alt: "Port de Sóller y su bahía vistos desde la Serra de Tramuntana"
tiempo_lectura: 4
keywords:
  - "serra de tramuntana"
  - "tren de sóller"
  - "valldemossa"
  - "deià"
  - "sa calobra"
slugs:
  es: serra-tramuntana-soller
  en: serra-tramuntana-soller
  de: serra-de-tramuntana-soller
  fr: serra-tramuntana-soller
  it: serra-de-tramuntana-e-soller
  pt: serra-de-tramuntana-e-soller
reservasArriba: true
respuestaCorta: 'Un día en coche da para lo principal: **Valldemossa, Deià y Sóller**, y la carretera de **Sa Calobra** si sales temprano (a media mañana se llena). Son pocos kilómetros pero muchas curvas. Sin conducir, combina el **tren de Sóller** con el barco de Port de Sóller a Sa Calobra (desde 35 €). Mejor de abril a junio y en septiembre-octubre.'
actividades:
  - barco-soller-sa-calobra
  - mallorca-vuelta-isla-tren-soller-tranvia-barco
  - tren-soller-tranvia-medio-dia-desde-el-norte
  - cartuja-valldemossa-entrada-audioguia
---

**La Serra de Tramuntana es la Mallorca que el turista de playa no ve**, y para muchos, la mejor. Una cadena montañosa **Patrimonio de la Humanidad** por su paisaje cultural de bancales, muros de piedra seca y olivos centenarios, salpicada de pueblos de piedra colgados sobre el mar y carreteras de vértigo. Esta guía la ordena para que la disfrutes en coche o en el mítico tren de Sóller, sin perderte lo esencial.

La clave de la Tramuntana es ir despacio: son pocos kilómetros pero mucha curva, mucho mirador y muchas ganas de parar. Un día da para lo principal; dos, para vivirla con calma.

## Cuándo ir

| Época | Veredicto | Por qué |
| --- | --- | --- |
| Abril a junio | Ideal | Verde, flores, temperaturas perfectas |
| Septiembre y octubre | Ideal | Luz dorada, menos coches en las curvas |
| Enero y febrero | Almendros | Floración espectacular en los bancales |
| Julio y agosto | Calor y tráfico | Las carreteras estrechas se saturan |

> **⭐ Tip:** la carretera de **Sa Calobra** y los miradores se llenan a media mañana en temporada. Sal temprano: conducirás más tranquilo y harás las fotos sin gente.

[actividad: barco-soller-sa-calobra]

## Los pueblos imprescindibles

**Valldemossa.** El pueblo más famoso, de calles empedradas y flores, con la **Cartuja** donde Chopin y George Sand pasaron el invierno de 1838-39. Coqueto y muy visitado: ve pronto.

**Deià.** Aldea de artistas colgada sobre el mar, donde vivió el escritor Robert Graves. Casas de piedra dorada y una cala (Cala Deià) de aguas cristalinas al fondo de un barranco.

**Sóller.** Un valle de naranjos rodeado de montañas, con una plaza modernista preciosa. De aquí sale el **tranvía** al **Port de Sóller**, una bahía resguardada.

**Fornalutx.** A un paso de Sóller, considerado uno de los pueblos más bonitos de España: escaleras de piedra, geranios y silencio.

## El tren de Sóller

El **tren de madera de 1912** une Palma con Sóller cruzando la Tramuntana entre túneles y naranjos: una hora de viaje que es una atracción en sí misma. En Sóller, enlaza con el **tranvía histórico** hasta el puerto. Es la mejor opción si no quieres conducir las curvas. Reserva en temporada.

## Las carreteras y miradores

- **Sa Calobra (MA-2141).** La carretera más espectacular de la isla, con el famoso **"nus de sa corbata"** (un lazo de 360°), que baja hasta el **Torrent de Pareis**, un cañón que desemboca en el mar.
- **Sa Foradada.** Desde Son Marroig, una caminata fácil lleva a la roca horadada; atardecer de postal (hay restaurante).
- **Mirador de Ses Ànimes (Torre del Verger).** El balcón clásico sobre el Mediterráneo, espectacular al ponerse el sol.
- **Banyalbufar.** Pueblo de bancales sobre el mar.

## Lo práctico: carreteras, aparcar y precios

- **La MA-10** es la carretera que recorre la sierra de Andratx a Pollença: 110 km que en coche llevan 3 horas sin paradas. Entre Valldemossa y Sóller tiene un solo carril por sentido y poco arcén; con un coche pequeño se va mucho mejor que con un SUV.
- **Aparcar:** en Valldemossa, aparcamiento de pago a la entrada (unos 5 € el día); en Deià, apenas 40 plazas en la carretera y Cala Deià sin aparcamiento práctico en verano; en Sóller, el aparcamiento de la plaza de Mallorca; en Sa Calobra, 8-10 € y lleno a las 11:00 en temporada. Sa Foradada se aparca en Son Marroig (3 € la entrada al camino).
- **Sin coche:** la línea de autobús TIB 203 une Palma con Valldemossa (30 minutos), Deià (50) y Sóller (1 h 15) por 2-5 €, cada hora. Es la forma más barata y evita conducir la MA-10. El tren de Sóller (30 € ida y vuelta) es la forma más bonita.
- **Sa Calobra sin curvas:** barco desde Port de Sóller (desde 35 € ida y vuelta, 1 hora), con parada de dos horas para ver el Torrent de Pareis. Autobús TIB 354 desde Sóller y Port de Sóller en verano, muy limitado.
- **Cartuja de Valldemossa:** 13 € (gratis menores de 10), con la celda de Chopin y concierto de piano incluido cada hora. Cierra los domingos por la tarde y en invierno antes.
- **Gasolina y agua:** gasolineras solo en Sóller, Andratx y Pollença. Entre Deià y Sa Calobra, nada. En verano, 2 litros de agua por persona en el coche.
- **El túnel de Sóller** (MA-11) es gratuito desde 2017 y acorta el viaje desde Palma a 30 minutos; el puerto de montaña, el Coll de Sóller, es la alternativa panorámica, con 50 curvas.

## Ruta de un día en coche

| Hora | Parada |
| --- | --- |
| 9:00 | Palma → Valldemossa |
| 10:30 | Deià y mirador de Sa Foradada |
| 12:30 | Sóller y Fornalutx |
| 14:30 | Comida en el valle de Sóller |
| 16:30 | Sa Calobra (o Port de Sóller) |

## Comer en la Tramuntana

Cocina de montaña: **frit, tumbet, arròs brut** y, de Sóller, las **naranjas** y su zumo, además de los helados y el aceite de oliva de la sierra. Busca cellers y restaurantes de pueblo lejos de la plaza principal de Valldemossa, donde sube el precio.

## Lo que NO recomendamos

1. **Hacer la Tramuntana con prisa.** Es de parar cada pocos kilómetros; no la trates como un trayecto.
2. **Conducir Sa Calobra si te marea la carretera.** Curvas extremas; valora el bus o la barca.
3. **Llegar a los miradores a mediodía en verano.** Llenos y sin aparcamiento; ve pronto.
4. **Saltarte el tren de Sóller** si te gusta el viaje lento.

[actividad: mallorca-vuelta-isla-tren-soller-tranvia-barco]

## Errores típicos

> **⚠️ Aviso:** los fallos que más vemos.

1. **Reservar el coche tarde en verano.** Imprescindible para la sierra; vuela.
2. **Calcular mal los tiempos.** En la Tramuntana se va lento; no metas demasiadas paradas.
3. **Olvidar gasolina y agua.** Hay tramos largos sin servicios.

## En una frase

La Serra de Tramuntana es la Mallorca de piedra, olivos y mar: pueblos como Valldemossa, Deià y Fornalutx, el tren de Sóller y carreteras de vértigo como Sa Calobra. Es lo que diferencia la isla de un destino de playa cualquiera; lo enmarcamos en [qué ver en Mallorca](/guias/mallorca/que-ver-en-mallorca).
