import OtrosIdiomas from "@/components/layout/OtrosIdiomas";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import {
  obtenerGuia,
  obtenerTodosLosCaminos,
  obtenerGuiasRelacionadas,
} from "@/lib/guias";
import { slugParejaGuia } from "@/lib/i18n/slugs";
import {
  formatearFecha,
  hreflangAlternates,
  rutasPorIdioma,
  urlActividadesDeCiudad,
  urlGuia,
} from "@/lib/i18n/utils";
import FaqActividad from "@/components/FaqActividad";
import ActividadesRecomendadasGuia from "@/components/guia/ActividadesRecomendadasGuia";
import { obtenerActividadesParaGuia, obtenerPrivadasParaGuia } from "@/lib/recomendaciones";
import { obtenerListaCiudades } from "@/lib/ciudades";
import HeroGuia, { IndiceGuia } from "@/components/guia/HeroGuia";
import { anadirAnclasH2 } from "@/lib/indiceGuia";
import ReservasGuia from "@/components/guia/ReservasGuia";
import PrivadasGuia from "@/components/guia/PrivadasGuia";
import OpcionesGuia, { type OpcionGuia } from "@/components/guia/OpcionesGuia";
import RespuestaCorta from "@/components/guia/RespuestaCorta";
import MapaDiaGuia from "@/components/guia/MapaDiaGuia";
import { insertarMapasPorDia, obtenerMapasGuia } from "@/lib/mapasGuias";
import TarjetaReservaInline from "@/components/guia/TarjetaReservaInline";
import CtaStickyGuia from "@/components/guia/CtaStickyGuia";
import TrackingReservasGuia from "@/components/guia/TrackingReservasGuia";
import {
  enriquecerEnlacesFichas,
  formatearPrecio,
  formatearRating,
  indexarFichasCiudad,
  partirHtmlPorShortcodes,
  slugsInline,
} from "@/lib/guiasReservas";

const SITE_URL =
  process.env.NEXT_PUBLIC_SITE_URL || "https://www.exploraspain.com";

type Props = {
  params: { categoria: string; slug: string };
};

export async function generateStaticParams() {
  return obtenerTodosLosCaminos()
    .filter((c) => c.idioma === "es")
    .map(({ categoria, slug }) => ({ categoria, slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const guia = await obtenerGuia("es", params.categoria, params.slug);
  if (!guia) return { title: "Guía no encontrada" };

  const url = `${SITE_URL}${guia.url}`;
  const allowIndexing = process.env.NEXT_PUBLIC_ALLOW_INDEXING === "true";

  // Imagen absoluta para Open Graph (necesaria en WhatsApp, Twitter, LinkedIn).
  const imagenRelativa =
    guia.imagen_portada || guia.imagen || "/images/actividades/barcelona/sagrada-familia/pexels-11565894-og.jpg";
  const imagenAbsoluta = imagenRelativa.startsWith("http")
    ? imagenRelativa
    : `${SITE_URL}${imagenRelativa}`;

  return {
    title: guia.metaTitle ?? guia.titulo,
    description: guia.metaDescription ?? guia.descripcion,
    keywords: guia.keywords,
    authors: guia.autor ? [{ name: guia.autor }] : undefined,
    robots: {
      index: allowIndexing,
      follow: allowIndexing,
    },
    alternates: {
      canonical: url,
      languages: hreflangAlternates((l) => {
        const slugPareja = slugParejaGuia(
          "es",
          params.categoria,
          params.slug,
          l
        );
        return slugPareja ? urlGuia(l, params.categoria, slugPareja) : null;
      }),
    },
    openGraph: {
      type: "article",
      url,
      title: guia.titulo,
      description: guia.descripcion,
      publishedTime: guia.fecha,
      modifiedTime: guia.fecha_actualizacion || guia.fecha,
      authors: guia.autor ? [guia.autor] : undefined,
      siteName: "ExploraSpain",
      locale: "es_ES",
      images: [
        {
          url: imagenAbsoluta,
          alt: guia.imagen_alt || guia.titulo,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: guia.titulo,
      description: guia.descripcion,
      images: [imagenAbsoluta],
    },
  };
}

export default async function GuiaPage({ params }: Props) {
  const guia = await obtenerGuia("es", params.categoria, params.slug);
  if (!guia) notFound();

  const relacionadas = obtenerGuiasRelacionadas(
    "es",
    guia.categoria,
    guia.slug,
    3
  );

  const actividadesRecomendadas = obtenerActividadesParaGuia(
    "es",
    guia.categoria,
    {
      slug: guia.slug,
      titulo: guia.titulo,
      keywords: guia.keywords,
      actividades: guia.actividades,
      ciudadesFichas: guia.ciudadesFichas,
    },
    10
  );
  const privadasGuia = obtenerPrivadasParaGuia(
    "es",
    guia.categoria,
    {
      slug: guia.slug,
      titulo: guia.titulo,
      keywords: guia.keywords,
      actividades: guia.actividades,
      ciudadesFichas: guia.ciudadesFichas,
    },
    3
  );
  const nombreCiudad =
    obtenerListaCiudades("es").find((c) => c.slug === guia.categoria)?.nombre ??
    guia.categoria.charAt(0).toUpperCase() + guia.categoria.slice(1);

  // Imagen absoluta para JSON-LD (Google la requiere completa).
  const imagenRelativa =
    guia.imagen_portada || guia.imagen || "/images/actividades/barcelona/sagrada-familia/pexels-11565894-og.jpg";
  const imagenAbsoluta = imagenRelativa.startsWith("http")
    ? imagenRelativa
    : `${SITE_URL}${imagenRelativa}`;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: guia.titulo,
    description: guia.descripcion,
    image: imagenAbsoluta,
    datePublished: guia.fecha,
    dateModified: guia.fecha_actualizacion || guia.fecha,
    author: {
      "@type": "Person",
      name: guia.autor || "Borja",
      url: `${SITE_URL}/sobre-nosotros#autor`,
      worksFor: { "@type": "Organization", name: "ExploraSpain" },
    },
    publisher: {
      "@type": "Organization",
      name: "ExploraSpain",
      url: "https://www.exploraspain.com",
    },
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": `${SITE_URL}${guia.url}`,
    },
    keywords: guia.keywords?.join(", "),
  };

  const breadcrumbsLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Inicio",
        item: SITE_URL,
      },
      {
        "@type": "ListItem",
        position: 2,
        name: "Guías",
        item: `${SITE_URL}/guias`,
      },
      {
        "@type": "ListItem",
        position: 3,
        name: guia.titulo,
        item: `${SITE_URL}${guia.url}`,
      },
    ],
  };

  // Igual que en FaqActividad: no inyectamos FAQPage hasta tener 4+
  // preguntas reales (con menos, el rich snippet rara vez se muestra y
  // solo añade peso al HTML).
  const faq = guia.faq || [];
  const faqJsonLd =
    faq.length >= 4
      ? {
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: faq.map((p) => ({
            "@type": "Question",
            name: p.pregunta,
            acceptedAnswer: {
              "@type": "Answer",
              text: p.respuesta,
            },
          })),
        }
      : null;

  const { html: htmlConAnclas, indice } = anadirAnclasH2(guia.contenidoHtml);

  // Reservas dentro de la guía: fichas de la ciudad indexadas por slug,
  // tarjetas inline (shortcodes), píldoras en enlaces, bloque superior,
  // carrusel sin repetir lo ya ofrecido y barra sticky en móvil.
  const fichasCiudad = indexarFichasCiudad("es", guia.categoria, guia.ciudadesFichas);
  const trozos = insertarMapasPorDia(
    partirHtmlPorShortcodes(
      enriquecerEnlacesFichas(htmlConAnclas, fichasCiudad, "es"),
      fichasCiudad
    ),
    obtenerMapasGuia(guia.categoria, guia.slug),
    "es"
  );
  const opcionesGuia: OpcionGuia[] = (guia.opciones ?? []).flatMap((o) => {
    const actividad = fichasCiudad.get(o.ficha);
    return actividad ? [{ etiqueta: o.etiqueta, actividad }] : [];
  });
  // Con «Nuestras 3 opciones» no se repite el bloque de reservas genérico.
  const reservasArriba = guia.reservasArriba && opcionesGuia.length === 0
    ? actividadesRecomendadas.slice(0, 4)
    : [];
  // Carrusel final: todas las fichas de la guía (`actividades:`), en su
  // orden, aunque alguna ya salga arriba. Nunca fichas ajenas a la guía.
  const actividadesCarrusel = actividadesRecomendadas;
  const actividadSticky =
    opcionesGuia[0]?.actividad ??
    reservasArriba[0] ??
    fichasCiudad.get(slugsInline(trozos)[0] ?? "") ??
    actividadesRecomendadas[0];

  return (
    <main className="min-h-screen bg-white">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbsLd) }}
      />
      {faqJsonLd && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
        />
      )}

      <HeroGuia
        etiqueta={nombreCiudad || guia.categoria}
        titulo={guia.titulo}
        descripcion={guia.descripcion}
        imagen={guia.imagen_portada}
        imagenAlt={guia.imagen_alt}
        migasLabel="Migas de pan"
        migas={[
          { label: "Inicio", href: "/" },
          { label: "Guías", href: "/guias" },
          { label: guia.titulo },
        ]}
        meta={[
          ...(guia.autor ? [`Por ${guia.autor}`] : []),
          ...(guia.fecha_actualizacion && guia.fecha_actualizacion !== guia.fecha
            ? [`Actualizado el ${formatearFecha(guia.fecha_actualizacion, "es")}`]
            : guia.fecha
              ? [formatearFecha(guia.fecha, "es")]
              : []),
          `${guia.tiempoLectura} min de lectura`,
        ]}
      />

      <RespuestaCorta texto={guia.respuestaCorta} idioma="es" comprobado={guia.datosComprobados} />
      <OpcionesGuia opciones={opcionesGuia} idioma="es" />
      <ReservasGuia actividades={reservasArriba} idioma="es" />
      <PrivadasGuia actividades={privadasGuia} idioma="es" />

      <div
        className={
          "max-w-6xl mx-auto px-4 py-12 md:py-16 " +
          (indice.length > 2 ? "lg:grid lg:grid-cols-[220px_minmax(0,1fr)] lg:gap-16" : "")
        }
      >
        {indice.length > 2 && <IndiceGuia titulo="En esta guía" entradas={indice} />}
        <article className={"max-w-3xl " + (indice.length > 2 ? "" : "mx-auto")}>
          {trozos.map((trozo, i) =>
            trozo.tipo === "html" ? (
              <div
                key={i}
                className="prose-guia"
                dangerouslySetInnerHTML={{ __html: trozo.html }}
              />
            ) : trozo.tipo === "mapa" ? (
              <MapaDiaGuia
                key={i}
                dia={trozo.dia}
                paradas={trozo.paradas}
                idioma={"es"}
              />
            ) : (
              <TarjetaReservaInline
                key={i}
                actividad={fichasCiudad.get(trozo.slug)!}
                idioma="es"
              />
            )
          )}
          {faq.length > 0 && (
            <div className="mt-12 pt-8 border-t border-piedra-200">
              <FaqActividad idioma="es" preguntas={faq} />
            </div>
          )}
        </article>
      </div>

      <ActividadesRecomendadasGuia
        actividades={actividadesCarrusel}
        idioma={"es"}
        nombreCiudad={nombreCiudad}
        urlTodas={urlActividadesDeCiudad("es", guia.categoria)}
      />

      {relacionadas.length > 0 && (
        <section className="bg-piedra-50 border-t border-piedra-200">
          <div className="max-w-5xl mx-auto px-4 py-12 md:py-16">
            <h2 className="font-fraunces text-2xl md:text-3xl font-bold text-piedra-900 mb-6">
              Guías relacionadas
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {relacionadas.map((rel) => (
                <Link
                  key={rel.url}
                  href={rel.url}
                  className="group block bg-white border border-piedra-200 rounded-lg p-5 hover:border-anil-400 hover:shadow-md transition-all"
                >
                  <h3 className="font-fraunces text-lg font-bold text-piedra-900 mb-2 group-hover:text-anil-700 transition-colors">
                    {rel.titulo}
                  </h3>
                  <p className="text-sm text-piedra-600 leading-relaxed line-clamp-3">
                    {rel.descripcion}
                  </p>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      <div className="max-w-3xl mx-auto px-4 py-12 text-center">
        <Link
          href="/guias"
          className="text-anil-600 hover:text-anil-700 font-semibold"
        >
          ← Volver a todas las guías
        </Link>
      </div>

      {actividadSticky && (
        <CtaStickyGuia
          titulo={actividadSticky.titulo}
          url={actividadSticky.url}
          slugEs={actividadSticky.slugs?.es ?? actividadSticky.slug}
          precio={formatearPrecio(actividadSticky, "es")}
          rating={formatearRating(actividadSticky, "es")}
          textoDesde="desde"
          textoCta="Reservar"
        />
      )}
      <TrackingReservasGuia
        guiaSlug={guia.slug}
        ciudad={guia.categoria}
        idioma="es"
      />
      <OtrosIdiomas
        idioma={"es"}
        rutas={rutasPorIdioma((l) => {
          const slugPareja = slugParejaGuia("es", params.categoria, params.slug, l);
          return slugPareja ? urlGuia(l, params.categoria, slugPareja) : null;
        })}
      />
    </main>
  );
}
