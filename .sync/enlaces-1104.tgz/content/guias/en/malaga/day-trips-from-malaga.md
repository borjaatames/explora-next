---
titulo: "Day trips from Málaga: Ronda, Nerja, Antequera and white villages"
descripcion: "The best day trips from Málaga: Ronda, Nerja and Frigiliana, Antequera and El Torcal, Mijas and Gibraltar. How to get there, what to see and how long to spend."
categoria: "malaga"
slug: "day-trips-from-malaga"
fecha: "2026-04-13"
fecha_actualizacion: '2026-11-03'
respuestaCorta: 'The best day trips from Málaga are **Nerja and Frigiliana** (an hour by bus, caves from €15.50), **Antequera and El Torcal** (45 minutes), **Ronda** (about 2 hours by bus) and **Gibraltar** (bring a passport or EU ID). Do one per day: Ronda and Gibraltar each need a full day, and organised trips start at €35.'
autor: Borja
publicada: true
destacada: false
tiempo_lectura: 11
keywords:
  - "day trips from malaga"
  - "ronda from malaga"
  - "nerja and frigiliana"
  - "antequera el torcal"
  - "white villages malaga"
slugs:
  es: escapadas-desde-malaga
  en: day-trips-from-malaga
  de: ausfluege-ab-malaga
  fr: escapades-depuis-malaga
  it: gite-da-malaga
  pt: escapadinhas-desde-malaga
reservasArriba: true
actividades:
  - caminito-del-rey-guiado-desde-malaga
  - ronda-setenil-desde-malaga
  - cuevas-nerja-frigiliana-desde-malaga
  - gibraltar-desde-malaga
  - cuevas-nerja-entrada
  - cordoba-mezquita-desde-malaga
  - caminito-del-rey-entrada-guia-oficial
  - antequera-dolmenes-torcal-excursion-desde-malaga
  - mijas-marbella-puerto-banus-excursion-desde-malaga
imagen_portada: "/images/guias/escapadas-desde-malaga.jpg"
imagen_alt: "Frigiliana, a white village in the Axarquía"
---

**Málaga is the best base on the Costa del Sol for day trips.** Within an hour and a half you have white villages clinging to ravines, caves and beaches, lunar landscapes and even the Rock of Gibraltar. This guide sorts the best day outings by how much time you have and how to get there, with or without a car.

## Day trips with transport from Málaga

| Activity | Rating | From |
| --- | --- | --- |
| [Caminito del Rey guided tour](/en/cities/malaga/activities/caminito-del-rey-guided-tour-from-malaga) | 4.9★ (19,083) | €72 |
| [Ronda and Setenil de las Bodegas](/en/cities/malaga/activities/ronda-setenil-day-trip-from-malaga) | 4.7★ (8,742) | €34 |
| [Nerja Caves, Nerja and Frigiliana](/en/cities/malaga/activities/nerja-caves-frigiliana-from-malaga) | 4.6★ (3,192) | €69 |
| [Gibraltar](/en/cities/malaga/activities/gibraltar-day-trip-from-malaga) | 4.6★ (5,510) | €35 |
| [Córdoba with Mosque ticket](/en/cities/malaga/activities/cordoba-mosque-day-trip-from-malaga) | 4.5★ (753) | €76 |

Besides the **Caminito del Rey** (which deserves its own guide: [how to visit it](/en/guides/malaga/caminito-del-rey-how-to-visit)), these are the trips that really pay off.

## The best day trips

| Destination | Distance | Ideal for |
| --- | --- | --- |
| Nerja and Frigiliana | 1h | Caves, the Balcón de Europa and a white village |
| Antequera and El Torcal | 45 min | Dolmens and karst landscape |
| Ronda | 1h 45min | The gorge and the Puente Nuevo |
| Mijas | 40 min | A white village with sea views |
| Marbella | 40 min | Old town and Puerto Banús |
| Gibraltar | 1h 15min | The Rock, the monkeys and the tunnel |

## Nerja and Frigiliana

An hour along the coast, **Nerja** has the **Balcón de Europa** (a viewpoint over the Mediterranean) and the spectacular **[Nerja Caves](/en/guides/malaga/nerja-caves-tickets)**, with giant formations. Ten minutes away, **Frigiliana**, one of the prettiest white villages in Spain, of steep streets and flowers. A perfect day combining cave, beach and village.

Book the caves for the first slot (10:00), have lunch in Frigiliana and finish at the Balcón de Europa. Going by car or bus, buy the timed cave ticket on its own; the organised trip bundles everything.

[actividad: nerja-caves-entry-ticket]

## Antequera and El Torcal

Forty-five minutes away, **Antequera** holds the prehistoric **dolmens** (a UNESCO site) and, above, **El Torcal de Antequera**, a karst landscape of impossibly shaped rocks, ideal for an easy walk. Add the Peña de los Enamorados in the background.

## Ronda

An hour and three quarters away, **Ronda** is the mountain jewel: a city split by **El Tajo**, a 100-metre gorge crossed by the **Puente Nuevo**, with one of the oldest bullrings in Spain. One of the most famous images in the country. What to see there and in what order is in [Ronda in one day](/en/guides/malaga/ronda-in-one-day).

## Mijas, Marbella and the coast

Forty minutes away, **Mijas** is a white village with viewpoints over the sea; **Marbella** combines a charming old town with the glamour of **Puerto Banús**. Both are good half-day plans with a beach.

## Gibraltar

An hour and a quarter away, the **Rock of Gibraltar** (British territory) offers the climb up the Rock, the famous **monkeys** (macaques), caves and views of Africa. Bring your passport/ID: you cross a border.

## Practical: transport, tickets and paperwork

- **Buses from Málaga bus station (next to María Zambrano):** to Nerja, 1 hour and €5–6, every 30–60 minutes; to Marbella, 45 minutes and €8–9; to Antequera, 1 hour and €6; to Ronda, 2 hours and €12–14 (as of 2026). For Mijas Pueblo, take Cercanías C-1 to Fuengirola and then bus M-122. Frigiliana has an hourly local bus from Nerja.
- **Ronda by train:** there's no direct train, and in 2026 Renfe has been running replacement buses on the Antequera–Ronda section while the line is repaired. Check Renfe for your date; the direct bus is usually simpler.
- **Nerja Caves:** from €15.50 per adult with audio guide, free for under-6s, with timed slots that sell out at Easter and in August. The visit takes 45 minutes and it's 19 °C inside: bring a light jacket.
- **Antequera Dolmens:** free entry, closed on Mondays. **El Torcal:** free, but on weekend and holiday mornings car access to the top is restricted once the upper car park fills, and you ride a shuttle bus from the lower car park (€2 return). The green trail takes 45 minutes; the yellow, about 2 hours.
- **Gibraltar:** EU citizens can cross with a national ID card; everyone else needs a passport. Leave the car in La Línea (car parks €10–20 a day) and walk across: queues by car at the border can take an hour. Gibraltar uses pounds; euros are accepted at a poor rate, so pay by card. The cable car and the Upper Rock nature reserve are paid separately, about £20 each.
- **Mijas:** skip the donkey taxis; they're a tourist gimmick with no animal-welfare guarantees. The village takes about an hour on foot.

## Getting around

For **Nerja, Marbella, Antequera or Ronda** there are comfortable direct buses; for the inland **white villages** and El Torcal, a **car** gives much more freedom.

## What we don't recommend

1. **Trying two far-off trips on the same day.** Ronda or Gibraltar are a full day each.
2. **Going to Gibraltar without ID.** It's a border: you need a passport or ID card.
3. **Climbing El Torcal in unsuitable footwear.** It's rock; wear shoes with grip.
4. **Forgetting to book the Nerja Caves** on holidays and in summer.

## Common mistakes

> **⚠️ Warning:** the slip-ups we see most.

1. **Underestimating the road to Ronda.** An hour and three quarters each way by car, about two by bus; leave early.
2. **Doing Gibraltar in a rush.** Between the border, the Rock and the monkeys, count the day.
3. **Seeing Nerja without Frigiliana.** They're 10 minutes apart and better together.

## In one sentence

From Málaga, within an hour and a half you have white villages, caves, lunar landscapes and the Rock of Gibraltar: the best larder of day trips in Andalusia, with the Caminito del Rey as the great star apart.
