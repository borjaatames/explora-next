---
titulo: 'Alicante: espectáculo flamenco en El Mentidero con opción de tapas'
slug: flamenco-alicante-tablao-el-mentidero
ciudad: alicante
descripcion: Espectáculo de flamenco en directo con cante, guitarra y baile en el Tablao El Mentidero, en el puerto de Alicante, con opción de menú degustación de tapas. Desde 15 €. 4,8/5 con 1.744 reseñas.
slugs:
  es: flamenco-alicante-tablao-el-mentidero
  en: alicante-flamenco-show-el-mentidero
  it: alicante-spettacolo-flamenco-el-mentidero-tapas
  pt: alicante-flamenco-tablao-el-mentidero-tapas
duracion: 1-2,5 horas
duracionMinutos: 90
precioDesde: 15
moneda: EUR
idiomas:
- es
- en
proveedor: getyourguide
urlReserva: https://www.getyourguide.com/es-es/alicante-l414/alicante-increible-experiencia-de-flamenco-con-opcion-de-menu-de-tapas-t1047369/?partner_id=C71NOAW
cancelacionGratuita: true
horasCancelacion: 24
highlights:
- 'Flamenco en directo: cante, guitarra y baile'
- Tablao en el puerto de Alicante
- Opción con menú degustación de tapas
- Buena visibilidad desde todas las mesas
- Cancelación gratuita hasta 24 h antes
incluye:
- Entrada al espectáculo de flamenco
- Menú degustación de tapas (si eliges esa opción)
noIncluye:
- Bebidas
puntoEncuentro:
  texto: Tablao Flamenco El Mentidero, Muelle de Levante, 6, Alicante.
  descripcionGuia: Ve directamente al tablao, en el puerto, 15 minutos antes del espectáculo.
  latitud: 38.3385
  longitud: -0.478
  zoom: 17
detallesPracticos:
  ticketMovil: true
  confirmacionInmediata: true
  accesibleSilla: true
  edadMinima: 5
  mascotasPermitidas: false
informacionImportante:
  queTraer:
  - Reserva en el móvil
  noAptoPara:
  - Menores de 5 años
  aTenerEnCuenta:
  - Las bebidas no están incluidas en ninguna opción
  - Hay menús sin gluten, sin lactosa o halal bajo petición por WhatsApp
accesibilidad: Accesible en silla de ruedas.
politicaCancelacion: Cancelación gratuita hasta 24 horas antes, con reembolso íntegro.
preguntasFrecuentes:
- pregunta: ¿Incluye cena?
  respuesta: Solo si eliges la opción con menú de tapas; la entrada simple es solo el espectáculo.
- pregunta: ¿Están incluidas las bebidas?
  respuesta: No, en ninguna de las opciones.
- pregunta: ¿Hay menús especiales?
  respuesta: Sí, sin gluten, sin lactosa o halal, pidiéndolo antes por WhatsApp.
- pregunta: ¿Se ve bien el escenario?
  respuesta: Sí, la sala está pensada para que haya buena visibilidad desde todas las mesas.
opinionEditorial: Alicante no es tierra de flamenco, pero este tablao del puerto lo hace muy bien, a juzgar por sus casi 1.750 reseñas con 4,8/5. Desde 15 € solo el espectáculo; la opción con tapas resuelve la cena.
guiasRelacionadas:
- que-ver-en-alicante
categoria: espectaculos
keywords:
- flamenco alicante
- tablao flamenco alicante
- espectaculo flamenco alicante
- el mentidero alicante
imagen: /images/actividades/alicante/el-mentidero/el-mentidero-bailaora-lunares-rojos.webp
imagenAlt: Bailaora con vestido rojo de lunares en el Tablao El Mentidero
galeria:
- src: /images/actividades/alicante/el-mentidero/el-mentidero-escenario-publico.webp
  alt: Cuadro flamenco en el escenario de El Mentidero con el público
- src: /images/actividades/alicante/el-mentidero/el-mentidero-sala-espectaculo.webp
  alt: Sala del tablao durante el espectáculo
- src: /images/actividades/alicante/el-mentidero/el-mentidero-escenario-sillas.webp
  alt: Escenario de El Mentidero con las sillas antes del espectáculo
- src: /images/actividades/alicante/el-mentidero/el-mentidero-bailaor-cuadro.webp
  alt: Bailaor con guitarrista y palmeros en El Mentidero
- src: /images/actividades/alicante/el-mentidero/el-mentidero-bailaora-guitarra.webp
  alt: Bailaora de lunares junto al guitarrista
- src: /images/actividades/alicante/el-mentidero/el-mentidero-bailaora-vestido-rojo.webp
  alt: Bailaora de rojo con los palmeros al fondo
- src: /images/actividades/alicante/el-mentidero/el-mentidero-bailaor-chaqueta-roja.webp
  alt: Bailaor con chaqueta roja en pleno giro
- src: /images/actividades/alicante/el-mentidero/el-mentidero-bailaora-manton.webp
  alt: Bailaora con mantón flecado
- src: /images/actividades/alicante/centro/vista-puerto.webp
  alt: Puerto de Alicante, donde está el tablao
- src: /images/actividades/alicante/centro/explanada-palmeras.webp
  alt: Paseo de la Explanada, junto al puerto
- src: /images/actividades/alicante/centro/castillo-santa-barbara.webp
  alt: Castillo de Santa Bárbara sobre el puerto de Alicante
ratingProveedor: 4.8
numeroOpiniones: 1744
atraccionesRelacionadas:
- gastronomia
publicada: true
destacada: false
fecha: '2026-10-07'
fecha_actualizacion: '2026-10-07'
---

## Qué vas a ver

- **Cante**, **guitarra** y **baile** en directo.
- Un **tablao** de inspiración andaluza en el puerto.

## Cómo funciona

Llegas al tablao del puerto, te sientas en tu mesa y, si has elegido la opción con cena, te sirven el menú de tapas antes o durante el espectáculo de flamenco en directo.

## A quién se lo recomiendo

- A **parejas** que buscan un plan de noche.
- A quien quiere **cenar y ver flamenco** en el mismo sitio.

## A quién NO se lo recomiendo

- A quien busca **bebidas incluidas**.
