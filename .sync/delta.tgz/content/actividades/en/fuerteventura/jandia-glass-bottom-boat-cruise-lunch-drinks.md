---
titulo: 'Fuerteventura: Jandía glass-bottom boat cruise with lunch and drinks'
slug: jandia-glass-bottom-boat-cruise-lunch-drinks
ciudad: fuerteventura
descripcion: Four-hour cruise on the Odysee 3, a glass-bottom boat, along the Jandía Natural Park coast, looking for dolphins and whales, with snorkelling, kayaks, a waterslide, paella and drinks. Pickup in the south. Rated 4.4/5 from 1,602 reviews.
slugs:
  es: barco-fondo-cristal-jandia-comida-bebidas
  en: jandia-glass-bottom-boat-cruise-lunch-drinks
  de: jandia-glasbodenboot-mit-mittagessen
  fr: jandia-bateau-fond-de-verre-dejeuner-boissons
  it: jandia-barca-fondo-vetro-pranzo-bevande
  pt: jandia-barco-fundo-de-vidro-almoco-bebidas
duracion: 4 hours
duracionMinutos: 240
precioDesde: 75
moneda: EUR
idiomas:
- en
- de
- fr
- es
- pl
- it
proveedor: getyourguide
urlReserva: https://www.getyourguide.com/activity-t254507/?partner_id=C71NOAW
cancelacionGratuita: true
horasCancelacion: 24
highlights:
- Glass bottom to look under the sea
- Dolphin and whale spotting off Jandía
- Snorkelling, kayaks and a waterslide
- Paella and drinks on board
- Hotel pickup in the south
incluye:
- Hotel pickup and drop-off (south of the island)
- Glass-bottom boat cruise
- Paella lunch
- Drinks
- Snorkelling, kayaks and waterslide
noIncluye:
- Pickup outside the south of the island (a meeting point is given)
puntoEncuentro:
  texto: Hotel pickup in southern Fuerteventura (Morro Jable, Jandía, Esquinzo and Costa Calma).
  descripcionGuia: If your hotel is outside that area, the operator emails you a pickup point and time after booking.
detallesPracticos:
  ticketMovil: true
  confirmacionInmediata: false
  accesibleSilla: true
  edadMinima: 0
  mascotasPermitidas: false
informacionImportante:
  queTraer:
  - Swimwear and towel
  - Sunscreen
  noAptoPara: []
  aTenerEnCuenta:
  - Let them know if you are vegetarian; there are two food options
  - Authorised Blue Boat for whale and dolphin watching
  - Groups of up to 90 people
accesibilidad: The operator lists the activity as wheelchair accessible.
politicaCancelacion: Free cancellation up to 24 hours before, with a full refund.
preguntasFrecuentes:
- pregunta: Are dolphins guaranteed?
  respuesta: No. The boat looks for dolphins and whales off Jandía, but sightings depend on the day.
- pregunta: Is lunch included?
  respuesta: Yes, a Canarian lunch with paella and drinks on board. There is a vegetarian option if you ask.
- pregunta: Is there hotel pickup?
  respuesta: Yes, in the south of the island. Outside that area you get a meeting point.
- pregunta: Is it good for kids?
  respuesta: Yes, it is designed for families, with a waterslide, kayaks and the glass bottom.
opinionEditorial: It is a big, family-oriented boat, more about fun than quiet sailing, with a lot included for the price. With over 1,600 reviews at 4.4/5 it delivers; if you want a small group or a sailboat, there are more intimate options from Morro Jable.
guiasRelacionadas:
- what-to-see-in-fuerteventura
- cofete-villa-winter-how-to-get-there
categoria: agua
keywords:
- glass bottom boat fuerteventura
- morro jable boat trip
- fuerteventura dolphin boat trip
- jandia cruise with lunch
ratingProveedor: 4.4
numeroOpiniones: 1602
atraccionesRelacionadas:
- mar
publicada: true
indexar: false
destacada: false
fecha: '2026-10-31'
fecha_actualizacion: '2026-10-31'
imagen: /images/actividades/fuerteventura/barco-fondo-cristal/ffv-barcas-fondo-cristal.webp
imagenAlt: "Glass-bottom boats anchored at sea"
galeria:
- src: /images/actividades/fuerteventura/zonas/costa-jandia.webp
  alt: "Coast of the Jandía peninsula"
- src: /images/actividades/fuerteventura/delfines/ffv-delfines-mar-abierto.webp
  alt: "Two dolphins swimming in the open sea"
- src: /images/actividades/fuerteventura/barco-fondo-cristal/ffv-barca-fondo-cristal-orilla.webp
  alt: "Small glass-bottom boat in turquoise water"
- src: /images/actividades/fuerteventura/esnorquel/ffv-esnorquel-fondo-rocoso.webp
  alt: "Person snorkelling over a rocky seabed"
- src: /images/actividades/fuerteventura/delfines/ffv-calderones-aletas.webp
  alt: "Pod of pilot whales swimming at the surface"
- src: /images/actividades/fuerteventura/lobos/paella-vino-a-bordo.webp
  alt: "Paella and wine served on board"
- src: /images/actividades/fuerteventura/zonas/jandia-costa.webp
  alt: "Jandía coast from above"
---

## What you will see

- The **Jandía Natural Park** coast and its beaches from the sea.
- The seabed through the **glass viewing deck**.
- With luck, **dolphins**, **whales** or turtles.

## How it works

You are picked up at your hotel in the south and board the Odysee 3. You sail along the Jandía coast looking for whales and dolphins, with music on board, and stop to swim, snorkel, kayak or use the waterslide. A Canarian lunch with paella is served at midday, you can go below to look through the glass bottom, and at the end you are driven back to your hotel.

## Who I recommend it for

- **Families with children**, for the slide and the glass bottom.
- Anyone staying in **Morro Jable, Jandía or Costa Calma** wanting an all-inclusive boat day.

## Who I don't recommend it for

- Anyone after a **small group** or quiet sailing: up to 90 people come aboard.
