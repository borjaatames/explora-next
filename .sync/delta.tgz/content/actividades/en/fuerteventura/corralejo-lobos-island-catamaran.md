---
titulo: 'Corralejo: Lobos Island catamaran with lunch and snorkelling'
slug: corralejo-lobos-island-catamaran
ciudad: fuerteventura
descripcion: 4-hour catamaran trip from Corralejo to Lobos Island, anchoring off La Concha, with paella, drinks, snorkelling, kayaking and paddleboarding, and pickup in Corralejo. Rated 4.8/5 from more than 1,100 reviews.
slugs:
  es: catamaran-isla-lobos-corralejo
  en: corralejo-lobos-island-catamaran
  pt: corralejo-catamara-ilha-de-lobos-almoco-snorkel
duracion: 4 hours
duracionMinutos: 240
precioDesde: 75
moneda: EUR
idiomas:
- en
- es
proveedor: getyourguide
urlReserva: https://www.getyourguide.com/es-es/fuerteventura-l419/fuerteventura-tour-de-4-horas-navegando-de-la-isla-de-lobos-t210330/?partner_id=C71NOAW
cancelacionGratuita: true
horasCancelacion: 24
highlights:
- Sail along the coast to Lobos, past La Caldera
- Anchor off La Concha beach
- Snorkelling, kayaking and paddleboarding included
- Paella with soft drinks, beer, wine, water, coffee and tea
- Pickup from hotels and points in Corralejo
incluye:
- Pickup and return in Corralejo
- Paella
- Drinks (soft drinks, beer, wine, water, coffee and tea)
- Snorkelling, kayaking and paddleboarding
- Motorboat transfer and guided mini-tour of the islet
- Underwater photos
- Towels and sunscreen
noIncluye:
- Pickup outside Corralejo
puntoEncuentro:
  texto: Pickup in Corralejo (hotels and points listed when booking).
  descripcionGuia: There are eight pickup points in Corralejo, including the Aloe Club Resort, Alua Suites, Bahiazul, Riu Oliva Beach and Playa Park Zensation hotels, plus Fuerchina, Burger King and the Fuertecharter office.
  latitud: 28.7406
  longitud: -13.8637
  zoom: 13
detallesPracticos:
  ticketMovil: true
  confirmacionInmediata: true
  accesibleSilla: false
  edadMinima: 0
  mascotasPermitidas: false
informacionImportante:
  queTraer:
  - Swimwear
  - Hat and sunglasses
  noAptoPara: []
  aTenerEnCuenta:
  - The morning tour runs from 10:00 to 14:00
  - The itinerary may change depending on the sea
  - Snorkelling, kayaking, paddleboarding, motorboat and lunch are optional during the time at Lobos
accesibilidad: The listing gives no accessibility information; check with the operator before booking.
politicaCancelacion: Free cancellation up to 24 hours before, with a full refund.
preguntasFrecuentes:
- pregunta: Do you go ashore on Lobos?
  respuesta: The catamaran anchors off La Concha beach and the tour includes a motorboat transfer and a guided mini-tour of the islet.
- pregunta: What are the times?
  respuesta: The morning tour runs from 10:00 to 14:00, with pickup beforehand in Corralejo.
- pregunta: What's for lunch?
  respuesta: Paella, with soft drinks, beer, wine, water, coffee and tea.
- pregunta: Do I need the Lobos permit?
  respuesta: Ask the operator when booking whether they handle the access authorisation; if you're going to set foot on the island, you need one.
opinionEditorial: 'It''s the most comfortable way to see Lobos and one of the best rated: the boat, food and water gear are included and you don''t have to worry about ferry times. It costs about four ferry tickets, though. If you''d rather walk to the lighthouse and climb La Caldera, the ferry gives you more time ashore.'
guiasRelacionadas:
- lobos-island-how-to-get-there
- what-to-see-in-fuerteventura
categoria: agua
keywords:
- lobos island catamaran
- corralejo lobos boat trip
- corralejo catamaran
- lobos island snorkelling
imagen: /images/actividades/fuerteventura/catamaran-lobos.webp
imagenAlt: Catamaran anchored off Lobos Island
galeria:
- src: /images/actividades/fuerteventura/lobos/playa-la-concha-lobos.webp
  alt: La Concha beach on the Isle of Lobos with its turquoise lagoon
- src: /images/actividades/fuerteventura/zonas/isla-de-lobos-kitesurf.webp
  alt: Lobos Island off the beach, with kitesurfers
- src: /images/actividades/fuerteventura/lobos/esnorquel-fondo-rocoso.webp
  alt: Snorkeller swimming over a rocky seabed
- src: /images/actividades/fuerteventura/zonas/montana-caldera-lobos.webp
  alt: La Caldera hill on Lobos Island
- src: /images/actividades/fuerteventura/lobos/paddle-surf-agua-turquesa.webp
  alt: Aerial view of a stand-up paddle boarder on turquoise water
- src: /images/actividades/fuerteventura/zonas/faro-martino.webp
  alt: Martiño lighthouse on Lobos Island
- src: /images/actividades/fuerteventura/lobos/paella-vino-a-bordo.webp
  alt: Paella and white wine served on a boat table
- src: /images/actividades/fuerteventura/zonas/bahia-corralejo.webp
  alt: Corralejo bay with Lobos in the background
- src: /images/actividades/fuerteventura/zonas/isla-de-lobos-atardecer.webp
  alt: Lobos Island at dusk
ratingProveedor: 4.8
numeroOpiniones: 1183
atraccionesRelacionadas:
- isla-lobos
- lobos
publicada: true
indexar: false
destacada: false
fecha: '2026-10-24'
fecha_actualizacion: '2026-10-25'
---

## What you'll see

- The **Corralejo** coast and **Lobos** islet from the sea.
- **La Caldera**, Lobos's half-submerged volcano.
- **La Concha beach**, a lagoon of white sand and calm water.

## How it works

You're picked up at one of eight points in **Corralejo** (several hotels, Burger King, Fuerchina or the Fuertecharter office) and a 15-minute van ride takes you to the boat. The catamaran sails for **about an hour** along the coast, passes **La Caldera** and anchors off **La Concha**.

There you have about **40 minutes** for **snorkelling, kayaking or paddleboarding**, a **motorboat** ride with a guided mini-tour of the islet, and **an hour for lunch**: paella with drinks. The trip back to Corralejo is a relaxed half-hour sail. The morning tour runs from **10:00 to 14:00**.

## Practical tips

- **Permit:** if you set foot on the island you need the council's authorisation; ask the operator whether they handle it. We explain it in our [guide to getting to Lobos](/en/guides/fuerteventura/lobos-island-how-to-get-there).
- **Sea:** the crossing is short, but with a strong trade wind the boat moves. The itinerary may change.
- **What to bring:** swimwear, a hat and sunglasses. Towels and sunscreen are included.
- **Photos:** the crew takes underwater photos during the snorkelling.

## Who I'd recommend it to

- Anyone who wants to see Lobos **without organising anything**: boat, food and activities in one payment.
- **Couples and families** looking for a sea day with swimming.
- Anyone staying in **Corralejo**.

## Who I would NOT recommend it to

- Anyone who wants to **walk on Lobos** to the lighthouse: the ferry gives you more hours ashore.
- Travellers on a tight budget: the ferry costs much less.
