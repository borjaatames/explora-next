---
titulo: 'Gran Canaria: luxury morning catamaran cruise with lunch'
slug: gran-canaria-luxury-catamaran-cruise-lunch
ciudad: gran-canaria
descripcion: '4.5-hour cruise from Puerto Rico along the southwest coast on a 20-guest catamaran, with two swim stops, paddleboarding, kayaking, lunch and drinks included. Rated 4.8/5 from 1,066 reviews.'
slugs:
  es: catamaran-lujo-gran-canaria-almuerzo
  en: gran-canaria-luxury-catamaran-cruise-lunch
  de: gran-canaria-luxus-katamaran-mit-mittagessen
  fr: gran-canaria-croisiere-catamaran-luxe-dejeuner
  pt: gran-canaria-catamara-luxo-almoco
duracion: 4 hours 30 minutes
duracionMinutos: 270
precioDesde: 84
moneda: EUR
idiomas:
- en
- es
- de
- fr
proveedor: getyourguide
urlReserva: https://www.getyourguide.com/activity-t430633/?partner_id=C71NOAW
cancelacionGratuita: true
horasCancelacion: 24
highlights:
- Maximum 20 guests on board
- Swim stop at El Perchel Bay
- Lunch at anchor in Tasarte Bay
- Paddleboarding, kayaking and snorkelling
- Beer, sangria and soft drinks included
incluye:
- Catamaran cruise
- Soft drinks, beer, sangria, water and coffee
- Lunch (breaded chicken or fish with Canarian potatoes, mojo and salad)
- SUP boards and kayaks
- Snorkelling gear
- Pickup and drop-off in the south of the island
noIncluye:
- Cocktails and premium drinks
- Jet ski and parasailing (optional extras)
puntoEncuentro:
  texto: Puerto Base, Puerto Rico harbour. Departure at 10:30.
  descripcionGuia: Pickup in the south of the island is included; the exact time appears when you check availability.
detallesPracticos:
  ticketMovil: true
  confirmacionInmediata: false
  accesibleSilla: false
  edadMinima: 0
  mascotasPermitidas: false
informacionImportante:
  queTraer:
  - Towel
  - Beachwear
  - Sunscreen
  - Camera
  noAptoPara: []
  aTenerEnCuenta:
  - The menu is seasonal and may change without notice
  - The route depends on sea and weather conditions
  - Back in Puerto Rico around 15:00
accesibilidad: Check accessibility with the provider.
politicaCancelacion: Free cancellation up to 24 hours before, with a full refund.
preguntasFrecuentes:
- pregunta: What's for lunch?
  respuesta: A freshly prepared lunch on board, with a choice of breaded chicken or fresh fish, served with Canarian potatoes, mojo, salad and bread.
- pregunta: Are drinks free?
  respuesta: Beer, sangria, soft drinks, water and coffee are included. Cocktails, champagne and premium spirits cost extra.
- pregunta: Where does it leave from?
  respuesta: Puerto Base in Puerto Rico harbour, at 10:30. Pickup in the south is included.
- pregunta: What water activities are there?
  respuesta: Paddleboarding, kayaking, snorkelling and swimming at El Perchel and Tasarte. Jet ski and parasailing are extra.
opinionEditorial: "What sets it apart from Puerto Rico's big catamarans is the group size: 20 guests at most, with plenty of room in the shade and the sun. With lunch, drinks and water gear included, the price is fair. It's a relaxed swim-and-coast trip, not a dolphin-watching cruise."
guiasRelacionadas:
- what-to-see-in-gran-canaria
categoria: agua
keywords:
- puerto rico gran canaria catamaran
- gran canaria boat trip with lunch
- luxury catamaran gran canaria
- mogan boat trip
ratingProveedor: 4.8
numeroOpiniones: 1066
atraccionesRelacionadas:
- mar
- mogan
publicada: true
indexar: false
destacada: false
fecha: '2026-10-31'
fecha_actualizacion: '2026-10-31'
imagen: /images/actividades/gran-canaria/catamaran/fgc-proa-catamaran-agua-clara.webp
imagenAlt: "Bow of a catamaran over clear water"
galeria:
- src: /images/actividades/gran-canaria/mar/puerto-rico-puerto.webp
  alt: "The harbour of Puerto Rico de Gran Canaria, the departure point"
- src: /images/actividades/gran-canaria/mogan-kayak/costa-rocosa-mogan.webp
  alt: "Rocky coastline in south-west Gran Canaria"
- src: /images/actividades/gran-canaria/catamaran/fgc-catamaran-fondeado-aguas-turquesa.webp
  alt: "Catamaran at anchor in turquoise water"
- src: /images/actividades/gran-canaria/catamaran/fgc-fondo-rocoso-agua-cristalina.webp
  alt: "Rocky seabed under crystal-clear water, ideal for snorkelling"
- src: /images/actividades/gran-canaria/mogan/mogan-acantilados.webp
  alt: "Cliffs and houses on the Mogán coast seen from the sea"
- src: /images/actividades/gran-canaria/catamaran/fgc-catamaranes-fondeados-orilla.webp
  alt: "Aerial view of catamarans anchored in turquoise water near the shore"
- src: /images/actividades/gran-canaria/catamaran/x-catamaran-pexels-9995827.webp
  alt: "Sailing boats moored in a marina"
---

## What you will see

- Gran Canaria's **southwest coast**, with volcanic cliffs and coves.
- **El Perchel Bay**, the first swim stop.
- The quiet bay of **Tasarte**, where the boat anchors for lunch.

## How it works

You're picked up in the south and leave Puerto Rico at 10:30 heading west. At El Perchel there's time to swim, paddleboard, kayak or snorkel. The boat then anchors in Tasarte, where lunch is served while you can keep swimming. You cruise slowly back along the coast and reach Puerto Rico around 15:00.

## Who I recommend it for

- **Couples**, **families** and **groups of friends** who want an unhurried day at sea.
- Anyone who prefers a **small boat** to the mass-market catamarans.

## Who I don't recommend it for

- Anyone mainly after **dolphin sightings**.
- Anyone prone to seasickness.
