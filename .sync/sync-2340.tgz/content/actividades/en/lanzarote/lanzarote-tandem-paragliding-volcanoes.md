---
titulo: "Lanzarote: tandem paragliding over volcanoes and the Atlantic"
slug: lanzarote-tandem-paragliding-volcanoes
ciudad: lanzarote
descripcion: Tandem paragliding flight with a licensed pilot over Lanzarote's volcanoes, cliffs and Atlantic coast, lasting 20 to 40 minutes depending on the option and suitable for beginners from age 5. Rated 4.9/5 from 205 reviews.
slugs:
  es: parapente-biplaza-volcanes-lanzarote
  en: lanzarote-tandem-paragliding-volcanoes
  de: lanzarote-tandem-paragliding-vulkane
  fr: lanzarote-parapente-biplace-volcans
  it: lanzarote-parapendio-biposto-vulcani
duracion: 20 minutes
duracionMinutos: 20
precioDesde: 120
moneda: EUR
idiomas:
- en
- es
- de
- hu
- it
- 'no'
- fr
proveedor: getyourguide
urlReserva: https://www.getyourguide.com/activity-t434719/?partner_id=C71NOAW
cancelacionGratuita: true
horasCancelacion: 24
highlights:
- Tandem flight with an internationally licensed pilot
- Views of volcanoes, cliffs and the Atlantic coast
- No experience needed, from age 5
- Several launch sites so flights run most days
- Groups of up to 5 people
incluye:
- Pilot and assistance
- Safety briefing
- Helmet, harness and gloves
noIncluye:
- Hotel pickup and drop-off
- Flight photos and video (depending on the option)
puntoEncuentro:
  texto: Directly at the launch site, which varies with the option and the day's conditions.
  descripcionGuia: The provider confirms the exact time and place by WhatsApp or email 24 to 48 hours before. Arrive 15-20 minutes before your flight.
detallesPracticos:
  ticketMovil: true
  confirmacionInmediata: false
  accesibleSilla: false
  edadMinima: 5
  mascotasPermitidas: false
informacionImportante:
  queTraer:
  - Windbreaker
  - Sunglasses
  - Long-sleeved top and long trousers
  - Closed sports shoes
  noAptoPara:
  - Children under 5
  - Pregnant women
  - Wheelchair users
  - People over 120 kg
  - People with a cold
  aTenerEnCuenta:
  - Weather-dependent; if flying isn't possible, it's rescheduled or refunded
  - Any time change is agreed with you first
  - The full experience, including preparation, takes 45 to 60 minutes
accesibilidad: Not accessible for wheelchair users.
politicaCancelacion: Free cancellation up to 24 hours before, with a full refund. If weather prevents flying, it's rescheduled or refunded.
preguntasFrecuentes:
- pregunta: Do I need experience?
  respuesta: No. You fly tandem with a licensed pilot who guides you step by step.
- pregunta: How long is the flight?
  respuesta: 20 to 40 minutes depending on the option booked; with preparation, the whole experience takes 45 to 60 minutes.
- pregunta: What if the weather is bad?
  respuesta: The flight is rescheduled by agreement with you, or refunded.
- pregunta: Are there weight or age limits?
  respuesta: Yes, up to 120 kg and from age 5.
opinionEditorial: Rated 4.9 out of 5, it's one of the island's best-reviewed activities and a unique way to take in the volcanic landscape from above. The basic flight is short for the price, so if you're keen, look at the longer options and the photo package.
guiasRelacionadas:
- what-to-see-in-lanzarote
categoria: aventura
keywords:
- lanzarote paragliding
- tandem paragliding lanzarote
- paragliding over volcanoes lanzarote
- lanzarote paragliding flight
ratingProveedor: 4.9
numeroOpiniones: 205
atraccionesRelacionadas:
- volcanes
- isla
publicada: true
indexar: false
destacada: false
fecha: '2026-10-31'
fecha_actualizacion: '2026-10-31'
imagen: /images/actividades/lanzarote/parapente/flz-biplaza-nubes.webp
imagenAlt: "Tandem paraglider among clouds"
galeria:
- src: /images/actividades/lanzarote/timanfaya/flz-montanas-colores.webp
  alt: "Red and ochre volcanic mountains in Timanfaya"
- src: /images/actividades/lanzarote/parapente/flz-biplaza-cielo-claro.webp
  alt: "Tandem paraglider flying in a clear sky"
- src: /images/actividades/lanzarote/famara/flz-risco-famara.webp
  alt: "Famara cliffs seen from La Caleta de Famara"
- src: /images/actividades/lanzarote/parapente/flz-dos-velas.webp
  alt: "Two paragliders flying together"
- src: /images/actividades/lanzarote/zonas/valle-volcanico.webp
  alt: "Volcanic valley in Lanzarote"
- src: /images/actividades/lanzarote/parapente/x-parapente-pixabay-5292803.webp
  alt: "Tandem paragliding flight"
- src: /images/actividades/lanzarote/parapente/x-parapente-wikimedia-01.webp
  alt: "Paraglider getting ready for take-off on the mountain"
---

## What you will see

- The **volcanoes** and reddish rock formations from the air.
- **Cliffs** and beaches along the Atlantic coast.
- Lanzarote's sea and landscape on a **silent flight**.

## How it works

You meet directly at the launch site confirmed a day or two before. After the safety briefing and kitting up, you take off with the pilot and fly for 20 to 40 minutes depending on the option. If the wind isn't right, another day is agreed or you get your money back.

## Who I recommend it for

- Anyone wanting to **fly for the first time** with no experience.
- **Families** with children aged 5 and up.

## Who I don't recommend it for

- **Pregnant women** or people over **120 kg**.
- Anyone with a **fixed day** and no flexibility: it's weather-dependent.
