---
titulo: 'Alicante: Canelobre Caves and Busot with a local guide'
slug: canelobre-caves-busot-guided-tour-alicante
ciudad: alicante
descripcion: Half-day trip from Alicante in a group of up to 7 to the Canelobre Caves, with guided visit and entry, plus a walk around the village of Busot with a drink included. Rated 4.9/5 from 207 reviews.
slugs:
  es: cuevas-canelobre-busot-tour-guiado-alicante
  en: canelobre-caves-busot-guided-tour-alicante
duracion: 3 hours
duracionMinutos: 180
precioDesde: 55
moneda: EUR
idiomas:
- en
proveedor: getyourguide
urlReserva: https://www.getyourguide.com/activity-t390197/?partner_id=C71NOAW
cancelacionGratuita: true
horasCancelacion: 24
highlights:
- Guided visit to the Canelobre Caves
- Groups of up to 7 people
- Guided walk in Busot
- Drink included at a village café
- Transport from Alicante
incluye:
- Return transport from Alicante in a 7-seat hybrid vehicle
- Guided cave visit, not mixed with other groups
- Canelobre Caves entry ticket
- Guided walk in Busot
- One drink in Busot (coffee, wine, beer or soft drink)
noIncluye: []
puntoEncuentro:
  texto: Hotel Meliá Alicante (Terra terrace), Plaza Puerta del Mar, 3, Alicante.
  descripcionGuia: Your guide meets you at the meeting point by the Meliá hotel, facing the port.
detallesPracticos:
  ticketMovil: true
  confirmacionInmediata: false
  accesibleSilla: false
  edadMinima: 0
  mascotasPermitidas: false
informacionImportante:
  queTraer:
  - Comfortable shoes
  noAptoPara:
  - People with reduced mobility
  - Wheelchair users
  aTenerEnCuenta:
  - The cave visit involves several flights of stairs
  - Groups of up to 7 people
  - The guide speaks English
accesibilidad: Not wheelchair accessible.
politicaCancelacion: Free cancellation up to 24 hours before, with a full refund.
preguntasFrecuentes:
- pregunta: Is cave entry included?
  respuesta: Yes, entry to the Canelobre Caves is included.
- pregunta: How long is the cave visit?
  respuesta: Between 45 minutes and an hour, guided.
- pregunta: Are there many stairs?
  respuesta: Yes, the cave has several flights of stairs.
- pregunta: What language is it in?
  respuesta: English.
opinionEditorial: The Canelobre Caves are among the most spectacular in the Valencia region and only half an hour from Alicante. Going in a group of seven with a local family business and finishing with a drink in Busot makes for a very well-rounded morning; the 4.9/5 rating backs it up.
guiasRelacionadas:
- costa-blanca-day-trips-from-alicante
categoria: excursionesDia
keywords:
- canelobre caves
- canelobre caves from alicante
- busot canelobre tour
- caves near alicante
ratingProveedor: 4.9
numeroOpiniones: 207
atraccionesRelacionadas:
- excursiones
publicada: true
indexar: false
destacada: false
fecha: '2026-10-31'
fecha_actualizacion: '2026-10-31'
imagen: /images/actividades/alicante/fal-canelobre/fal-canelobre-formaciones-iluminadas.webp
imagenAlt: "Formations in the Canelobre Caves lit with coloured lights"
galeria:
- src: /images/actividades/alicante/fal-canelobre/fal-cabezon-oro-canelobre.webp
  alt: "Cabeçó d'Or range, home to the Canelobre Caves"
- src: /images/actividades/alicante/fal-canelobre/fal-canelobre-sala-estalactitas.webp
  alt: "Lit stalactites in the Canelobre's great chamber"
- src: /images/actividades/alicante/fal-canelobre/fal-canelobre-columnas.webp
  alt: "Columns and flowstone in the Canelobre Caves"
- src: /images/actividades/alicante/fal-canelobre/fal-vista-busot.webp
  alt: "View over the landscape from the Busot caves area"
- src: /images/actividades/alicante/fal-canelobre/fal-canelobre-estalagmita-color.webp
  alt: "Lit stalagmite in the Canelobre Caves"
- src: /images/actividades/alicante/fal-canelobre/x-canelobre-pexels-16455426.webp
  alt: "Rock formations in the Canelobre Caves"
---

## What you will see

- The **Canelobre Caves**, a huge cavern over 80 metres long and up to 30 metres high.
- Illuminated **stalactites and stalagmites**.
- Mountain and sea views from the entrance.
- **Busot**, a hilltop village of narrow lanes.

## How it works

You leave central Alicante in a 7-seat hybrid vehicle and reach the caves in about half an hour, where your guide takes you through for 45 minutes to an hour. Then you head down to Busot for a guided stroll and a drink at a café before returning.

## Who I recommend it for

- Anyone wanting to **get away from the coast** for a few hours without a car.
- People who value **very small groups** and a local guide.

## Who I don't recommend it for

- People with **reduced mobility**: there are lots of stairs.
