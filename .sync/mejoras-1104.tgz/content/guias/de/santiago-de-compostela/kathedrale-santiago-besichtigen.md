---
titulo: "Kathedrale von Santiago: so besichtigt man sie (Pórtico, Dächer und Botafumeiro)"
descripcion: "Guide zur Kathedrale von Santiago: was kostenlos ist und was kostenpflichtig, das Pórtico de la Gloria, die Dächer, der Botafumeiro und die Pilgermesse. Tipps."
categoria: "santiago-de-compostela"
slug: "kathedrale-santiago-besichtigen"
fecha: "2026-05-18"
fecha_actualizacion: "2026-10-23"
autor: Borja
publicada: true
destacada: false
imagen_portada: "/images/guias/catedral-de-santiago-como-visitar.jpg"
imagen_alt: "Pórtico de la Gloria in der Kathedrale von Santiago de Compostela"
tiempo_lectura: 4
keywords:
  - "kathedrale von santiago"
  - "pórtico de la gloria"
  - "botafumeiro"
  - "dächer kathedrale santiago"
  - "pilgermesse santiago"
slugs:
  es: catedral-de-santiago-como-visitar
  en: santiago-cathedral-how-to-visit
  de: kathedrale-santiago-besichtigen
  fr: cathedrale-de-saint-jacques-comment-la-visiter
  it: cattedrale-di-santiago-come-visitarla
  pt: catedral-de-santiago-como-visitar
actividades:
  - santiago-portico-gloria-catedral-tour
  - catedral-santiago-museo-tour-guiado
  - catedral-museo-casco-antiguo-santiago
  - cubiertas-catedral-santiago-tour
opciones:
  - ficha: catedral-santiago-museo-tour-guiado
    etiqueta: Am günstigsten
  - ficha: cubiertas-catedral-santiago-tour
    etiqueta: Über die Dächer
  - ficha: santiago-portico-gloria-catedral-tour
    etiqueta: Mit Altstadt
---

**Die Kathedrale von Santiago ist das Ziel des Jakobswegs und das Herz der Stadt**, doch ihr Besuch verwirrt viele: Kostet der Eintritt? Was ist der Botafumeiro? Kann man aufs Dach steigen? Die kurze Antwort ist: **Das Betreten des Gotteshauses ist kostenlos**, aber es gibt kostenpflichtige Erlebnisse, die sich sehr lohnen. Dieser Guide erklärt, was man sehen, was man buchen und wie man sich organisieren sollte.

Der Schlüssel: Trenn das Kostenlose (das Gotteshaus, das Grab des Apostels) von den Sonderbesichtigungen (Pórtico de la Gloria, Dächer, Museum), für die ein Ticket und manchmal eine vorherige Reservierung nötig sind.

## Was kostenlos ist

- **Das Gotteshaus.** Die Kathedrale zu betreten, um zu beten oder sie zu besichtigen, ist **kostenlos**: täglich **7:00-21:00 Uhr**, Eingang über die Puerta de Platerías (im Sommer samstags bis 20:30 Uhr wegen der Pilgervigil).
- **Das Grab des Apostels.** Die Krypta mit den Reliquien des Heiligen Jakobus unter dem Hochaltar.
- **Die Umarmung des Apostels** (wenn zugänglich), hinter dem Altar.
- **Die Pilgermesse**, täglich (siehe unten).

[actividad: santiago-portico-gloria-catedral-tour]

## Was kostenpflichtig ist (und sich lohnt)

| Besichtigung | Was sie beinhaltet |
| --- | --- |
| Pórtico de la Gloria | Das Meisterwerk von Meister Mateo, restauriert (Ticket mit Zeitfenster) |
| Dächer | Geführte Tour über das Granitdach, mit Ausblick |
| Kathedralmuseum | Kreuzgang, Schatzkammer, Krypta und Pazo de Xelmírez |

> **⭐ Tipp:** Das **Pórtico de la Gloria** und die **Dächer** besichtigt man mit **Ticket und Zeitfenster**, und sie sind in der Hochsaison schnell ausverkauft. Buch sie online im Voraus; es sind die beiden lohnendsten Erlebnisse über das Gotteshaus hinaus.

## Welches Ticket solltest du wählen?

| Option | Preis | Was enthalten ist | Für wen |
| --- | --- | --- | --- |
| [Kathedrale und Museum ohne Anstehen](/en/cities/santiago-de-compostela/activities/santiago-cathedral-museum-guided-tour) | 25 € | Guide, Tickets für Kathedrale und Museum; Pórtico de la Gloria je nach gewählter Option | Wer Kathedrale und Museum mit Erklärungen sehen will |
| [Dächer und Carraca-Turm](/en/cities/santiago-de-compostela/activities/santiago-cathedral-rooftops-tour) | 37 € | Zugang zu den Dächern und zum Carraca-Turm, Kathedralmuseum, Guide auf Spanisch | Wer den Blick vom Dach über die Altstadt will |
| [Pórtico de la Gloria, Kathedrale und Altstadt](/en/cities/santiago-de-compostela/activities/santiago-portico-of-glory-cathedral-city-tour) | 40 € | Eintritt zum Pórtico de la Gloria, offizieller Guide, Kathedrale und Altstadt | Wer das Pórtico und einen Altstadtrundgang verbinden will |

## Der Botafumeiro

Der **Botafumeiro** ist das riesige Weihrauchfass (über 50 kg), das acht *Tiraboleiros* durch das Querschiff schwingen lassen. **Er fliegt nicht jeden Tag**: Das geschieht bei bestimmten **Pilgermessen** und an ausgewählten Terminen (er kann auch von Gruppen angefragt und bezahlt werden). Wer ihn sehen möchte, sollte **vorher den offiziellen Kalender prüfen** und früh zur Messe kommen.

## Die Pilgermesse

Es handelt sich um die tägliche Messe (üblicherweise um **12:00 Uhr**, mit einer weiteren am Nachmittag), in der der Camino seinen Höhepunkt findet. Sie füllt die Kathedrale: Wer einen Platz möchte, sollte **deutlich früher** kommen. Während der Messe ist keine touristische Besichtigung möglich.

> **Hinweis:** Seit **Freitag, dem 16. Oktober 2026**, finden die Pilgermessen (9:30, 12:00 und 19:30 Uhr) bis auf Weiteres in der nahen **Kirche San Agustín** statt, weil in der Hauptkapelle der Kathedrale gebaut wird. Nur die Messe um 7:30 Uhr bleibt in der Kathedrale. Die Besichtigungen sind nicht betroffen. Ob der Botafumeiro während der Arbeiten schwingt, geht aus der Mitteilung nicht hervor: Prüf das vorher auf der Website der Kathedrale.

## Praktische Tipps

- **Angemessen kleiden:** Es ist ein aktiv genutztes Gotteshaus.
- **Große Rucksäcke sind im Inneren nicht erlaubt**; in der Nähe gibt es eine Gepäckaufbewahrung für Pilger.
- Kombiniere die Kathedrale mit dem Rest der Altstadt in [Santiago an einem Tag](/de/guides/santiago-de-compostela/santiago-in-einem-tag).
- Die **Porta Santa** (Quintana) öffnet nur im **Heiligen Jahr**.

## Was wir NICHT empfehlen

1. **Davon ausgehen, den Botafumeiro zu sehen.** Er fliegt nur bei bestimmten Messen und Terminen; prüf das vorher.
2. **Pünktlich um 12:00 Uhr zur Messe kommen.** Sie wird voll sein; geh früher und prüf, wo sie stattfindet.
3. **Das Pórtico de la Gloria auslassen, weil man nicht gebucht hat.** Es ist das Juwel der Kathedrale.
4. **Mit einem riesigen Rucksack auftauchen.** Man lässt dich nicht hinein; nutz die Gepäckaufbewahrung.

[actividad: catedral-museo-casco-antiguo-santiago]

## Typische Fehler

> **⚠️ Hinweis:** die Fehler, die wir am häufigsten sehen.

1. **Pórtico oder Dächer in der Saison nicht buchen:** Sie sind schnell ausverkauft.
2. **Das kostenlose Gotteshaus mit den kostenpflichtigen Besichtigungen verwechseln.** Das sind unterschiedliche Dinge.
3. **Den Kalender des Botafumeiro nicht prüfen.** Das ist die häufigste Enttäuschung.

## In einem Satz

Die Kathedrale von Santiago besichtigt man kostenlos in ihrem Gotteshaus und am Grab des Apostels, und kostenpflichtig in ihren Schätzen – Pórtico de la Gloria und Dächer, die man am besten reserviert –, mit dem Botafumeiro als magischem Moment, wenn man Glück hat. Sie ist das Herz von [Santiago an einem Tag](/de/guides/santiago-de-compostela/santiago-in-einem-tag).
