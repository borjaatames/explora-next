---
titulo: 'Valencia: Oceanogràfic and Science Museum combo ticket'
slug: oceanografic-science-museum-combo-ticket
ciudad: valencia
descripcion: Combo ticket for the Oceanogràfic and the Science Museum at the City of Arts and Sciences, on the same day and without queuing at the ticket office. Rated 4.7/5 from 2,797 reviews.
slugs:
  es: oceanografic-museo-ciencias-entrada-combinada
  en: oceanografic-science-museum-combo-ticket
  de: oceanografic-wissenschaftsmuseum-kombiticket
  fr: valence-billet-combine-oceanografic-musee-sciences
  it: oceanografic-museo-scienze-valencia-biglietto
  pt: oceanografic-museu-ciencias-bilhete-combinado
duracion: 1 day
duracionMinutos: 360
precioDesde: 39
moneda: EUR
idiomas:
- en
- es
proveedor: getyourguide
urlReserva: https://www.getyourguide.com/es-es/valencia-l49/valencia-entrada-combinada-oceanografic-y-museo-de-la-ciencia-t1026094/?partner_id=C71NOAW
cancelacionGratuita: false
horasCancelacion: 0
highlights:
- Oceanogràfic and Science Museum on one ticket
- Skip the ticket-office queue
- Belugas, sharks and sea lions
- Hands-on interactive museum
- Under-4s go free
incluye:
- Entry to the Oceanogràfic
- Entry to the Science Museum
noIncluye:
- Food and drinks
- Transfers
- Guide
puntoEncuentro:
  texto: City of Arts and Sciences, Av. del Professor López Piñero, 3, Valencia.
  descripcionGuia: 'There''s no meeting point: enter the Oceanogràfic at c/ Eduardo Primo Yúfera, 1, and the Science Museum at its main entrance.'
  latitud: 39.4549
  longitud: -0.3534
  zoom: 16
detallesPracticos:
  ticketMovil: true
  confirmacionInmediata: true
  accesibleSilla: true
  edadMinima: 0
  mascotasPermitidas: false
informacionImportante:
  queTraer:
  - Ticket on your phone
  - Comfortable shoes
  noAptoPara: []
  aTenerEnCuenta:
  - You pick a time slot for the Oceanogràfic; the Museum can be visited any time that day
  - Under-4s go free
  - Plan a full day to see both
accesibilidad: Wheelchair accessible.
politicaCancelacion: 'Non-refundable: once booked, the ticket can''t be cancelled or changed.'
preguntasFrecuentes:
- pregunta: Do I have to see both on the same day?
  respuesta: Yes, the combo ticket is valid for one day.
- pregunta: Which should I visit first?
  respuesta: The Oceanogràfic at your booked time; the Science Museum whenever you like that day. They're a 10-minute walk apart.
- pregunta: Is it worth it over the Oceanogràfic-only ticket?
  respuesta: 'Yes, if you have the whole day: a few euros more adds the museum.'
- pregunta: Can I cancel?
  respuesta: No, the ticket is non-refundable.
opinionEditorial: For a little more than the Oceanogràfic ticket you add the Science Museum, great with kids. You need the whole day and it can't be changed, so book once your plan is set.
guiasRelacionadas:
- city-of-arts-sciences-how-to-visit
- valencia-with-kids
categoria: parques
keywords:
- oceanografic science museum combo ticket
- city of arts and sciences tickets
- valencia science museum ticket
imagen: /images/actividades/valencia/oceanografic/oceanografic-tunel-tiburones.webp
imagenAlt: Visitors in the underwater tunnel at the Oceanogràfic in Valencia
galeria:
- src: /images/actividades/valencia/oceanografic/oceanografic-beluga.webp
  alt: Beluga swimming in its pool at the Oceanogràfic
- src: /images/actividades/valencia/museo-ciencias/museo-ciencias-atardecer.webp
  alt: Príncipe Felipe Science Museum at dusk
- src: /images/actividades/valencia/oceanografic/oceanografic-tiburon.webp
  alt: Sand tiger shark in the Oceanogràfic's ocean tank
- src: /images/actividades/valencia/ciudad-artes-ciencias/oceanografic-arquitectura-valencia.webp
  alt: Arquitectura del Oceanogràfic de Valencia en la Ciudad de las Artes
- src: /images/actividades/valencia/oceanografic/oceanografic-leon-marino.webp
  alt: Sea lion on a rock at the Oceanogràfic
- src: /images/actividades/valencia/ciudad-artes-ciencias/ciudad-artes-ciencias-exterior.webp
  alt: Exterior de la Ciudad de las Artes y Ciencias de Valencia
- src: /images/actividades/valencia/museo-ciencias/museo-ciencias-interior-sala.webp
  alt: The great interior hall of the Science Museum with its exhibits
- src: /images/actividades/valencia/museo-ciencias/hemisferic-dia.webp
  alt: The Hemisfèric reflected in the water
- src: /images/actividades/valencia/museo-ciencias/museo-ciencias-adn.webp
  alt: Giant DNA molecule inside the Science Museum
- src: /images/actividades/valencia/museo-ciencias/museo-ciencias-fachada.webp
  alt: White structure of the Science Museum
- src: /images/actividades/valencia/museo-ciencias/museo-ciencias-noche.webp
  alt: The Science Museum lit up at night
- src: /images/actividades/valencia/museo-ciencias/museo-ciencias-rotulo.webp
  alt: Façade of the Museu de les Ciències with its sign
ratingProveedor: 4.7
numeroOpiniones: 2797
atraccionesRelacionadas:
- ciudad-artes
- ciudad-artes-ciencias
publicada: true
indexar: false
destacada: false
fecha: '2026-10-07'
fecha_actualizacion: '2026-10-25'
---

## What you will see

- The **Oceanogràfic**: belugas, sharks, jellyfish and sea lions.
- The **Príncipe Felipe Science Museum** and its hands-on exhibits.
- **Calatrava's** architecture and the Hemisfèric.

## How it works

You book the day and the Oceanogràfic time slot. The same day you can enter the Science Museum whenever you like, with the ticket on your phone and no ticket-office queue.

## Who I recommend it for

- **Families with children** wanting to make a day of it.
- Anyone wanting the **essentials** of the City of Arts.

## Who I don't recommend it for

- Anyone with only **half a day**: there's no time for both.
