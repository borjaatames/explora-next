---
titulo: 'Palma: live flamenco show at Tablao Flamenco Alma'
slug: palma-tablao-flamenco-alma-show
ciudad: mallorca
descripcion: 1-hour live flamenco show at Tablao Flamenco Alma, Palma's first tablao, with dance, singing and guitar, plus a drink or tapas depending on the option. Rated 4.6/5 from 1,683 reviews.
slugs:
  es: palma-tablao-flamenco-alma-espectaculo
  en: palma-tablao-flamenco-alma-show
  de: palma-flamenco-show-tablao-alma
  fr: palma-spectacle-flamenco-tablao-alma
  it: palma-spettacolo-flamenco-tablao-alma
  pt: palma-espetaculo-flamenco-tablao-alma
duracion: 1 hour
duracionMinutos: 60
precioDesde: 35
moneda: EUR
idiomas: []
proveedor: getyourguide
urlReserva: https://www.getyourguide.com/activity-t653681/?partner_id=C71NOAW
cancelacionGratuita: true
horasCancelacion: 24
highlights:
- Palma's first flamenco tablao
- Live dance, singing and guitar
- Drink included depending on option
- Tapas option with Iberian ham, cheeses and anchovies
- Wheelchair accessible
incluye:
- Flamenco show
- One drink (sangria, beer, wine, cava or soft drink) depending on option
- Tapas depending on option
noIncluye:
- Tapas and drinks on options that don't include them
puntoEncuentro:
  texto: Tablao Flamenco Alma, Av. de Portugal, 5, ground floor, 07012 Palma.
  descripcionGuia: Arrive a little early to take your seat before the show.
detallesPracticos:
  ticketMovil: true
  confirmacionInmediata: false
  accesibleSilla: true
  edadMinima: 0
  mascotasPermitidas: false
informacionImportante:
  queTraer: []
  noAptoPara: []
  aTenerEnCuenta:
  - What's included (drink or tapas) depends on the option you book
  - Every show is different depending on that night's artists
accesibilidad: Wheelchair accessible.
politicaCancelacion: Free cancellation up to 24 hours before, with a full refund.
preguntasFrecuentes:
- pregunta: How long is it?
  respuesta: The show lasts about 1 hour.
- pregunta: Is a drink included?
  respuesta: Yes, depending on the option, one drink from sangria, beer, wine, cava or a soft drink.
- pregunta: What tapas come with the food option?
  respuesta: A selection with Iberian ham, artisan cheeses and Cantabrian anchovies, plus one drink.
- pregunta: Is it accessible?
  respuesta: Yes, the tablao is wheelchair accessible.
opinionEditorial: Mallorca isn't flamenco country, but this intimate tablao in central Palma is a serious way to see it live without going to Andalusia. At 4.6/5 and a fair price, the tapas option turns the one-hour show into a full evening out.
guiasRelacionadas:
- what-to-see-in-mallorca
categoria: espectaculos
keywords:
- flamenco palma de mallorca
- tablao flamenco alma
- flamenco show mallorca
- palma flamenco tickets
ratingProveedor: 4.6
numeroOpiniones: 1683
atraccionesRelacionadas:
- palma
publicada: true
indexar: false
destacada: false
fecha: '2026-10-31'
fecha_actualizacion: '2026-10-31'
imagen: /images/actividades/jerez-de-la-frontera/flamenco/baile-luz-tenue.webp
imagenAlt: "Flamenco dancer in motion on a dimly lit stage (illustrative image)"
galeria:
- src: /images/actividades/mallorca/fma-palma/catedral-palma-noche.webp
  alt: "Palma Cathedral lit up at night"
- src: /images/actividades/jerez-de-la-frontera/flamenco/castanuelas-manos.webp
  alt: "A flamenco dancer's hands with castanets"
- src: /images/actividades/mallorca/fma-palma/paseo-maritimo-palma-atardecer.webp
  alt: "Palma seafront promenade at sunset"
- src: /images/actividades/jerez-de-la-frontera/flamenco/bailaora-giro-escenario.webp
  alt: "A dancer twirling on stage (illustrative image)"
- src: /images/actividades/mallorca/fma-palma/catedral-palma-atardecer-rosa.webp
  alt: "Palma Cathedral under a pink sunset sky"
- src: /images/actividades/alicante/flamenco/x-flamenco-pixabay-594272.webp
  alt: "Bailaora con mantón y guitarrista en un espectáculo flamenco"
- src: /images/actividades/jerez-de-la-frontera/flamenco/x-flamenco-wikimedia-02.webp
  alt: "Bailaora flamenca en blanco y negro"
---

## What you will see

- A **flamenco group** with live dance, singing and guitar.
- Palma's **first tablao**, in an intimate setting.

## How it works

You head to the tablao on Avinguda de Portugal and watch a show of around an hour, with artists who improvise every night. Depending on the option, you get a drink or a tapas selection with a drink while you watch.

## Who I recommend it for

- Anyone who wants to see **live flamenco** on holiday in Mallorca.
- **Couples** looking for an evening out in central Palma.

## Who I don't recommend it for

- Anyone wanting a full dinner, as the food option is tapas.
