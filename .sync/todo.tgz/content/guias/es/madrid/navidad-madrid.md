---
titulo: "Navidad en Madrid 2026: luces, mercadillos y planes que merecen la pena"
descripcion: "Navidad en Madrid 2026: cuándo se encienden las luces, mercadillo de la Plaza Mayor, Naviluz, Cortylandia, pista de hielo, Nochevieja en Sol y Cabalgata de Reyes."
categoria: "madrid"
slug: "navidad-madrid"
fecha: "2026-10-23"
fecha_actualizacion: '2026-11-07'
autor: Borja
publicada: true
destacada: true
imagen_portada: "/images/guias/navidad-madrid.jpg"
imagen_alt: "Mercadillo navideño de la Plaza Mayor de Madrid iluminado de noche, con el árbol de Navidad"
tiempo_lectura: 5
keywords:
  - "navidad en madrid"
  - "navidad madrid 2026"
  - "luces de navidad madrid"
  - "mercadillo plaza mayor"
  - "naviluz"
  - "cortylandia"
  - "qué hacer en madrid en navidad"
slugs:
  es: navidad-madrid
  en: christmas-in-madrid
  de: weihnachten-madrid
  fr: noel-a-madrid
  it: natale-a-madrid
  pt: natal-em-madrid
reservasArriba: true
intro: 'La **Navidad en Madrid** llena el centro de luces durante seis semanas: más de 250 puntos iluminados, el mercadillo de la Plaza Mayor, el belén de la Puerta del Sol, Cortylandia y la pista de hielo de Plaza de España. Y tiene tradiciones propias que no se viven en otra ciudad, del sorteo de la Lotería en el Teatro Real a las campanadas en Sol y la Cabalgata de Reyes.'
respuestaCorta: 'En la **Navidad en Madrid** las luces se encienden el **sábado 21 de noviembre** en Cibeles y siguen hasta el 6 de enero. Lo imprescindible: el **mercadillo de la Plaza Mayor**, **Cortylandia** en Preciados, las luces en **Naviluz** o en tuk-tuk y la **Cabalgata de Reyes** del 5 de enero. Ve entre semana: los sábados el centro se colapsa.'
actividades:
  - tuk-tuk-luces-navidad-madrid
  - madrid-big-bus-night-tour
  - ruta-tapas-nocturna-madrid
  - flamenco-torres-bermejas-cena
  - madrid-tour-nocturno-inquisicion-leyendas
  - palacio-real-visita-guiada-golden-tour
  - excursion-toledo-segovia-alcazar
faq:
- pregunta: ¿Cuándo se encienden las luces de Navidad en Madrid en 2026?
  respuesta: El sábado 21 de noviembre, con un acto en la plaza de Cibeles, y el alumbrado dura hasta el 6 de enero de 2027. La hora del encendido está pendiente de confirmar por el Ayuntamiento.
- pregunta: ¿Cuándo abre el mercadillo de Navidad de la Plaza Mayor?
  respuesta: Desde finales de noviembre hasta el 31 de diciembre, con entrada libre. Lo mejor es ir hacia las 17:30, con la última luz del día y antes de que se llene.
- pregunta: ¿Cuánto cuesta Naviluz y cómo funciona?
  respuesta: Es un autobús descapotable de unos 50 minutos que sale de la calle Felipe IV, junto al Prado, cada hora de 18:00 a 22:00. Cuesta unos 12 € (6 € niños de 7 a 11 años; los menores de 7 no pagan, pero necesitan billete) y es más barato desde las 21:00. Se compra en naviluz.es, no se puede cambiar ni cancelar y no funciona el 24 y 31 de diciembre ni el 5 de enero.
- pregunta: ¿Cómo es la Nochevieja en la Puerta del Sol?
  respuesta: 'Las campanadas son gratis, pero el acceso se cierra cuando se llena la plaza: llega antes de las 21:00 y lleva las uvas peladas. Si prefieres menos gente, el 30 de diciembre se celebran las preúvas, el ensayo general, con aforo de unas 15.000 personas.'
- pregunta: ¿Por dónde pasa la Cabalgata de Reyes de Madrid?
  respuesta: Sale el 5 de enero a las 18:00 de la plaza de San Juan de la Cruz, baja por la Castellana y Recoletos y termina en Cibeles hacia las 21:00. Para ver algo, coge sitio en la Castellana.
---

## Navidad en Madrid 2026: el calendario

| Qué | Dónde | Cuándo | Precio |
| --- | --- | --- | --- |
| Luces de Navidad | Centro y los 21 distritos (encendido en Cibeles) | 21 de noviembre de 2026 – 6 de enero de 2027 | Gratis |
| Belén de la Real Casa de Correos | Puerta del Sol | Finales de noviembre – 6 de enero | Gratis |
| Mercadillo navideño | Plaza Mayor | Finales de noviembre – 31 de diciembre | Gratis |
| Cortylandia | El Corte Inglés de Preciados | Finales de noviembre – 5 de enero | Gratis |
| Naviluz (bus de las luces) | Calle Felipe IV, junto al Prado | Finales de noviembre – 6 de enero | Unos 12 € (6 € niños) |
| La Navideña y pista de hielo | Plaza de España | Finales de noviembre – primeros de enero | Pista de pago |
| Feria de Artesanía | Paseo de Recoletos | 1 – 30 de diciembre | Gratis |
| Sorteo de El Gordo | Teatro Real | 22 de diciembre, por la mañana | Gratis, con entrada |
| Preúvas | Puerta del Sol | 30 de diciembre, a medianoche | Gratis, con aforo |
| Campanadas | Puerta del Sol | 31 de diciembre | Gratis, con aforo |
| Cabalgata de Reyes | Castellana – Cibeles | 5 de enero, desde las 18:00 | Gratis |

**Confirmado (4 de noviembre de 2026):** el Ayuntamiento enciende las luces el sábado 21 de noviembre con un acto en la plaza de Cibeles, y el alumbrado dura hasta el 6 de enero de 2027. La hora del encendido está pendiente de confirmar. El resto de fechas son las de la última edición hasta que salga el programa de 2026.

## Luces de Navidad en Madrid: cómo verlas

Este año hay más de **250 puntos iluminados** y 14 millones de ledes, con dibujos de alumbrado hechos por escolares madrileños.

- **A pie:** Sol, Preciados, Gran Vía y la calle Alcalá hasta Cibeles, y luego Serrano. Unas dos horas sin prisa.
- **Naviluz:** autobús descapotable de unos 50 minutos, con salidas cada hora de 18:00 a 22:00 y más barato a partir de las 21:00. Se compra en naviluz.es y **no se puede cambiar ni cancelar**, ni siquiera si llueve. No funciona el 24 y el 31 de diciembre ni el 5 de enero.
- **En tuk-tuk privado:** hora y media para hasta 4 personas, sin colas ni esperas al frío. Va abierto: lleva abrigo.

[actividad: tuk-tuk-luces-navidad-madrid]

## Una tarde de diciembre: mercadillo de la Plaza Mayor, Sol y Cortylandia

1. **17:30, Plaza Mayor:** el mercadillo con la última luz del día, antes de que se llene.
2. **18:15, Puerta del Sol:** el belén de la Real Casa de Correos (hay cola, pero avanza) y el árbol.
3. **19:00, Preciados:** Cortylandia, y de ahí a la Gran Vía ya de noche, que es cuando las luces lucen más.
4. **20:00, chocolate con churros en San Ginés**, en el pasadizo de San Ginés, junto a Sol. Abre desde 1894 y funciona 24 horas de jueves a domingo y las vísperas de festivo.
5. **21:00, cena:** de tapas por el centro o con un espectáculo de flamenco.

## Tradiciones, Nochevieja y Reyes

- **El sorteo de la Lotería (22 de diciembre):** en el Teatro Real, con entrada gratuita numerada que se recoge en taquilla enseñando el DNI o el pasaporte. Hay quien hace cola desde la noche anterior: en las últimas ediciones, llegar después de las 4 de la madrugada era quedarse fuera.
- **La cola de Doña Manolita:** la administración de lotería más famosa de Madrid, con colas de horas en diciembre. Para la foto, ve a primera hora de un día laborable.
- **Las preúvas (30 de diciembre):** el ensayo general de las campanadas, con las mismas uvas y mucha menos gente. Gratis, con aforo de unas 15.000 personas; en la última edición la plaza se cerró a las 21:00 y volvió a abrir a las 22:00.
- **Campanadas en Sol (31 de diciembre):** el acceso se cierra cuando se llena la plaza. Llega antes de las 21:00 y lleva las uvas peladas.
- **Cabalgata de Reyes (5 de enero):** sale a las 18:00 de la plaza de San Juan de la Cruz, baja por la Castellana y Recoletos y termina en Cibeles hacia las 21:00. Coge sitio en la Castellana: en Cibeles la multitud no deja ver nada.

## Qué hacer en Madrid en Navidad con niños y en festivos

**Con niños:**

- **Cortylandia** es el plan número uno: gratis y al lado de Sol. Ve entre semana por la tarde.
- **Naviluz** cuesta la mitad para niños de 7 a 11 años, y los menores de 7 no pagan, aunque necesitan billete.
- La **pista de hielo** de Plaza de España funciona por turnos: compra la entrada antes en su web.

**Museos en festivos:** el **Prado** cierra el 25 de diciembre y el 1 de enero, y el 24 y el 31 de diciembre y el 6 de enero abre solo de 10:00 a 14:00. Las dos últimas horas de cada día la colección es gratis, con aforo. Diciembre es buen mes para el **Palacio Real** y los museos, con menos colas que en primavera. Si tienes un día libre, **Toledo y Segovia** son la escapada clásica, y en invierno se hacen sin calor.

## Errores típicos

- **Ir un sábado de diciembre por la tarde:** Sol y Preciados son un tapón. Mejor un martes o un miércoles.
- **Dejar para el final la cena del 24 o del 31:** muchos restaurantes cierran o solo dan menú cerrado. Reserva en noviembre.
- **Reservar Naviluz para un día dudoso:** no se devuelve si llueve. Mejor un plan que se pueda cancelar.
