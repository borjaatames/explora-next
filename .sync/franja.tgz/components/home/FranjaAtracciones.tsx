import Link from "next/link";
import Image from "next/image";
import { atraccionesParaHome } from "@/lib/atracciones";
import type { Idioma } from "@/lib/i18n/types";

type TextosFranja = { titulo: string; subtitulo: string };

const TEXTOS: Partial<Record<Idioma, TextosFranja>> = {
  es: {
    titulo: "Atracciones imprescindibles",
    subtitulo: "Entradas, visitas guiadas y todo lo que necesitas saber de cada monumento, comparado en una sola página.",
  },
  en: {
    titulo: "Must-see attractions",
    subtitulo: "Tickets, guided tours and everything you need to know about each landmark, compared on a single page.",
  },
};

const NOMBRE_CIUDAD: Record<string, Partial<Record<Idioma, string>>> = {
  barcelona: { es: "Barcelona", en: "Barcelona" },
  cordoba: { es: "Córdoba", en: "Córdoba" },
  granada: { es: "Granada", en: "Granada" },
  madrid: { es: "Madrid", en: "Madrid" },
  malaga: { es: "Málaga", en: "Málaga" },
  sevilla: { es: "Sevilla", en: "Seville" },
};

/** Tira de botones con las páginas de atracción. Solo se muestra si el idioma tiene al menos 4. */
export default function FranjaAtracciones({ idioma }: { idioma: Idioma }) {
  const t = TEXTOS[idioma];
  const atracciones = atraccionesParaHome(idioma);
  if (!t || atracciones.length < 4) return null;

  return (
    <section aria-labelledby="atracciones-home" className="max-w-6xl mx-auto px-4 py-12 md:py-14">
      <div className="mb-6 max-w-2xl">
        <h2 id="atracciones-home" className="font-fraunces text-2xl md:text-3xl font-bold text-piedra-900 mb-2">
          {t.titulo}
        </h2>
        <p className="text-piedra-600">{t.subtitulo}</p>
      </div>
      <ul className="flex flex-wrap gap-3">
        {atracciones.map((a) => (
          <li key={a.url}>
            <Link
              href={a.url}
              className="group inline-flex items-center gap-3 bg-white border border-piedra-200 hover:border-anil-400 hover:shadow-md rounded-lg py-2 pl-2 pr-4 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-anil-500 focus-visible:ring-offset-2"
            >
              <Image
                src={a.imagen}
                alt=""
                width={48}
                height={48}
                sizes="48px"
                className="h-12 w-12 rounded-full object-cover shrink-0"
              />
              <span className="flex flex-col leading-tight">
                <span className="text-sm font-semibold text-piedra-900 group-hover:text-anil-700 transition-colors">
                  {a.nombre}
                </span>
                <span className="text-xs text-piedra-500">{NOMBRE_CIUDAD[a.ciudad]?.[idioma] ?? a.ciudad}</span>
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}
