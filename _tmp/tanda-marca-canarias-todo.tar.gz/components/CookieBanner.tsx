"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  leerConsentimiento,
  guardarConsentimiento,
  COOKIE_CONSENT_EVENT,
} from "@/lib/cookies";
import { urlCookies, urlPrivacidad } from "@/lib/i18n/utils";
import type { Idioma } from "@/lib/i18n/types";

const DICT = {
  es: {
    titulo: "Usamos cookies para entender cómo se usa el sitio",
    texto:
      "Analítica con Google Analytics 4. No vendemos tus datos. Más información en",
    politicaCookies: "Política de cookies",
    politicaPrivacidad: "Privacidad",
    y: "y",
    rechazar: "Rechazar",
    aceptar: "Aceptar",
  },
  en: {
    titulo: "We use cookies to understand how the site is used",
    texto:
      "Analytics with Google Analytics 4. We don't sell your data. More information in",
    politicaCookies: "Cookie policy",
    politicaPrivacidad: "Privacy",
    y: "and",
    rechazar: "Reject",
    aceptar: "Accept",
  },
  de: {
    titulo: "Wir verwenden Cookies, um zu verstehen, wie die Website genutzt wird",
    texto:
      "Analyse mit Google Analytics 4. Wir verkaufen deine Daten nicht. Weitere Informationen in der",
    politicaCookies: "Cookie-Richtlinie",
    politicaPrivacidad: "Datenschutz",
    y: "und",
    rechazar: "Ablehnen",
    aceptar: "Akzeptieren",
  },
} as const;

type Props = {
  idioma: Idioma;
};

/**
 * Banner inferior de consentimiento de cookies. Aparece solo si el
 * usuario no ha decidido todavía (estado "pending") o si caducó.
 *
 * Diseño: barra fina inferior tipo Vercel/Linear. No bloquea contenido.
 * Posición fixed, fuera del flujo, no provoca CLS.
 *
 * Cumplimiento RGPD:
 *   - Aceptar y Rechazar tienen igual prominencia visual.
 *   - Los enlaces a la política de cookies y privacidad son visibles.
 *   - GA4 NO carga hasta que se pulsa "Aceptar" (lo gestiona Analytics.tsx).
 */
export default function CookieBanner({ idioma }: Props) {
  const t = DICT[idioma === "en" ? "en" : idioma === "de" ? "de" : "es"];

  const [visible, setVisible] = useState(false);
  const bannerRef = useRef<HTMLDivElement>(null);

  // Publica la altura del banner en `--alto-cookie-banner` para que la barra
  // fija de reserva en móvil se coloque justo encima y no quede tapada.
  useEffect(() => {
    const raiz = document.documentElement;
    const el = bannerRef.current;
    if (!visible || !el) {
      raiz.style.removeProperty("--alto-cookie-banner");
      return;
    }
    const publicar = () =>
      raiz.style.setProperty("--alto-cookie-banner", `${el.offsetHeight}px`);
    publicar();
    const observador = new ResizeObserver(publicar);
    observador.observe(el);
    return () => {
      observador.disconnect();
      raiz.style.removeProperty("--alto-cookie-banner");
    };
  }, [visible]);

  useEffect(() => {
    function evaluar() {
      setVisible(leerConsentimiento() === "pending");
    }

    // Pequeño delay para no interferir con el LCP. El banner es importante
    // pero no es lo primero que el usuario debe ver al cargar la página.
    const timer = setTimeout(evaluar, 400);

    // Re-evaluar si el consentimiento cambia (por ej. desde /cookies con
    // un botón "Cambiar mi decisión").
    window.addEventListener(COOKIE_CONSENT_EVENT, evaluar);

    return () => {
      clearTimeout(timer);
      window.removeEventListener(COOKIE_CONSENT_EVENT, evaluar);
    };
  }, []);

  function aceptar() {
    guardarConsentimiento("granted");
    setVisible(false);
  }

  function rechazar() {
    guardarConsentimiento("denied");
    setVisible(false);
  }

  if (!visible) return null;

  return (
    <div
      ref={bannerRef}
      role="dialog"
      aria-labelledby="cookie-banner-titulo"
      aria-describedby="cookie-banner-texto"
      className="fixed bottom-0 left-0 right-0 z-50 border-t border-piedra-200 bg-white shadow-lg animate-cookie-slide-up"
    >
      <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-3 sm:px-6 lg:flex-row lg:items-center lg:justify-between lg:px-8 lg:py-3">
        <div className="flex-1">
          <p
            id="cookie-banner-titulo"
            className="text-sm font-semibold text-piedra-900"
          >
            {t.titulo}
          </p>
          <p
            id="cookie-banner-texto"
            className="mt-1 text-sm text-piedra-600"
          >
            {t.texto}{" "}
            <Link
              href={urlCookies(idioma)}
              className="underline hover:text-piedra-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-anil-500 focus-visible:ring-offset-2 rounded-sm"
            >
              {t.politicaCookies}
            </Link>{" "}
            {t.y}{" "}
            <Link
              href={urlPrivacidad(idioma)}
              className="underline hover:text-piedra-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-anil-500 focus-visible:ring-offset-2 rounded-sm"
            >
              {t.politicaPrivacidad}
            </Link>
            .
          </p>
        </div>

        <div className="flex items-center gap-2 lg:gap-3 lg:flex-shrink-0">
          <button
            type="button"
            onClick={rechazar}
            className="flex-1 lg:flex-none rounded-md border border-piedra-300 bg-white px-4 py-2 text-sm font-semibold text-piedra-700 transition-colors hover:bg-piedra-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-anil-500 focus-visible:ring-offset-2"
          >
            {t.rechazar}
          </button>
          <button
            type="button"
            onClick={aceptar}
            className="flex-1 lg:flex-none rounded-md bg-piedra-900 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-piedra-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-anil-500 focus-visible:ring-offset-2"
          >
            {t.aceptar}
          </button>
        </div>
      </div>

    </div>
  );
}
