"use client";

import { useState, type FormEvent } from "react";
import type { Idioma } from "@/lib/i18n/types";

/**
 * Formulario de contacto. Envía a Web3Forms (https://web3forms.com): no
 * requiere backend propio ni guardar secretos sensibles en el repo — solo
 * una "access key" pública ligada al email de destino, en
 * NEXT_PUBLIC_WEB3FORMS_KEY.
 *
 * Si la clave no está configurada, se hace fallback al email (mailto) para
 * que la página nunca quede sin vía de contacto.
 *
 * Antispam: honeypot `botcheck` (campo oculto que solo rellenan los bots).
 */

const T = {
  es: {
    nombre: "Nombre",
    email: "Tu correo",
    mensaje: "Mensaje",
    enviar: "Enviar mensaje",
    enviando: "Enviando…",
    ok: "¡Gracias! Hemos recibido tu mensaje y te responderemos lo antes posible.",
    error: "No se ha podido enviar. Inténtalo de nuevo o escríbenos a contacto@exploraspain.com.",
    subject: "Nuevo mensaje desde ExploraSpain",
    sinConfig: "Escríbenos directamente a:",
  },
  en: {
    nombre: "Name",
    email: "Your email",
    mensaje: "Message",
    enviar: "Send message",
    enviando: "Sending…",
    ok: "Thanks! We've received your message and will get back to you as soon as possible.",
    error: "Couldn't send. Please try again or email us at contacto@exploraspain.com.",
    subject: "New message from ExploraSpain",
    sinConfig: "Email us directly at:",
  },
  de: {
    nombre: "Name",
    email: "Deine E-Mail",
    mensaje: "Nachricht",
    enviar: "Nachricht senden",
    enviando: "Wird gesendet…",
    ok: "Danke! Wir haben deine Nachricht erhalten und melden uns so schnell wie möglich.",
    error: "Senden fehlgeschlagen. Bitte versuche es erneut oder schreibe uns an contacto@exploraspain.com.",
    subject: "Neue Nachricht von ExploraSpain",
    sinConfig: "Schreib uns direkt an:",
  },
} as const;

type Estado = "idle" | "sending" | "ok" | "error";

export default function ContactForm({ idioma }: { idioma: Idioma }) {
  const t = T[idioma === "en" ? "en" : idioma === "de" ? "de" : "es"];
  const accessKey = process.env.NEXT_PUBLIC_WEB3FORMS_KEY;
  const [estado, setEstado] = useState<Estado>("idle");

  if (estado === "ok") {
    return (
      <div className="bg-anil-50 border border-anil-200 rounded-lg p-6 text-piedra-800">
        {t.ok}
      </div>
    );
  }

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);

    // Sin clave de Web3Forms: el formulario sigue visible y, al enviar,
    // abre el correo del usuario con el mensaje ya redactado (mailto).
    if (!accessKey) {
      const nombre = String(fd.get("name") || "");
      const correo = String(fd.get("email") || "");
      const mensaje = String(fd.get("message") || "");
      const body = `${mensaje}\n\n— ${nombre} (${correo})`;
      window.location.href = `mailto:contacto@exploraspain.com?subject=${encodeURIComponent(
        t.subject
      )}&body=${encodeURIComponent(body)}`;
      return;
    }

    fd.append("access_key", accessKey);
    fd.append("subject", t.subject);
    fd.append("from_name", "ExploraSpain");
    setEstado("sending");
    try {
      const res = await fetch("https://api.web3forms.com/submit", {
        method: "POST",
        body: fd,
      });
      const data = await res.json();
      if (data.success) {
        form.reset();
        setEstado("ok");
      } else {
        setEstado("error");
      }
    } catch {
      setEstado("error");
    }
  }

  const inputCls =
    "w-full rounded-lg border border-piedra-300 px-4 py-2.5 text-piedra-900 placeholder-piedra-400 focus:outline-none focus:ring-2 focus:ring-anil-500 focus:border-anil-500 transition";

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      {/* Honeypot antispam: oculto a humanos, lo rellenan los bots. */}
      <input
        type="checkbox"
        name="botcheck"
        className="hidden"
        style={{ display: "none" }}
        tabIndex={-1}
        autoComplete="off"
        aria-hidden="true"
      />

      <div className="grid sm:grid-cols-2 gap-4">
        <input name="name" required placeholder={t.nombre} className={inputCls} />
        <input
          type="email"
          name="email"
          required
          placeholder={t.email}
          className={inputCls}
        />
      </div>
      <textarea
        name="message"
        required
        rows={5}
        placeholder={t.mensaje}
        className={inputCls}
      />

      <button
        type="submit"
        disabled={estado === "sending"}
        className="inline-flex items-center gap-2 bg-azafran-400 hover:bg-azafran-500 disabled:opacity-60 text-piedra-900 font-semibold px-6 py-3 rounded-lg transition-colors"
      >
        {estado === "sending" ? t.enviando : t.enviar}
      </button>

      {estado === "error" && (
        <p className="text-sm text-teja-600">{t.error}</p>
      )}
    </form>
  );
}
