"use client";

import type { Idioma } from "@/lib/i18n/types";

/**
 * Botón flotante de contacto por WhatsApp (click-to-chat).
 *
 * Es un simple enlace `https://wa.me/<numero>` que abre una conversación
 * de WhatsApp con un mensaje ya redactado. NO inicia llamadas: solo chat.
 * El número es una línea de WhatsApp Business de ExploraSpain.
 *
 * Se monta en los shells (ES y EN) para estar visible en toda la web y dar
 * un canal de contacto directo que aporta confianza antes de reservar.
 *
 * Posición: abajo a la derecha. En móvil se sube (bottom-24) para no tapar
 * la barra sticky de reserva (StickyReservaMovil, bottom-0, z-40).
 */

// Número de WhatsApp Business en formato internacional, solo dígitos
// (sin "+", espacios ni guiones), como exige la API de wa.me.
const WHATSAPP_NUMERO = "34917647730";

const DICT: Record<"es" | "en" | "de", { aria: string; tooltip: string; mensaje: string }> = {
  es: {
    aria: "Contactar por WhatsApp",
    tooltip: "Hablar con un experto",
    mensaje: "Hola, tengo una consulta sobre las experiencias de ExploraSpain.",
  },
  en: {
    aria: "Contact us on WhatsApp",
    tooltip: "Talk to an expert",
    mensaje: "Hi, I have a question about ExploraSpain's experiences.",
  },
  de: {
    aria: "Über WhatsApp kontaktieren",
    tooltip: "Mit einem Experten sprechen",
    mensaje: "Hallo, ich habe eine Frage zu den Erlebnissen von ExploraSpain.",
  },
};

export default function WhatsAppButton({ idioma }: { idioma: Idioma }) {
  const t = idioma === "es" ? DICT.es : idioma === "de" ? DICT.de : DICT.en;
  const href = `https://wa.me/${WHATSAPP_NUMERO}?text=${encodeURIComponent(
    t.mensaje
  )}`;

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={t.aria}
      title={t.tooltip}
      className="group fixed bottom-24 right-4 z-40 lg:bottom-6 lg:right-6 flex items-center gap-2.5 rounded-full bg-piedra-900 hover:bg-piedra-800 text-white shadow-md transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-anil-500 pl-3 pr-3 lg:pl-4 lg:pr-5 py-3"
    >
      <span className="hidden lg:block w-2 h-2 rounded-full bg-anil-400" aria-hidden="true" />
      <svg
        width="22"
        height="22"
        viewBox="0 0 24 24"
        fill="currentColor"
        aria-hidden="true"
        className="flex-shrink-0"
      >
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.872.118.571-.085 1.758-.719 2.006-1.413.247-.694.247-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.999-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
      </svg>
      <span className="hidden lg:inline text-sm font-semibold whitespace-nowrap">
        {t.tooltip}
      </span>
    </a>
  );
}
