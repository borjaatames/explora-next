import OtrosIdiomas from "@/components/layout/OtrosIdiomas";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { obtenerCiudad } from "@/lib/ciudades";
import {
  obtenerActividad,
  obtenerTodosLosCaminosActividades,
  type ActividadCompleta,
} from "@/lib/actividades";
import { slugParejaActividad } from "@/lib/i18n/slugs";
import { obtenerGuiasParaFicha } from "@/lib/guias";
import { getDictionary } from "@/lib/i18n/getDictionary";
import {
  hreflangAlternates,
  rutasPorIdioma,
  urlActividad,
  urlActividadesDeCiudad,
} from "@/lib/i18n/utils";
import { construirUrlReserva, nombreProveedor } from "@/lib/afiliados";
import GaleriaActividad from "@/components/GaleriaActividad";
import CreditosFotos from "@/components/CreditosFotos";
import StickyReservaMovil from "@/components/StickyReservaMovil";
import CalendarioReserva from "@/components/CalendarioReserva";
import WidgetDisponibilidadGyg from "@/components/WidgetDisponibilidadGyg";
import PrecioDestacado from "@/components/PrecioDestacado";
import { ANCLA_WIDGET_GYG, tourWidgetGyg } from "@/lib/gyg-widget";
import BokunWidget from "@/components/BokunWidget";
import CtaReservaBokun from "@/components/ficha/CtaReservaBokun";
import DatosClave from "@/components/ficha/DatosClave";
import NotaTripadvisor from "@/components/ficha/NotaTripadvisor";
import ResenasTripadvisor from "@/components/ficha/ResenasTripadvisor";
import { datosTripadvisorBokun, fuenteResenasGyg } from "@/lib/tripadvisor";
import PlegableMovil from "@/components/ficha/PlegableMovil";
import StickyReservaBokun from "@/components/ficha/StickyReservaBokun";
import { ANCLA_RESERVA } from "@/lib/reservaBokun";
import SelloProveedor from "@/components/SelloProveedor";
import DetallesPracticos from "@/components/DetallesPracticos";
import InformacionImportante from "@/components/InformacionImportante";
import MapaPuntoEncuentro from "@/components/MapaPuntoEncuentro";
import FaqActividad from "@/components/FaqActividad";
import BotonVolverFicha from "@/components/ficha/BotonVolverFicha";
import ActividadesRecomendadasGuia from "@/components/guia/ActividadesRecomendadasGuia";
import { obtenerParecidasConTipo } from "@/lib/recomendaciones";
import OtrasVersiones from "@/components/ficha/OtrasVersiones";

const SITE_URL =
  process.env.NEXT_PUBLIC_SITE_URL || "https://www.exploraspain.com";

type Props = {
  params: { ciudad: string; slug: string };
};

export async function generateStaticParams() {
  return obtenerTodosLosCaminosActividades()
    .filter((c) => c.idioma === "es")
    .map(({ ciudad, slug }) => ({ ciudad, slug }));
}

export async function generateMetadata({
  params,
}: Props): Promise<Metadata> {
  const actividad = await obtenerActividad("es", params.ciudad, params.slug);
  if (!actividad) return { title: "Actividad no encontrada" };

  const url = `${SITE_URL}${actividad.url}`;
  const allowIndexing = process.env.NEXT_PUBLIC_ALLOW_INDEXING === "true";

  return {
    title: actividad.metaTitle ?? actividad.titulo,
    description: actividad.metaDescription ?? actividad.descripcion,
    keywords: actividad.keywords,
    robots: {
      index: allowIndexing,
      follow: allowIndexing,
    },
    alternates: {
      canonical: url,
      languages: hreflangAlternates((l) => {
        const slugPareja = slugParejaActividad(
          "es",
          params.ciudad,
          params.slug,
          l
        );
        return slugPareja ? urlActividad(l, params.ciudad, slugPareja) : null;
      }),
    },
    openGraph: {
      type: "article",
      url,
      title: `${actividad.titulo} | ExploraSpain`,
      description: actividad.descripcion,
      siteName: "ExploraSpain",
      locale: "es_ES",
      images: actividad.imagen
        ? [{ url: actividad.imagen, alt: actividad.imagenAlt }]
        : [],
    },
  };
}

export default async function ActividadPage({ params }: Props) {
  const ciudad = await obtenerCiudad("es", params.ciudad);
  const actividad = await obtenerActividad("es", params.ciudad, params.slug);
  if (!ciudad || !actividad) notFound();

  const dict = getDictionary("es");

  const guiasRelacionadas = obtenerGuiasParaFicha("es", params.ciudad, actividad);

  const parecidas = obtenerParecidasConTipo("es", params.ciudad, actividad);
  const actividadesParecidas = parecidas.actividades;
  const otrasVersiones = parecidas.tipo === "casiIguales" ? parecidas.actividades : [];
  const tripadvisor =
    actividad.proveedor === "bokun" ? datosTripadvisorBokun(actividad.bokunProductId) : null;
  const fuenteResenas = tripadvisor ?? fuenteResenasGyg(actividad.urlReserva);

  const url = `${SITE_URL}${actividad.url}`;
  const precioDesdeFinal = actividad.precioDesde;
  const precio = new Intl.NumberFormat("es-ES", {
    style: "currency",
    currency: actividad.moneda,
    maximumFractionDigits: 0,
  }).format(precioDesdeFinal);

  // URL limpia con tu PID/aid del proveedor ya añadido. NO se le añaden
  // parámetros de fecha ni viajeros porque Viator (afiliado básico) no
  // los respeta y, al recibirlos, redirige al carrusel genérico de la
  // ciudad en lugar de a la ficha individual del producto.
  const urlReservaBase = construirUrlReserva(
    actividad.proveedor,
    actividad.urlReserva
  );
  const nombreComercialProveedor = nombreProveedor(actividad.proveedor);

  const productLd = buildProductLd(actividad, url, urlReservaBase);

  const breadcrumbsLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Inicio", item: SITE_URL },
      {
        "@type": "ListItem",
        position: 2,
        name: "Ciudades",
        item: `${SITE_URL}/ciudades`,
      },
      {
        "@type": "ListItem",
        position: 3,
        name: ciudad.nombre,
        item: `${SITE_URL}${ciudad.url}`,
      },
      {
        "@type": "ListItem",
        position: 4,
        name: "Actividades",
        item: `${SITE_URL}${urlActividadesDeCiudad("es", params.ciudad)}`,
      },
      { "@type": "ListItem", position: 5, name: actividad.titulo, item: url },
    ],
  };

  /**
   * Igual que en las guías (ver app/(es-shell)/guias/[categoria]/[slug]/page.tsx):
   * NO se inyecta JSON-LD `FAQPage` hasta que la actividad tenga 4+ preguntas
   * reales, siguiendo la misma decisión de producto documentada en
   * components/FaqActividad.tsx.
   */
  const faqActividad = actividad.preguntasFrecuentes || [];
  const faqJsonLd =
    faqActividad.length >= 4
      ? {
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: faqActividad.map((p) => ({
            "@type": "Question",
            name: p.pregunta,
            acceptedAnswer: { "@type": "Answer", text: p.respuesta },
          })),
        }
      : null;

  // Rating como dato agregado del proveedor (Viator). NO se renderizan
  // opiniones individuales: la API de afiliación lo prohíbe y, además,
  // ExploraSpain no es el operador de la actividad.
  const tieneRating =
    typeof actividad.ratingProveedor === "number" &&
    typeof actividad.numeroOpiniones === "number" &&
    actividad.numeroOpiniones > 0;

  const ratingTextoOpiniones =
    actividad.numeroOpiniones === 1
      ? `1 ${dict.actividades.opiniones}`
      : `${(actividad.numeroOpiniones ?? 0).toLocaleString("es-ES")} ${
          dict.actividades.opiniones
        }`;

  const ratingTextoValor = (actividad.ratingProveedor ?? 0).toLocaleString(
    "es-ES",
    {
      minimumFractionDigits: 1,
      maximumFractionDigits: 1,
    }
  );


  const tourWidget = tourWidgetGyg(actividad.proveedor, actividad.urlReserva);
  const precioWidget = (
    <PrecioDestacado
      textoDesde={dict.actividades.desde}
      precio={precio}
      textoPorPersona={dict.actividades.porPersona}
      rating={tieneRating ? ratingTextoValor : undefined}
      opiniones={tieneRating ? ratingTextoOpiniones : undefined}
    />
  );
  const bloqueCalendario = (
    <CalendarioReserva
      idioma="es"
      proveedor={actividad.proveedor}
      precio={precio}
      valorEstimado={precioDesdeFinal}
      monedaEstimada={actividad.moneda}
      precioPorPersona={dict.actividades.porPersona}
      duracion={actividad.duracion}
      idiomas={actividad.idiomas}
      cancelacionGratuita={actividad.cancelacionGratuita}
      horasCancelacion={actividad.horasCancelacion}
      ratingProveedor={actividad.ratingProveedor}
      numeroOpiniones={actividad.numeroOpiniones}
      urlReservaBase={urlReservaBase}
      nombreProveedor={nombreComercialProveedor}
      textoReservar={dict.actividades.reservar}
      textoDesde={dict.actividades.desde}
      textoPorPersona={dict.actividades.porPersona}
      textoDuracion={dict.actividades.duracion}
      textoIdiomas={dict.actividades.idiomas}
      textoCancelacionHorasAntes={
        dict.actividades.cancelacionHorasAntes
      }
      textoCancelacionGratuita={dict.actividades.cancelacionGratuita}
    />
  );

  return (
    <main className="min-h-screen bg-white pb-24 lg:pb-0">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(productLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbsLd) }}
      />
      {faqJsonLd && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
        />
      )}

      {/* Móvil: foto primero (como Civitatis/GetYourGuide); desde md, cabecera
          y después galería, como siempre (desde md). */}
      <div className="flex flex-col">
      <header className="bg-white pt-4 md:pt-8">
        <div className="max-w-6xl mx-auto px-4">
          <nav aria-label="Migas de pan" className="text-sm text-piedra-500 mb-4">
            <Link href="/" className="hover:text-anil-700">
              Inicio
            </Link>
            {" › "}
            <Link href={ciudad.url} className="hover:text-anil-700">
              {ciudad.nombre}
            </Link>
            {" › "}
            <Link
              href={urlActividadesDeCiudad("es", params.ciudad)}
              className="hover:text-anil-700"
            >
              Actividades
            </Link>
            {" › "}
            <span className="text-piedra-900">{actividad.titulo}</span>
          </nav>

          <div className="flex flex-wrap items-center gap-2 text-xs font-semibold uppercase tracking-wider text-piedra-600 mb-3">
            <span className="bg-anil-100 text-anil-700 px-2 py-1 rounded">
              {dict.actividades.categorias[actividad.categoria]}
            </span>
            <span className="hidden md:inline bg-piedra-100 text-piedra-600 px-2 py-1 rounded">
              {actividad.duracion}
            </span>
            {actividad.cancelacionGratuita && (
              <span className="hidden md:inline bg-piedra-100 text-piedra-600 px-2 py-1 rounded">
                {actividad.horasCancelacion
                  ? dict.actividades.cancelacionHorasAntes.replace(
                      "{horas}",
                      String(actividad.horasCancelacion)
                    )
                  : dict.actividades.cancelacionGratuita}
              </span>
            )}
          </div>

          <h1 className="font-fraunces text-2xl md:text-5xl font-bold text-piedra-900 mb-3 leading-tight">
            {actividad.titulo}
          </h1>
          <p className="text-base md:text-lg text-piedra-600 max-w-3xl leading-relaxed line-clamp-3 md:line-clamp-none">
            {actividad.descripcion}
          </p>

          {tieneRating && (
            <p className="mt-4 inline-flex flex-wrap items-center gap-x-2 gap-y-1 text-sm text-piedra-600">
              <span className="inline-flex items-center gap-1.5 font-semibold text-piedra-900">
                <span aria-hidden="true" className="text-azafran-500 text-base">
                  ★
                </span>
                <span>{ratingTextoValor}</span>
              </span>
              <span aria-hidden="true" className="text-piedra-400">
                ·
              </span>
              <span>{ratingTextoOpiniones}</span>
            </p>
          )}

          {actividad.proveedor === "bokun" && (
            <NotaTripadvisor
              idioma="es"
              datos={tripadvisor}
            />
          )}

          {actividad.avisoReserva && (
            <p className="hidden md:flex mt-3 items-center gap-2 text-sm font-semibold text-azafran-900 bg-azafran-50 border border-azafran-200 rounded-lg px-3 py-2 w-fit">
              <span aria-hidden="true" className="text-azafran-500">!</span>
              {actividad.avisoReserva}
            </p>
          )}

          <DatosClave
            idioma="es"
            titulo={actividad.titulo}
            categoria={actividad.categoria}
            duracion={actividad.duracion}
            idiomas={actividad.idiomas}
            highlights={actividad.highlights}
            cancelacionGratuita={actividad.cancelacionGratuita}
            horasCancelacion={actividad.horasCancelacion}
            detalles={actividad.detallesPracticos}
          />

          {actividad.proveedor === "bokun" && (
            <CtaReservaBokun
              cancelacionGratuita={actividad.cancelacionGratuita}
              horasCancelacion={actividad.horasCancelacion}
              confirmacionInmediata={actividad.detallesPracticos?.confirmacionInmediata}
              idioma="es"
              precioDesde={actividad.precioDesde}
              moneda={actividad.moneda}
              porGrupo={actividad.categoria === "experienciasPrivadas"}
              minimoPersonas={actividad.minimoPersonas}
            />
          )}
        </div>
      </header>

      {actividad.imagen && (
        <div className="order-first md:order-none w-full max-w-6xl mx-auto px-4 pt-3 md:pt-8">
          <GaleriaActividad
            idioma="es"
            principal={{
              src: actividad.imagen,
              alt: actividad.imagenAlt,
            }}
            galeria={actividad.galeria}
            destacada={actividad.destacada}
          />
          <CreditosFotos
            idioma="es"
            srcs={[actividad.imagen, ...(actividad.galeria ?? []).map((g) => g.src)]}
          />
        </div>
      )}

      </div>

      <section className="max-w-6xl mx-auto px-4 py-10 md:py-14">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2 space-y-12">
            <SelloProveedor proveedor={actividad.proveedor} idioma="es" />

            {tourWidget && (
              <div className="lg:hidden">
                <WidgetDisponibilidadGyg
                  tourId={tourWidget}
                  idioma="es"
                  urlReserva={urlReservaBase}
                  cabecera={precioWidget}
                  soloEn="movil"
                />
              </div>
            )}

            {/* 2. Detalles prácticos — justo después de la galería */}
            <div className="hidden md:block">
              <DetallesPracticos
                idioma="es"
                duracion={actividad.duracion}
                idiomas={actividad.idiomas}
                detalles={actividad.detallesPracticos}
                cancelacionGratuita={actividad.cancelacionGratuita}
                horasCancelacion={actividad.horasCancelacion}
              />
            </div>

            {/* 3. Lo más destacado */}
            {actividad.highlights.length > 0 && (
              <div>
                <h2 className="font-fraunces text-2xl md:text-3xl font-bold text-piedra-900 mb-4">
                  Lo más destacado
                </h2>
                <ul className="space-y-2">
                  {actividad.highlights.map((h) => (
                    <li
                      key={h}
                      className="flex items-start gap-3 text-base text-piedra-800"
                    >
                      <span aria-hidden="true" className="text-anil-600 mt-1">
                        ✓
                      </span>
                      <span>{h}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* 3a. Otras versiones de la misma actividad */}
            <OtrasVersiones idioma="es" actual={actividad} versiones={otrasVersiones} />

            {/* 4. Nuestra opinión editorial */}
            {actividad.opinionEditorial && (
              <div className="bg-azafran-50 border-l-4 border-azafran-400 p-6 rounded-r-lg">
                <h2 className="font-fraunces text-xl md:text-2xl font-bold text-piedra-900 mb-3">
                  {dict.actividades.nuestraOpinion}
                </h2>
                <p className="text-piedra-800 leading-relaxed whitespace-pre-line">
                  {actividad.opinionEditorial}
                </p>
              </div>
            )}

            {/* 5. Qué incluye / no incluye */}
            {(actividad.incluye.length > 0 ||
              actividad.noIncluye.length > 0) && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {actividad.incluye.length > 0 && (
                  <div>
                    <h2 className="font-fraunces text-xl font-bold text-piedra-900 mb-3">
                      {dict.actividades.queIncluye}
                    </h2>
                    <ul className="space-y-2">
                      {actividad.incluye.map((item) => (
                        <li
                          key={item}
                          className="flex items-start gap-3 text-piedra-800"
                        >
                          <span
                            aria-hidden="true"
                            className="text-cobre-600 font-bold mt-0.5"
                          >
                            ✓
                          </span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {actividad.noIncluye.length > 0 && (
                  <div>
                    <h2 className="font-fraunces text-xl font-bold text-piedra-900 mb-3">
                      {dict.actividades.queNoIncluye}
                    </h2>
                    <ul className="space-y-2">
                      {actividad.noIncluye.map((item) => (
                        <li
                          key={item}
                          className="flex items-start gap-3 text-piedra-800"
                        >
                          <span
                            aria-hidden="true"
                            className="text-teja-500 font-bold mt-0.5"
                          >
                            ✗
                          </span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}

            {/* 6. Información importante — 3 columnas */}
            <PlegableMovil idioma="es">
              <InformacionImportante idioma="es" info={actividad.informacionImportante} />
            </PlegableMovil>

            {/* 7. Punto de encuentro con MAPA OSM + descripción guía */}
            {actividad.puntoEncuentro.texto && (
              <PlegableMovil idioma="es">
                <MapaPuntoEncuentro idioma="es" punto={actividad.puntoEncuentro} />
              </PlegableMovil>
            )}

            {/* 8. Sobre la actividad (Markdown editorial) */}
            <PlegableMovil idioma="es">
            <div>
              <h2 className="font-fraunces text-2xl md:text-3xl font-bold text-piedra-900 mb-4">
                {dict.actividades.laExperiencia}
              </h2>
              <div
                className="prose-guia"
                dangerouslySetInnerHTML={{ __html: actividad.contenidoHtml }}
              />
            </div>
            </PlegableMovil>

            {/* 9. Accesibilidad — frase global simple */}
            {actividad.accesibilidad && (
              <div className="bg-white border border-piedra-200 rounded-lg p-6 md:p-7">
                <h2 className="font-fraunces text-xl md:text-2xl font-bold text-piedra-900 mb-3">
                  Accesibilidad
                </h2>
                <p className="text-piedra-700 leading-relaxed">
                  {actividad.accesibilidad}
                </p>
              </div>
            )}

            {/* 11. Política de cancelación — párrafo claro */}
            {actividad.politicaCancelacion && (
              <div className="bg-white border border-piedra-200 rounded-lg p-6 md:p-7">
                <h2 className="font-fraunces text-xl md:text-2xl font-bold text-piedra-900 mb-3">
                  Política de cancelación
                </h2>
                <p className="text-piedra-700 leading-relaxed">
                  {actividad.politicaCancelacion}
                </p>
              </div>
            )}

            {/* 12. Preguntas frecuentes — sin JSON-LD por ahora */}
            <FaqActividad idioma="es" preguntas={actividad.preguntasFrecuentes || []} />

            {/* 13. Guías relacionadas */}
            {guiasRelacionadas.length > 0 && (
              <div className="bg-piedra-50 border border-piedra-200 rounded-lg p-6">
                <h2 className="font-fraunces text-xl md:text-2xl font-bold text-piedra-900 mb-4">
                  {dict.actividades.guiasRelacionadas}
                </h2>
                <div className="space-y-3">
                  {guiasRelacionadas.map((guia) => (
                    <Link
                      key={guia.url}
                      href={guia.url}
                      className="block group"
                    >
                      <h3 className="font-semibold text-piedra-900 group-hover:text-anil-700 transition-colors">
                        → {guia.titulo}
                      </h3>
                      <p className="text-sm text-piedra-600 mt-1">
                        {guia.descripcion}
                      </p>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* 13b. Reseñas reales del proveedor (Tripadvisor Content API),
                al final del contenido por decisión de Borja (24-10-2026) */}
            {fuenteResenas && (
              <ResenasTripadvisor
                idioma="es"
                locationId={fuenteResenas.locationId}
                nombreProveedor={fuenteResenas.nombre}
              />
            )}

            {/* 14. Disclosure de afiliación */}
            <p className="text-xs text-piedra-500 border-t border-piedra-200 pt-6">
              {dict.actividades.avisoAfiliacion}
            </p>

            {/* 15. Referencia al proveedor (cierre) */}
            <SelloProveedor proveedor={actividad.proveedor} idioma="es" conLogo />
          </div>

          {/* Bókun: un solo widget. En móvil el aside se apila tras el contenido
              (la barra fija y el CTA de cabecera bajan hasta él); para afiliados
              el aside solo existe en escritorio y en móvil manda la barra sticky. */}
          <aside
            id={actividad.proveedor === "bokun" ? ANCLA_RESERVA : undefined}
            className={
              actividad.proveedor === "bokun"
                ? "lg:col-span-1 scroll-mt-24"
                : "hidden lg:block lg:col-span-1"
            }
          >
            <div className="lg:sticky lg:top-24">
              {actividad.proveedor === "bokun" ? (
                <BokunWidget
                  idioma="es"
                  productId={actividad.bokunProductId ?? 0}
                  precioDesde={actividad.precioDesde}
                  moneda={actividad.moneda}
                  porGrupo={actividad.categoria === "experienciasPrivadas"}
                  ratingProveedor={actividad.ratingProveedor}
                  numeroOpiniones={actividad.numeroOpiniones}
                  minimoPersonas={actividad.minimoPersonas}
                />
              ) : tourWidget ? (
                <WidgetDisponibilidadGyg
                  tourId={tourWidget}
                  idioma="es"
                  urlReserva={urlReservaBase}
                  cabecera={precioWidget}
                  soloEn="escritorio"
                  fallback={bloqueCalendario}
                />
              ) : (
                bloqueCalendario
              )}
              <div className="mt-3 flex justify-center">
                <SelloProveedor proveedor={actividad.proveedor} idioma="es" conLogo />
              </div>
            </div>
          </aside>
        </div>
      </section>

      <ActividadesRecomendadasGuia

        actividades={actividadesParecidas}

        idioma="es"

        nombreCiudad={ciudad.nombre}

        urlTodas={urlActividadesDeCiudad("es", params.ciudad)}

        variante="ficha"

      />


      <div className="max-w-6xl mx-auto px-4 py-12 text-center">
        <BotonVolverFicha
          urlActividadesCiudad={
            actividad.atraccionesRelacionadas?.[0]
              ? `${urlActividadesDeCiudad("es", params.ciudad)}?atraccion=${actividad.atraccionesRelacionadas[0]}`
              : urlActividadesDeCiudad("es", params.ciudad)
          }
          textoActividadesCiudad={`← Ver más actividades en ${ciudad.nombre}`}
        />
      </div>

      {actividad.proveedor === "bokun" && (
        <StickyReservaBokun
          aviso={actividad.avisoReserva}
          ratingProveedor={actividad.ratingProveedor}
          numeroOpiniones={actividad.numeroOpiniones}
          idioma="es"
          precioDesde={actividad.precioDesde}
          moneda={actividad.moneda}
          porGrupo={actividad.categoria === "experienciasPrivadas"}
          minimoPersonas={actividad.minimoPersonas}
        />
      )}

      {actividad.proveedor !== "bokun" && (
        <StickyReservaMovil
          anclaWidget={tourWidget ? ANCLA_WIDGET_GYG : undefined}
          aviso={actividad.avisoReserva}
          idioma="es"
          precio={`${dict.actividades.desde} ${precio}`}
          valorEstimado={precioDesdeFinal}
          monedaEstimada={actividad.moneda}
          precioPorPersona={dict.actividades.porPersona}
          duracion={actividad.duracion}
          idiomas={actividad.idiomas}
          cancelacionGratuita={actividad.cancelacionGratuita}
          horasCancelacion={actividad.horasCancelacion}
          ratingProveedor={actividad.ratingProveedor}
          numeroOpiniones={actividad.numeroOpiniones}
          urlReservaBase={urlReservaBase}
          nombreProveedor={nombreComercialProveedor}
          textoReservar={dict.actividades.reservar}
          textoOpiniones={dict.actividades.opiniones}
          textoDesde={dict.actividades.desde}
          textoPorPersona={dict.actividades.porPersona}
          textoDuracion={dict.actividades.duracion}
          textoIdiomas={dict.actividades.idiomas}
          textoCancelacionHorasAntes={dict.actividades.cancelacionHorasAntes}
          textoCancelacionGratuita={dict.actividades.cancelacionGratuita}
        />
      )}
      <OtrosIdiomas
        idioma={"es"}
        rutas={rutasPorIdioma((l) => {
          const slugPareja = slugParejaActividad("es", params.ciudad, params.slug, l);
          return slugPareja ? urlActividad(l, params.ciudad, slugPareja) : null;
        })}
      />
    </main>
  );
}

function buildProductLd(
  actividad: ActividadCompleta,
  url: string,
  urlReservaFinal: string
) {
  const imagenAbsoluta = actividad.imagen.startsWith("http")
    ? actividad.imagen
    : `${SITE_URL}${actividad.imagen}`;
  const ld: Record<string, unknown> = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: actividad.titulo,
    description: actividad.descripcion,
    image: actividad.imagen ? [imagenAbsoluta] : undefined,
    category: actividad.categoria,
    inLanguage: "es",
    url,
    offers: {
      "@type": "Offer",
      url: urlReservaFinal || url,
      priceCurrency: actividad.moneda,
      price: actividad.precioDesde,
      availability: "https://schema.org/InStock",
    },
  };
  // Sin `brand` (el operador no es la marca del producto), sin
  // `aggregateRating` (Google no admite notas recogidas en otras webs,
  // como las de GetYourGuide) y sin `review` editorial (exige
  // `reviewRating`, que no tenemos). La nota se sigue mostrando en pantalla.
  return ld;
}
