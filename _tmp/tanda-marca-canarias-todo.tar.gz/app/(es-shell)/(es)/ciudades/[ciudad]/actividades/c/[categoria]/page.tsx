import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { obtenerCiudad } from "@/lib/ciudades";
import {
  obtenerActividadesDeCiudadPorCategoria,
  obtenerCategoriasConActividades,
  obtenerCiudadesConActividades,
  categoriaDesdeUrl,
  type ActividadListItem,
  type CategoriaActividad,
  urlCategoriaActividadesSiExiste,
  MIN_FICHAS_CATEGORIA_INDEXABLE,
} from "@/lib/actividades";
import { getDictionary } from "@/lib/i18n/getDictionary";
import {
  hreflangAlternates,
  urlActividadesDeCiudad,
  urlActividadesDeCiudadPorCategoria,
} from "@/lib/i18n/utils";
import SelloProveedor from "@/components/SelloProveedor";

const SITE_URL =
  process.env.NEXT_PUBLIC_SITE_URL || "https://www.exploraspain.com";

/**
 * Etiqueta editorial en plural para construir títulos del tipo
 * "Visitas guiadas en Madrid". Las nuevas categorías son ya sustantivos
 * comerciales en plural, así que reusamos el mismo label en H1 y meta.
 */
const LABEL_CATEGORIA: Record<CategoriaActividad, string> = {
  visitasGuiadas: "Visitas guiadas",
  entradas: "Entradas",
  excursionesDia: "Excursiones de un día",
  espectaculos: "Espectáculos",
  toursGastronomicos: "Gastronomía",
  serviciosAdicionales: "Bienestar y relax",
  transporte: "Transporte",
  experienciasPrivadas: "Experiencias privadas",
};

/**
 * Construye los textos editoriales (h1, descripción y meta) para una
 * categoría dada. Caso especial `excursionesDia`: en español queda más
 * natural "desde Madrid" que "en Madrid" (porque la actividad sale de
 * la ciudad). El resto usa "en {ciudad}".
 */
function textosCategoria(
  categoria: CategoriaActividad,
  nombreCiudad: string
): { titulo: string; descripcion: string } {
  const label = LABEL_CATEGORIA[categoria];
  const preposicion =
    categoria === "excursionesDia" ? `desde ${nombreCiudad}` : `en ${nombreCiudad}`;

  return {
    titulo: `${label} ${preposicion}`,
    descripcion: `${label} ${preposicion}, seleccionadas con criterio editorial.`,
  };
}

type Props = {
  params: { ciudad: string; categoria: string };
};

/**
 * Solo generamos páginas de categoría para combinaciones (ciudad, categoría)
 * con al menos una actividad publicada en español. Esto evita crear páginas
 * vacías indexables y caminos que devolverían 404.
 */
export async function generateStaticParams() {
  const params: { ciudad: string; categoria: string }[] = [];
  for (const ciudad of obtenerCiudadesConActividades("es")) {
    for (const cat of obtenerCategoriasConActividades("es", ciudad)) {
      params.push({ ciudad, categoria: cat.urlSlug });
    }
  }
  return params;
}

export async function generateMetadata({
  params,
}: Props): Promise<Metadata> {
  const ciudad = await obtenerCiudad("es", params.ciudad);
  if (!ciudad) return { title: "Ciudad no encontrada" };

  const categoria = categoriaDesdeUrl(params.categoria);
  if (!categoria) return { title: "Categoría no encontrada" };

  const { titulo, descripcion } = textosCategoria(categoria, ciudad.nombre);
  const url = `${SITE_URL}${urlActividadesDeCiudadPorCategoria(
    "es",
    params.ciudad,
    params.categoria
  )}`;
  const allowIndexing = process.env.NEXT_PUBLIC_ALLOW_INDEXING === "true";
  // Categorías con pocas fichas = contenido fino: fuera del índice, pero
  // Google sigue los enlaces a las fichas.
  const suficientes =
    obtenerActividadesDeCiudadPorCategoria("es", params.ciudad, categoria)
      .length >= MIN_FICHAS_CATEGORIA_INDEXABLE;

  return {
    title: titulo,
    description: descripcion,
    robots: {
      index: allowIndexing && suficientes,
      follow: allowIndexing,
    },
    alternates: {
      canonical: url,
      languages: hreflangAlternates((l) =>
        urlCategoriaActividadesSiExiste(l, params.ciudad, params.categoria)
      ),
    },
    openGraph: {
      type: "website",
      url,
      title: `${titulo} | ExploraSpain`,
      description: descripcion,
      siteName: "ExploraSpain",
      locale: "es_ES",
    },
  };
}

export default async function ActividadesCategoriaPage({ params }: Props) {
  const ciudad = await obtenerCiudad("es", params.ciudad);
  if (!ciudad) notFound();

  const categoria = categoriaDesdeUrl(params.categoria);
  if (!categoria) notFound();

  const actividades = obtenerActividadesDeCiudadPorCategoria(
    "es",
    params.ciudad,
    categoria
  );
  if (actividades.length === 0) notFound();

  const dict = getDictionary("es");
  const labelCategoria = dict.actividades.categorias[categoria];
  const { titulo: tituloPagina, descripcion: descripcionPagina } =
    textosCategoria(categoria, ciudad.nombre);

  const urlIndice = urlActividadesDeCiudad("es", params.ciudad);
  const urlCategoria = urlActividadesDeCiudadPorCategoria(
    "es",
    params.ciudad,
    params.categoria
  );

  const breadcrumbsLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: dict.navegacion.inicio,
        item: SITE_URL,
      },
      {
        "@type": "ListItem",
        position: 2,
        name: ciudad.nombre,
        item: `${SITE_URL}${ciudad.url}`,
      },
      {
        "@type": "ListItem",
        position: 3,
        name: "Actividades",
        item: `${SITE_URL}${urlIndice}`,
      },
      {
        "@type": "ListItem",
        position: 4,
        name: labelCategoria,
        item: `${SITE_URL}${urlCategoria}`,
      },
    ],
  };

  const itemListLd = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    itemListElement: actividades.map((a, i) => ({
      "@type": "ListItem",
      position: i + 1,
      url: `${SITE_URL}${a.url}`,
      name: a.titulo,
    })),
  };

  return (
    <main className="min-h-screen bg-white">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbsLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(itemListLd) }}
      />

      <header className="border-b border-piedra-200 bg-piedra-50">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
          <nav
            aria-label="Migas de pan"
            className="mb-6 text-sm text-piedra-500"
          >
            <ol className="flex flex-wrap items-center gap-x-2">
              <li>
                <Link href="/" className="hover:text-piedra-700">
                  {dict.navegacion.inicio}
                </Link>
              </li>
              <li aria-hidden="true">/</li>
              <li>
                <Link href={ciudad.url} className="hover:text-piedra-700">
                  {ciudad.nombre}
                </Link>
              </li>
              <li aria-hidden="true">/</li>
              <li>
                <Link href={urlIndice} className="hover:text-piedra-700">
                  Actividades
                </Link>
              </li>
              <li aria-hidden="true">/</li>
              <li className="text-piedra-700">{labelCategoria}</li>
            </ol>
          </nav>

          <h1 className="text-4xl font-semibold tracking-tight text-piedra-900 sm:text-5xl">
            {tituloPagina}
          </h1>
          <p className="mt-4 max-w-2xl text-lg text-piedra-600">
            {descripcionPagina}
          </p>
        </div>
      </header>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {actividades.map((actividad) => (
            <TarjetaActividad
              key={actividad.slug}
              actividad={actividad}
              dict={dict}
            />
          ))}
        </div>
      </section>
    </main>
  );
}

function TarjetaActividad({
  actividad,
  dict,
}: {
  actividad: ActividadListItem;
  dict: ReturnType<typeof getDictionary>;
}) {
  const formatoPrecio = new Intl.NumberFormat("es-ES", {
    style: "currency",
    currency: actividad.moneda,
    maximumFractionDigits: 0,
  });

  return (
    <Link
      href={actividad.url}
      className="group flex flex-col overflow-hidden rounded-xl border border-piedra-200 bg-white shadow-sm transition hover:border-piedra-300 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-anil-500 focus-visible:ring-offset-2"
    >
      {actividad.imagen ? (
        <div className="relative aspect-[4/3] w-full overflow-hidden bg-piedra-100">
          <Image
            src={actividad.imagen}
            alt={actividad.imagenAlt}
            fill
            sizes="(min-width: 1024px) 33vw, (min-width: 768px) 50vw, 100vw"
            className="object-cover transition duration-300 group-hover:scale-105"
          />
        </div>
      ) : (
        <div className="aspect-[4/3] w-full bg-piedra-100" aria-hidden="true" />
      )}

      <div className="flex flex-1 flex-col p-6">
        <h2 className="text-lg font-semibold text-piedra-900">
          {actividad.titulo}
        </h2>

        <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-piedra-500">
          {actividad.duracion ? <span>{actividad.duracion}</span> : null}
          {typeof actividad.ratingProveedor === "number" &&
          typeof actividad.numeroOpiniones === "number" ? (
            <span>
              {actividad.ratingProveedor.toFixed(1)} ★ (
              {actividad.numeroOpiniones})
            </span>
          ) : null}
        </div>

        <div className="mt-auto pt-6">
          <SelloProveedor
            proveedor={actividad.proveedor}
            idioma="es"
            className="mb-3"
          />
          <div className="flex items-end justify-between">
            <div>
              <p className="text-xs uppercase tracking-wide text-piedra-400">
                {dict.actividades.desde}
              </p>
              <p className="text-xl font-semibold text-piedra-900">
                {formatoPrecio.format(actividad.precioDesde)}
              </p>
            </div>
            <span
              aria-hidden="true"
              className="text-sm font-semibold text-anil-600 group-hover:text-anil-700"
            >
              {dict.actividades.verActividad} →
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
}
