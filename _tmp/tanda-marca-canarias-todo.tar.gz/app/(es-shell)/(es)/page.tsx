import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { obtenerGuiasDestacadas } from "@/lib/guias";
import { obtenerListaCiudades } from "@/lib/ciudades";
import { obtenerActividadesHome } from "@/lib/actividades";
import {
  formatearFecha,
  hreflangAlternates,
  prefijoIdioma,
  urlActividadesDeCiudad,
  urlIndiceCiudades,
} from "@/lib/i18n/utils";
import SelloProveedor from "@/components/SelloProveedor";
import HeroHome from "@/components/home/HeroHome";
import FranjaConfianza, { FranjaPartners } from "@/components/home/FranjaConfianza";

const SITE_URL =
  process.env.NEXT_PUBLIC_SITE_URL || "https://www.exploraspain.com";

/**
 * Destinos principales que se muestran en la home (orden manual). El resto
 * de ciudades sigue accesible desde /ciudades. Civitatis-style: pocos
 * destinos, muy visuales.
 */
const ORDEN_DESTINOS_HOME = [
  "madrid",
  "barcelona",
  "sevilla",
  "granada",
  "valencia",
  "malaga",
] as const;

export const metadata: Metadata = {
  // `absolute` evita la plantilla "%s | ExploraSpain" (marca duplicada).
  title: { absolute: "ExploraSpain · Actividades, tours y guías de España" },
  description:
    "Actividades, tours y guías de viaje por España elegidos por expertos locales: Madrid, Barcelona, Sevilla, Granada y más. Cancelación gratuita y partners de confianza.",
  alternates: {
    canonical: `${SITE_URL}/`,
    languages: hreflangAlternates((l) => prefijoIdioma(l) || "/"),
  },
  openGraph: {
    type: "website",
    locale: "es_ES",
    url: `${SITE_URL}/`,
    siteName: "ExploraSpain",
    title: "ExploraSpain · Actividades, tours y guías de España",
    description:
      "Actividades, tours y guías de viaje por España elegidos por expertos locales. Cancelación gratuita y reserva con partners de confianza.",
  },
};

/** Formatea un precio en euros sin decimales (es-ES). */
function formatearPrecio(precio: number, moneda: string): string {
  return new Intl.NumberFormat("es-ES", {
    style: "currency",
    currency: moneda || "EUR",
    maximumFractionDigits: 0,
  }).format(precio);
}

export default function HomePage() {
  const ciudades = obtenerListaCiudades("es");
  const guias = obtenerGuiasDestacadas("es", 6);

  // Mapa slug -> nombre de ciudad para etiquetar las tarjetas.
  const nombrePorCiudad = new Map(ciudades.map((c) => [c.slug, c.nombre]));

  // Destinos principales de la home: 6 ciudades en orden manual. Si alguna
  // no estuviera publicada, simplemente se omite (sin huecos).
  const porSlug = new Map(ciudades.map((c) => [c.slug, c]));
  const destinosHome = ORDEN_DESTINOS_HOME.map((s) => porSlug.get(s)).filter(
    (c): c is NonNullable<typeof c> => c != null
  );

  // Actividades estrella de la home: las que promocionamos en Google Ads.
  // Selección curada en lib/actividades.ts (obtenerActividadesHome).
  const actividadesHome = obtenerActividadesHome("es");

  const websiteJsonLd = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: "ExploraSpain",
    url: SITE_URL,
    inLanguage: "es-ES",
    description:
      "Actividades, tours y guías de viaje por España elegidos por expertos locales: reserva con cancelación gratuita y partners de confianza.",
  };

  const organizationJsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "@id": `${SITE_URL}/#organization`,
    name: "ExploraSpain",
    legalName: "SKYWARD PARTNERS, S.L.",
    url: SITE_URL,
    logo: `${SITE_URL}/logo-square.png`,
    email: "contacto@exploraspain.com",
    address: {
      "@type": "PostalAddress",
      streetAddress: "Calle Castelló 117",
      postalCode: "28006",
      addressLocality: "Madrid",
      addressCountry: "ES",
    },
    taxID: "B26629576",
  };

  return (
    <main>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(organizationJsonLd),
        }}
      />

      <HeroHome
        idioma={"es"}
        opciones={ciudades.map((c) => ({
          nombre: c.nombre,
          url: urlActividadesDeCiudad("es", c.slug),
        }))}
        urlTodos={urlIndiceCiudades("es")}
        anclaDestinos="#destinos"
      />
      <FranjaConfianza idioma={"es"} />

      {/* Principales destinos */}
      {destinosHome.length > 0 && (
        <section
          id="destinos"
          className="max-w-6xl mx-auto px-4 py-16 md:py-20 scroll-mt-24"
        >
          <div className="mb-10">
            <h2 className="font-fraunces text-3xl md:text-4xl font-bold text-piedra-900 mb-3">
              Principales destinos
            </h2>
            <p className="text-piedra-600 text-lg">
              Elige tu ciudad y descubre las mejores actividades en cada una.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {destinosHome.map((ciudad, index) => (
              <Link
                key={ciudad.url}
                href={urlActividadesDeCiudad("es", ciudad.slug)}
                className="group relative block h-56 md:h-64 rounded-xl overflow-hidden shadow-sm"
              >
                <Image
                  src={`/ciudades/${ciudad.slug}.jpg`}
                  alt={`${ciudad.nombre}, ${ciudad.comunidad}`}
                  fill
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                  priority={index === 0}
                />
                {/* Degradado inferior para legibilidad del nombre */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-5">
                  <span className="inline-block bg-white/90 text-piedra-800 text-[11px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded mb-2">
                    {ciudad.comunidad}
                  </span>
                  <h3 className="font-fraunces text-2xl md:text-3xl font-bold text-white leading-tight drop-shadow">
                    {ciudad.nombre}
                  </h3>
                </div>
              </Link>
            ))}
          </div>

          <div className="mt-10 text-center">
            <Link
              href="/ciudades"
              className="inline-block text-anil-600 hover:text-anil-700 font-semibold"
            >
              Ver todas las ciudades →
            </Link>
          </div>
        </section>
      )}

      {/* Actividades y tours destacados (debajo de los destinos) */}
      {actividadesHome.length > 0 && (
        <section
          id="actividades"
          className="bg-piedra-50 border-y border-piedra-200 scroll-mt-24"
        >
          <div className="max-w-6xl mx-auto px-4 py-16 md:py-20">
            <div className="mb-10">
              <h2 className="font-fraunces text-3xl md:text-4xl font-bold text-piedra-900 mb-3">
                Actividades destacadas
              </h2>
              <p className="text-piedra-600 text-lg">
                Lo mejor de cada ciudad: cancelación gratuita y confirmación
                inmediata.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {actividadesHome.map((a) => (
                <Link
                  key={a.url}
                  href={a.url}
                  className="group flex flex-col overflow-hidden rounded-xl border border-piedra-200 bg-white shadow-sm transition hover:border-anil-400 hover:shadow-md"
                >
                  <div className="relative aspect-[4/3] w-full overflow-hidden bg-piedra-100">
                    {a.imagen ? (
                      <Image
                        src={a.imagen}
                        alt={a.imagenAlt}
                        fill
                        sizes="(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"
                        className="object-cover transition duration-300 group-hover:scale-105"
                      />
                    ) : null}
                    {a.cancelacionGratuita ? (
                      <span className="absolute top-3 left-3 bg-azafran-500 text-piedra-900 text-xs font-semibold px-2 py-1 rounded">
                        Cancelación gratuita
                      </span>
                    ) : null}
                  </div>
                  <div className="flex flex-1 flex-col p-5">
                    {/* Siempre se pinta (vacío si no hay ciudad) para que todas las tarjetas midan igual. */}
                    <span className="h-4 text-xs font-semibold uppercase tracking-wider text-anil-700 mb-2">
                      {nombrePorCiudad.get(a.ciudad) ?? ""}
                    </span>
                    <h3 className="font-fraunces text-lg font-bold text-piedra-900 mb-2 group-hover:text-anil-700 transition-colors leading-tight line-clamp-2 min-h-[2.5em]">
                      {a.titulo}
                    </h3>
                    <div className="flex items-center gap-x-3 h-5 overflow-hidden whitespace-nowrap text-sm text-piedra-500 mb-4">
                      {a.duracion ? (
                        <span className="min-w-0 truncate">{a.duracion}</span>
                      ) : null}
                      {typeof a.ratingProveedor === "number" &&
                      typeof a.numeroOpiniones === "number" ? (
                        <span className="shrink-0">
                          <span className="text-azafran-600" aria-hidden="true">
                            ★
                          </span>{" "}
                          {a.ratingProveedor.toFixed(1)} ({a.numeroOpiniones})
                        </span>
                      ) : null}
                    </div>
                    <div className="mt-auto pt-4 border-t border-piedra-100">
                      <SelloProveedor
                        proveedor={a.proveedor}
                        idioma="es"
                        className="mb-3"
                      />
                      <div className="flex items-end justify-between">
                        <div>
                          <p className="text-xs uppercase tracking-wider text-piedra-400">
                            Desde
                          </p>
                          <p className="text-xl font-bold text-piedra-900">
                            {formatearPrecio(a.precioDesde, a.moneda)}
                          </p>
                        </div>
                        <span
                          aria-hidden="true"
                          className="text-sm font-semibold text-anil-600 group-hover:text-anil-700"
                        >
                          Ver actividad →
                        </span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Guías (accesorio) */}
      {guias.length > 0 && (
        <section className="max-w-6xl mx-auto px-4 py-14 md:py-16">
          <div className="flex flex-wrap items-end justify-between gap-3 mb-8">
            <div>
              <h2 className="font-fraunces text-2xl md:text-3xl font-bold text-piedra-900 mb-2">
                Guías para viajar mejor
              </h2>
              <p className="text-piedra-600">
                Consejos prácticos y rutas con criterio antes de reservar.
              </p>
            </div>
            <Link
              href="/guias"
              className="text-anil-600 hover:text-anil-700 font-semibold whitespace-nowrap"
            >
              Ver todas las guías →
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {guias.map((guia) => (
              <Link
                key={guia.url}
                href={guia.url}
                className="group block border border-piedra-200 rounded-lg p-6 hover:border-anil-400 hover:shadow-md transition-all"
              >
                <span className="inline-block bg-anil-100 text-anil-700 text-xs font-semibold uppercase tracking-wider px-2 py-1 rounded mb-3">
                  {guia.categoria}
                </span>
                <h3 className="font-fraunces text-lg font-bold text-piedra-900 mb-2 group-hover:text-anil-700 transition-colors">
                  {guia.titulo}
                </h3>
                <p className="text-piedra-600 text-sm leading-relaxed mb-4 line-clamp-3">
                  {guia.descripcion}
                </p>
                <div className="flex items-center justify-between text-xs text-piedra-500">
                  <span>{formatearFecha(guia.fecha, "es")}</span>
                  <span>{guia.tiempoLectura} min lectura</span>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
      <FranjaPartners idioma={"es"} />
    </main>
  );
}
