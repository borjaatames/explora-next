import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { obtenerCiudad } from "@/lib/ciudades";
import {
  obtenerActividadesDeCiudadPorCategoria,
  obtenerCategoriasConActividades,
  obtenerCiudadesConActividades,
  categoriaDesdeUrl,
  type ActividadListItem,
  type CategoriaActividad,
  urlCategoriaActividadesSiExiste,
  MIN_FICHAS_CATEGORIA_INDEXABLE,
} from "@/lib/actividades";
import { getDictionary } from "@/lib/i18n/getDictionary";
import { esIdiomaActivo, IDIOMAS_ACTIVOS, IDIOMA_LOCALE } from "@/lib/i18n/config";
import {
  hreflangAlternates,
  prefijoIdioma,
  urlActividadesDeCiudad,
  urlActividadesDeCiudadPorCategoria,
} from "@/lib/i18n/utils";
import type { Idioma } from "@/lib/i18n/types";
import SelloProveedor from "@/components/SelloProveedor";

const SITE_URL =
  process.env.NEXT_PUBLIC_SITE_URL || "https://www.exploraspain.com";

/**
 * Plural label used as both the user-facing category name and inside the
 * H1 / meta. The new categories are already commercial nouns in plural,
 * so we reuse the same label for both purposes.
 */
const LABEL_CATEGORIA: Record<CategoriaActividad, string> = {
  visitasGuiadas: "Guided tours",
  entradas: "Tickets",
  excursionesDia: "Day trips",
  espectaculos: "Shows",
  toursGastronomicos: "Food & drink",
  serviciosAdicionales: "Wellness",
  transporte: "Transport",
  experienciasPrivadas: "Private experiences",
};

/**
 * Builds editorial copy (h1, description, meta) for a given category.
 * Special case `excursionesDia`: "Day trips from {city}" reads more
 * naturally than "Day trips in {city}".
 */
function textosCategoria(
  categoria: CategoriaActividad,
  nombreCiudad: string
): { titulo: string; descripcion: string } {
  const label = LABEL_CATEGORIA[categoria];
  const preposicion =
    categoria === "excursionesDia"
      ? `from ${nombreCiudad}`
      : `in ${nombreCiudad}`;

  return {
    titulo: `${label} ${preposicion}`,
    descripcion: `${label} ${preposicion}, hand-picked with editorial criteria. No filler.`,
  };
}

type Props = {
  params: { lang: string; ciudad: string; categoria: string };
};

/**
 * Solo genera páginas de categoría para (idioma, ciudad, categoría) con
 * al menos una actividad publicada. Recorre todos los idiomas activos
 * != es; hoy solo `en` tiene contenido, así que en la práctica solo se
 * generan rutas /en/... — cuando haya contenido en otro idioma activo,
 * se recoge automáticamente sin tocar código.
 */
export async function generateStaticParams() {
  const params: { lang: string; ciudad: string; categoria: string }[] = [];
  for (const lang of IDIOMAS_ACTIVOS) {
    if (lang === "es") continue;
    for (const ciudad of obtenerCiudadesConActividades(lang)) {
      for (const cat of obtenerCategoriasConActividades(lang, ciudad)) {
        params.push({ lang, ciudad, categoria: cat.urlSlug });
      }
    }
  }
  return params;
}

export async function generateMetadata({
  params,
}: Props): Promise<Metadata> {
  if (!esIdiomaActivo(params.lang) || params.lang === "es") {
    return { title: "Not found" };
  }
  const lang: Idioma = params.lang;
  const ciudad = await obtenerCiudad(lang, params.ciudad);
  if (!ciudad) return { title: "City not found" };

  const categoria = categoriaDesdeUrl(params.categoria);
  if (!categoria) return { title: "Category not found" };

  const { titulo, descripcion } = textosCategoria(categoria, ciudad.nombre);
  const url = `${SITE_URL}${urlActividadesDeCiudadPorCategoria(
    lang,
    params.ciudad,
    params.categoria
  )}`;
  const allowIndexing = process.env.NEXT_PUBLIC_ALLOW_INDEXING === "true";
  // Categorías con pocas fichas = contenido fino: fuera del índice, pero
  // Google sigue los enlaces a las fichas.
  const suficientes =
    obtenerActividadesDeCiudadPorCategoria(lang, params.ciudad, categoria)
      .length >= MIN_FICHAS_CATEGORIA_INDEXABLE;

  return {
    title: titulo,
    description: descripcion,
    robots: {
      index: allowIndexing && suficientes,
      follow: allowIndexing,
    },
    alternates: {
      canonical: url,
      languages: hreflangAlternates((l) =>
        urlCategoriaActividadesSiExiste(l, params.ciudad, params.categoria)
      ),
    },
    openGraph: {
      type: "website",
      url,
      title: `${titulo} | ExploraSpain`,
      description: descripcion,
      siteName: "ExploraSpain",
      locale: IDIOMA_LOCALE[lang],
    },
  };
}

export default async function ActividadesCategoriaPage({ params }: Props) {
  if (!esIdiomaActivo(params.lang) || params.lang === "es") {
    notFound();
  }
  const lang: Idioma = params.lang;
  const ciudad = await obtenerCiudad(lang, params.ciudad);
  if (!ciudad) notFound();

  const categoria = categoriaDesdeUrl(params.categoria);
  if (!categoria) notFound();

  const actividades = obtenerActividadesDeCiudadPorCategoria(
    lang,
    params.ciudad,
    categoria
  );
  if (actividades.length === 0) notFound();

  const dict = getDictionary(lang);
  const labelCategoria = dict.actividades.categorias[categoria];
  const { titulo: tituloPagina, descripcion: descripcionPagina } =
    textosCategoria(categoria, ciudad.nombre);

  const urlIndice = urlActividadesDeCiudad(lang, params.ciudad);
  const urlCategoria = urlActividadesDeCiudadPorCategoria(
    lang,
    params.ciudad,
    params.categoria
  );

  const breadcrumbsLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: dict.navegacion.inicio,
        item: SITE_URL,
      },
      {
        "@type": "ListItem",
        position: 2,
        name: ciudad.nombre,
        item: `${SITE_URL}${ciudad.url}`,
      },
      {
        "@type": "ListItem",
        position: 3,
        name: "Things to do",
        item: `${SITE_URL}${urlIndice}`,
      },
      {
        "@type": "ListItem",
        position: 4,
        name: labelCategoria,
        item: `${SITE_URL}${urlCategoria}`,
      },
    ],
  };

  const itemListLd = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    itemListElement: actividades.map((a, i) => ({
      "@type": "ListItem",
      position: i + 1,
      url: `${SITE_URL}${a.url}`,
      name: a.titulo,
    })),
  };

  return (
    <main className="min-h-screen bg-white">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbsLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(itemListLd) }}
      />

      <header className="border-b border-piedra-200 bg-piedra-50">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
          <nav aria-label="Breadcrumb" className="mb-6 text-sm text-piedra-500">
            <ol className="flex flex-wrap items-center gap-x-2">
              <li>
                <Link href={prefijoIdioma(lang) || "/"} className="hover:text-piedra-700">
                  {dict.navegacion.inicio}
                </Link>
              </li>
              <li aria-hidden="true">/</li>
              <li>
                <Link href={ciudad.url} className="hover:text-piedra-700">
                  {ciudad.nombre}
                </Link>
              </li>
              <li aria-hidden="true">/</li>
              <li>
                <Link href={urlIndice} className="hover:text-piedra-700">
                  Things to do
                </Link>
              </li>
              <li aria-hidden="true">/</li>
              <li className="text-piedra-700">{labelCategoria}</li>
            </ol>
          </nav>

          <h1 className="text-4xl font-semibold tracking-tight text-piedra-900 sm:text-5xl">
            {tituloPagina}
          </h1>
          <p className="mt-4 max-w-2xl text-lg text-piedra-600">
            {descripcionPagina}
          </p>
        </div>
      </header>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {actividades.map((actividad) => (
            <TarjetaActividad
              key={actividad.slug}
              actividad={actividad}
              dict={dict}
              lang={lang}
            />
          ))}
        </div>
      </section>
    </main>
  );
}

function TarjetaActividad({
  actividad,
  dict,
  lang,
}: {
  actividad: ActividadListItem;
  dict: ReturnType<typeof getDictionary>;
  lang: Idioma;
}) {
  const formatoPrecio = new Intl.NumberFormat(IDIOMA_LOCALE[lang], {
    style: "currency",
    currency: actividad.moneda,
    maximumFractionDigits: 0,
  });

  return (
    <Link
      href={actividad.url}
      className="group flex flex-col overflow-hidden rounded-xl border border-piedra-200 bg-white shadow-sm transition hover:border-piedra-300 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-anil-500 focus-visible:ring-offset-2"
    >
      {actividad.imagen ? (
        <div className="relative aspect-[4/3] w-full overflow-hidden bg-piedra-100">
          <Image
            src={actividad.imagen}
            alt={actividad.imagenAlt}
            fill
            sizes="(min-width: 1024px) 33vw, (min-width: 768px) 50vw, 100vw"
            className="object-cover transition duration-300 group-hover:scale-105"
          />
        </div>
      ) : (
        <div className="aspect-[4/3] w-full bg-piedra-100" aria-hidden="true" />
      )}

      <div className="flex flex-1 flex-col p-6">
        <h2 className="text-lg font-semibold text-piedra-900">
          {actividad.titulo}
        </h2>

        <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-piedra-500">
          {actividad.duracion ? <span>{actividad.duracion}</span> : null}
          {typeof actividad.ratingProveedor === "number" &&
          typeof actividad.numeroOpiniones === "number" ? (
            <span>
              {actividad.ratingProveedor.toFixed(1)} ★ (
              {actividad.numeroOpiniones})
            </span>
          ) : null}
        </div>

        <div className="mt-auto pt-6">
          <SelloProveedor
            proveedor={actividad.proveedor}
            idioma={lang}
            className="mb-3"
          />
          <div className="flex items-end justify-between">
            <div>
              <p className="text-xs uppercase tracking-wide text-piedra-400">
                {dict.actividades.desde}
              </p>
              <p className="text-xl font-semibold text-piedra-900">
                {formatoPrecio.format(actividad.precioDesde)}
              </p>
            </div>
            <span
              aria-hidden="true"
              className="text-sm font-semibold text-anil-600 group-hover:text-anil-700"
            >
              {dict.actividades.verActividad} →
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
}
