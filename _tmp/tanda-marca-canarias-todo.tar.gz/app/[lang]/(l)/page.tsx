import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { obtenerGuiasDestacadas } from "@/lib/guias";
import { obtenerListaCiudades } from "@/lib/ciudades";
import {
  obtenerActividadesHome,
  urlListadoActividadesSiExiste,
} from "@/lib/actividades";
import {
  IDIOMAS_ACTIVOS,
  IDIOMA_LOCALE,
  esIdiomaActivo,
} from "@/lib/i18n/config";
import { getDictionary } from "@/lib/i18n/getDictionary";
import {
  formatearFecha,
  hreflangAlternates,
  prefijoIdioma,
  urlIndiceGuias,
  urlIndiceCiudades,
  urlCiudad,
} from "@/lib/i18n/utils";
import type { Idioma } from "@/lib/i18n/types";
import SelloProveedor from "@/components/SelloProveedor";
import HeroHome from "@/components/home/HeroHome";
import FranjaConfianza, { FranjaPartners } from "@/components/home/FranjaConfianza";

const SITE_URL =
  process.env.NEXT_PUBLIC_SITE_URL || "https://www.exploraspain.com";

/**
 * Destinos principales que se muestran en la home (orden manual). El resto
 * de ciudades sigue accesible desde /cities. Civitatis-style.
 */
const ORDEN_DESTINOS_HOME = [
  "madrid",
  "barcelona",
  "sevilla",
  "granada",
  "valencia",
  "malaga",
] as const;

type Props = {
  params: { lang: string };
};

type Copy = {
  metaTitle: string;
  metaDescription: string;
  ogDescription: string;
  websiteJsonLdDescription: string;
  heroTitle: string;
  heroSubtitle: string;
  exploreDestinos: string;
  seeActivitiesCta: string;
  topDestinosHeading: string;
  topDestinosSubheading: string;
  seeAllCities: string;
  featuredActHeading: string;
  featuredActSubheading: string;
  freeCancellation: string;
  fromLabel: string;
  viewActivity: string;
  guidesHeading: string;
  guidesSubheading: string;
  seeAllGuides: string;
};

function getCopy(lang: Idioma): Copy {
  if (lang === "de") {
    return {
      metaTitle: "ExploraSpain · Reiseführer, Touren & Aktivitäten Spanien",
      metaDescription:
        "Reiseführer, Touren und Aktivitäten für Spanien mit den besten Tipps von lokalen Experten: Madrid, Barcelona, Sevilla, Granada und mehr. Kostenlose Stornierung und vertrauenswürdige Partner.",
      ogDescription:
        "Reiseführer, Touren und Aktivitäten für Spanien mit den besten Tipps von lokalen Experten. Kostenlose Stornierung und Buchung über vertrauenswürdige Partner.",
      websiteJsonLdDescription:
        "Reiseführer, Touren und Aktivitäten für Spanien mit den besten Tipps von lokalen Experten: buche mit kostenloser Stornierung und vertrauenswürdigen Partnern.",
      heroTitle:
        "Reiseführer, Touren und Aktivitäten für Spanien, mit den besten Tipps von lokalen Experten",
      heroSubtitle:
        "Direkte und sichere Buchung von Touren und Aktivitäten in ganz Spanien — kein touristischer Fülltext, nur das, was sich wirklich lohnt.",
      exploreDestinos: "Reiseziele entdecken",
      seeActivitiesCta: "Beliebte Aktivitäten ansehen",
      topDestinosHeading: "Top-Reiseziele",
      topDestinosSubheading:
        "Wähle deine Stadt und entdecke die besten Aktivitäten in jeder von ihnen.",
      seeAllCities: "Alle Städte ansehen →",
      featuredActHeading: "Beliebte Aktivitäten",
      featuredActSubheading:
        "Das Beste aus jeder Stadt: kostenlose Stornierung und sofortige Bestätigung.",
      freeCancellation: "Kostenlose Stornierung",
      fromLabel: "Ab",
      viewActivity: "Aktivität ansehen →",
      guidesHeading: "Reiseführer für bessere Reisen",
      guidesSubheading:
        "Praktische Tipps und Routen mit Kriterium, bevor du buchst.",
      seeAllGuides: "Alle Reiseführer ansehen →",
    };
  }
  return {
    metaTitle: "ExploraSpain · Spain Travel Guides, Tours & Activities",
    metaDescription:
      "Spain travel guides, tours and activities with the best advice from local experts: Madrid, Barcelona, Seville, Granada and more. Free cancellation and trusted partners.",
    ogDescription:
      "Spain travel guides, tours and activities with the best advice from local experts. Free cancellation and booking through trusted partners.",
    websiteJsonLdDescription:
      "Spain travel guides, tours and activities with the best advice from local experts: book with free cancellation and trusted partners.",
    heroTitle:
      "Spain travel guides, tours and activities, with the best advice from local experts",
    heroSubtitle:
      "Direct, secure booking for tours and activities across Spain — no tourist filler, just what's actually worth it.",
    exploreDestinos: "Explore destinations",
    seeActivitiesCta: "See featured activities",
    topDestinosHeading: "Top destinations",
    topDestinosSubheading:
      "Pick your city and discover the best activities in each one.",
    seeAllCities: "See all cities →",
    featuredActHeading: "Featured activities",
    featuredActSubheading:
      "The best of each city: free cancellation and instant confirmation.",
    freeCancellation: "Free cancellation",
    fromLabel: "From",
    viewActivity: "View activity →",
    guidesHeading: "Guides to travel better",
    guidesSubheading: "Practical tips and routes with judgment before you book.",
    seeAllGuides: "See all guides →",
  };
}

export function generateStaticParams(): Array<{ lang: Idioma }> {
  return IDIOMAS_ACTIVOS.filter((l) => l !== "es").map((lang) => ({ lang }));
}

export async function generateMetadata({
  params,
}: Props): Promise<Metadata> {
  const { lang } = params;
  if (!esIdiomaActivo(lang) || lang === "es") {
    return {};
  }

  const copy = getCopy(lang);
  const canonicalUrl = `${SITE_URL}${prefijoIdioma(lang) || "/"}`;
  const languages = hreflangAlternates((l) => prefijoIdioma(l) || "/");

  return {
    title: { absolute: copy.metaTitle },
    description: copy.metaDescription,
    alternates: {
      canonical: canonicalUrl,
      languages,
    },
    openGraph: {
      type: "website",
      locale: IDIOMA_LOCALE[lang],
      url: canonicalUrl,
      siteName: "ExploraSpain",
      title: copy.metaTitle,
      description: copy.ogDescription,
    },
  };
}

/** Formatea un precio en EUR sin decimales para el locale dado. */
function formatearPrecio(precio: number, moneda: string, locale: string): string {
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency: moneda || "EUR",
    maximumFractionDigits: 0,
  }).format(precio);
}

export default function HomePage({ params }: Props) {
  if (!esIdiomaActivo(params.lang) || params.lang === "es") {
    notFound();
  }

  const lang: Idioma = params.lang;
  const copy = getCopy(lang);
  const locale = IDIOMA_LOCALE[lang];
  const dict = getDictionary(lang);
  const guias = obtenerGuiasDestacadas(lang, 6);
  const ciudades = obtenerListaCiudades(lang);

  // Mapa slug -> nombre de ciudad para etiquetar las tarjetas.
  const nombrePorCiudad = new Map(ciudades.map((c) => [c.slug, c.nombre]));

  // Destinos principales de la home: 6 ciudades en orden manual.
  const porSlug = new Map(ciudades.map((c) => [c.slug, c]));
  const destinosHome = ORDEN_DESTINOS_HOME.map((s) => porSlug.get(s)).filter(
    (c): c is NonNullable<typeof c> => c != null
  );

  // Actividades estrella de la home: las que promocionamos en Google Ads.
  // Selección curada en lib/actividades.ts (obtenerActividadesHome).
  const actividadesHome = obtenerActividadesHome(lang);

  const websiteJsonLd = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: "ExploraSpain",
    url: SITE_URL,
    inLanguage: IDIOMA_LOCALE[lang],
    description: copy.websiteJsonLdDescription,
  };

  const organizationJsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "SKYWARD PARTNERS, S.L.",
    legalName: "SKYWARD PARTNERS, S.L.",
    url: SITE_URL,
    email: "contacto@exploraspain.com",
    address: {
      "@type": "PostalAddress",
      streetAddress: "Calle Castelló 117",
      postalCode: "28006",
      addressLocality: "Madrid",
      addressCountry: "ES",
    },
    taxID: "B26629576",
  };

  return (
    <main>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(organizationJsonLd),
        }}
      />

      <HeroHome
        idioma={lang}
        opciones={ciudades.map((c) => ({
          nombre: c.nombre,
          url:
            urlListadoActividadesSiExiste(lang, c.slug) ??
            urlCiudad(lang, c.slug),
        }))}
        urlTodos={urlIndiceCiudades(lang)}
        anclaDestinos="#destinations"
      />
      <FranjaConfianza idioma={lang} />

      {/* Top destinations */}
      {destinosHome.length > 0 && (
        <section
          id="destinations"
          className="max-w-6xl mx-auto px-4 py-16 md:py-20 scroll-mt-24"
        >
          <div className="mb-10">
            <h2 className="font-fraunces text-3xl md:text-4xl font-bold text-piedra-900 mb-3">
              {copy.topDestinosHeading}
            </h2>
            <p className="text-piedra-600 text-lg">{copy.topDestinosSubheading}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {destinosHome.map((ciudad, index) => (
              <Link
                key={ciudad.url}
                href={
                  urlListadoActividadesSiExiste(lang, ciudad.slug) ??
                  urlCiudad(lang, ciudad.slug)
                }
                className="group relative block h-56 md:h-64 rounded-xl overflow-hidden shadow-sm"
              >
                <Image
                  src={`/ciudades/${ciudad.slug}.jpg`}
                  alt={`${ciudad.nombre}, ${ciudad.comunidad}`}
                  fill
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                  priority={index === 0}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-5">
                  <span className="inline-block bg-white/90 text-piedra-800 text-[11px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded mb-2">
                    {ciudad.comunidad}
                  </span>
                  <h3 className="font-fraunces text-2xl md:text-3xl font-bold text-white leading-tight drop-shadow">
                    {ciudad.nombre}
                  </h3>
                </div>
              </Link>
            ))}
          </div>

          <div className="mt-10 text-center">
            <Link
              href={urlIndiceCiudades(lang)}
              className="inline-block text-anil-600 hover:text-anil-700 font-semibold"
            >
              {copy.seeAllCities}
            </Link>
          </div>
        </section>
      )}

      {/* Featured activities and tours (below destinations) */}
      {actividadesHome.length > 0 && (
        <section
          id="activities"
          className="bg-piedra-50 border-y border-piedra-200 scroll-mt-24"
        >
          <div className="max-w-6xl mx-auto px-4 py-16 md:py-20">
            <div className="mb-10">
              <h2 className="font-fraunces text-3xl md:text-4xl font-bold text-piedra-900 mb-3">
                {copy.featuredActHeading}
              </h2>
              <p className="text-piedra-600 text-lg">{copy.featuredActSubheading}</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {actividadesHome.map((a) => (
                <Link
                  key={a.url}
                  href={a.url}
                  className="group flex flex-col overflow-hidden rounded-xl border border-piedra-200 bg-white shadow-sm transition hover:border-anil-400 hover:shadow-md"
                >
                  <div className="relative aspect-[4/3] w-full overflow-hidden bg-piedra-100">
                    {a.imagen ? (
                      <Image
                        src={a.imagen}
                        alt={a.imagenAlt}
                        fill
                        sizes="(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"
                        className="object-cover transition duration-300 group-hover:scale-105"
                      />
                    ) : null}
                    {a.cancelacionGratuita ? (
                      <span className="absolute top-3 left-3 bg-azafran-500 text-piedra-900 text-xs font-semibold px-2 py-1 rounded">
                        {copy.freeCancellation}
                      </span>
                    ) : null}
                  </div>
                  <div className="flex flex-1 flex-col p-5">
                    {/* Siempre se pinta (vacío si no hay ciudad) para que todas las tarjetas midan igual. */}
                    <span className="h-4 text-xs font-semibold uppercase tracking-wider text-anil-700 mb-2">
                      {nombrePorCiudad.get(a.ciudad) ?? ""}
                    </span>
                    <h3 className="font-fraunces text-lg font-bold text-piedra-900 mb-2 group-hover:text-anil-700 transition-colors leading-tight line-clamp-2 min-h-[2.5em]">
                      {a.titulo}
                    </h3>
                    <div className="flex items-center gap-x-3 h-5 overflow-hidden whitespace-nowrap text-sm text-piedra-500 mb-4">
                      {a.duracion ? (
                        <span className="min-w-0 truncate">{a.duracion}</span>
                      ) : null}
                      {typeof a.ratingProveedor === "number" &&
                      typeof a.numeroOpiniones === "number" ? (
                        <span className="shrink-0">
                          <span className="text-azafran-600" aria-hidden="true">
                            ★
                          </span>{" "}
                          {a.ratingProveedor.toFixed(1)} ({a.numeroOpiniones})
                        </span>
                      ) : null}
                    </div>
                    <div className="mt-auto pt-4 border-t border-piedra-100">
                      <SelloProveedor
                        proveedor={a.proveedor}
                        idioma={lang}
                        className="mb-3"
                      />
                      <div className="flex items-end justify-between">
                        <div>
                          <p className="text-xs uppercase tracking-wider text-piedra-400">
                            {copy.fromLabel}
                          </p>
                          <p className="text-xl font-bold text-piedra-900">
                            {formatearPrecio(a.precioDesde, a.moneda, locale)}
                          </p>
                        </div>
                        <span
                          aria-hidden="true"
                          className="text-sm font-semibold text-anil-600 group-hover:text-anil-700"
                        >
                          {copy.viewActivity}
                        </span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Guides (accessory) */}
      {guias.length > 0 && (
        <section className="max-w-6xl mx-auto px-4 py-14 md:py-16">
          <div className="flex flex-wrap items-end justify-between gap-3 mb-8">
            <div>
              <h2 className="font-fraunces text-2xl md:text-3xl font-bold text-piedra-900 mb-2">
                {copy.guidesHeading}
              </h2>
              <p className="text-piedra-600">{copy.guidesSubheading}</p>
            </div>
            <Link
              href={urlIndiceGuias(lang)}
              className="text-anil-600 hover:text-anil-700 font-semibold whitespace-nowrap"
            >
              {copy.seeAllGuides}
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {guias.map((guia) => (
              <Link
                key={guia.url}
                href={guia.url}
                className="group block border border-piedra-200 rounded-lg p-6 hover:border-anil-400 hover:shadow-md transition-all"
              >
                <span className="inline-block bg-anil-100 text-anil-700 text-xs font-semibold uppercase tracking-wider px-2 py-1 rounded mb-3">
                  {guia.categoria}
                </span>
                <h3 className="font-fraunces text-lg font-bold text-piedra-900 mb-2 group-hover:text-anil-700 transition-colors">
                  {guia.titulo}
                </h3>
                <p className="text-piedra-600 text-sm leading-relaxed mb-4 line-clamp-3">
                  {guia.descripcion}
                </p>
                <div className="flex items-center justify-between text-xs text-piedra-500">
                  <span>{formatearFecha(guia.fecha, lang)}</span>
                  <span>
                    {guia.tiempoLectura} {dict.guias.minutosLectura}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
      <FranjaPartners idioma={lang} />
    </main>
  );
}
